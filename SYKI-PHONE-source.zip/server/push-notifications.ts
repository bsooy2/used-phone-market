import * as db from "./db";

type ExpoPushReceipt = { status?: "ok" | "error"; details?: { error?: string } };

export function isExpoPushToken(token: string) {
  return /^ExponentPushToken\[[^\]]+\]$|^ExpoPushToken\[[^\]]+\]$/.test(token);
}

export async function sendInquiryReplyPush(input: { userId: string; inquiryId: string; transactionLabel: string }) {
  const rows = await db.getDevicePushTokens(input.userId);
  const tokens = rows.map((row) => row.token).filter(isExpoPushToken);
  if (tokens.length === 0) return { sent: 0, skipped: true };
  const response = await fetch("https://exp.host/--/api/v2/push/send", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(tokens.map((to) => ({ to, sound: "default", title: "거래 문의에 답변이 등록되었어요", body: input.transactionLabel, data: { url: `/my-inquiries?inquiryId=${input.inquiryId}` } }))),
  });
  if (!response.ok) throw new Error("푸시 알림 발송에 실패했습니다.");
  const payload = await response.json() as { data?: ExpoPushReceipt[] };
  const invalidTokens = payload.data?.flatMap((receipt, index) => receipt.status === "error" && ["DeviceNotRegistered", "InvalidCredentials"].includes(receipt.details?.error ?? "") ? [tokens[index]] : []) ?? [];
  await Promise.all(invalidTokens.map((token) => db.deleteDevicePushToken(token)));
  return { sent: tokens.length - invalidTokens.length, skipped: false };
}
