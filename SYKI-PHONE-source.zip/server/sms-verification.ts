import { createHmac, randomBytes, randomInt, randomUUID, timingSafeEqual } from "crypto";

import { canRequestSmsCode, getVerificationFailureReason, normalizeSmsPhone, SMS_CODE_TTL_MS } from "../lib/sms-verification-rules";
import { getSmsLimitStatus } from "../lib/sms-budget-rules";

type Challenge = { code: string; expiresAt: number; attempts: number; requestedAt: number };
const challenges = new Map<string, Challenge>();

type SolapiMessage = { messageId: string; groupId?: string | null; to: string; type?: string | null; status?: string; statusCode?: string | null; reason?: string | null; dateCreated: string; text?: string };
type SolapiBalanceHistory = { balanceAmount: number; type: string; groupId?: string | null; serviceMethod?: string | null; dateCreated: string };

function createSolapiAuthorization(apiKey: string, apiSecret: string) {
  const date = new Date().toISOString().replace(/\.\d{3}Z$/, "+00:00");
  const alphabet = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const bytes = randomBytes(32);
  const salt = Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join("");
  const signature = createHmac("sha256", apiSecret).update(`${date}${salt}`).digest("hex");
  return `HMAC-SHA256 apiKey=${apiKey}, date=${date}, salt=${salt}, signature=${signature}`;
}

export async function getSolapiCredentialHealth(): Promise<{ ok: boolean; status: number | null; reason?: string }> {
  const apiKey = process.env.SOLAPI_API_KEY;
  const apiSecret = process.env.SOLAPI_API_SECRET;
  if (!apiKey || !apiSecret) return { ok: false, status: null, reason: "missing_credentials" };
  const response = await fetch("https://api.solapi.com/cash/v1/balance", { headers: { Authorization: createSolapiAuthorization(apiKey, apiSecret), "Content-Type": "application/json" } });
  const reason = response.ok ? undefined : (await response.text()).slice(0, 240);
  return { ok: response.ok, status: response.status, reason };
}

export async function verifySolapiCredentials(): Promise<boolean> {
  return (await getSolapiCredentialHealth()).ok;
}

async function solapiFetch(path: string, init?: RequestInit) {
  const apiKey = process.env.SOLAPI_API_KEY;
  const apiSecret = process.env.SOLAPI_API_SECRET;
  if (!apiKey || !apiSecret) throw new Error("문자 발송 서비스 설정이 필요합니다.");
  const response = await fetch(`https://api.solapi.com${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", Authorization: createSolapiAuthorization(apiKey, apiSecret), ...(init?.headers ?? {}) },
  });
  if (!response.ok) throw new Error("SOLAPI 발송 이력을 불러오지 못했습니다.");
  return response.json() as Promise<unknown>;
}

function maskPhone(phone: string) {
  return phone.length >= 10 ? `${phone.slice(0, 3)}-****-${phone.slice(-4)}` : "***";
}

export async function getSmsDashboard(days = 30) {
  const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
  const [messagesRaw, historyRaw, balanceRaw] = await Promise.all([
    solapiFetch(`/messages/v4/list?limit=100&startDate=${encodeURIComponent(startDate)}`),
    solapiFetch(`/cash/v1/balance/history?limit=100&balanceRecharge=false&pointRecharge=false&pointDeduct=false`),
    solapiFetch("/cash/v1/balance"),
  ]);
  const messages = Object.values(((messagesRaw as { messageList?: Record<string, SolapiMessage> }).messageList ?? {}))
    .filter((message) => message.text?.startsWith("[시끼폰] 본인인증번호"));
  const authGroupIds = new Set(messages.map((message) => message.groupId).filter((groupId): groupId is string => Boolean(groupId)));
  const charges = ((historyRaw as { historyList?: SolapiBalanceHistory[] }).historyList ?? [])
    .filter((entry) => entry.type === "SERVICE-CHARGE" && entry.serviceMethod === "MT" && entry.balanceAmount < 0 && entry.groupId && authGroupIds.has(entry.groupId));
  const totalCost = charges.reduce((sum, entry) => sum + Math.abs(entry.balanceAmount), 0);
  const today = new Date().toISOString().slice(0, 10);
  const dailySentCount = messages.filter((message) => message.dateCreated.slice(0, 10) === today).length;
  const balanceRecord = balanceRaw as { balance?: number; cash?: number; amount?: number };
  const balance = Number(balanceRecord.balance ?? balanceRecord.cash ?? balanceRecord.amount ?? 0);
  const dailyLimit = Math.max(1, Number(process.env.SOLAPI_DAILY_LIMIT ?? 100));
  const balanceWarningThreshold = Math.max(0, Number(process.env.SOLAPI_BALANCE_WARNING_THRESHOLD ?? 5000));
  const limit = getSmsLimitStatus({ balance, dailySentCount, dailyLimit, balanceWarningThreshold });
  return {
    periodDays: days,
    sentCount: messages.length,
    deliveredCount: messages.filter((message) => message.statusCode === "4000").length,
    totalCost,
    balance,
    dailySentCount,
    dailyLimit,
    limit,
    messages: messages.slice(0, 30).map((message) => ({ id: message.messageId, recipient: maskPhone(message.to), type: message.type ?? "SMS", status: message.status ?? "PENDING", statusCode: message.statusCode, reason: message.reason, createdAt: message.dateCreated })),
  };
}

async function sendSolapiSms(to: string, text: string) {
  const apiKey = process.env.SOLAPI_API_KEY;
  const apiSecret = process.env.SOLAPI_API_SECRET;
  const from = normalizeSmsPhone(process.env.SOLAPI_SENDER ?? "");
  if (!apiKey || !apiSecret || !from) throw new Error("문자 발송 서비스 설정이 필요합니다.");
  const response = await fetch("https://api.solapi.com/messages/v4/send", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: createSolapiAuthorization(apiKey, apiSecret) },
    body: JSON.stringify({ message: { to, from, text, customFields: { purpose: "syki_password_reset" } } }),
  });
  if (!response.ok) throw new Error("인증번호 문자 발송에 실패했습니다.");
}

export async function requestSmsVerification(phoneInput: string) {
  const phone = normalizeSmsPhone(phoneInput);
  if (!/^01[016789]\d{7,8}$/.test(phone)) return { ok: false as const, error: "올바른 휴대폰 번호를 입력해 주세요." };
  const now = Date.now();
  const current = challenges.get(phone);
  if (!canRequestSmsCode(current?.requestedAt, now)) return { ok: false as const, error: "인증번호는 1분 후 다시 발송할 수 있습니다." };
  if (!(await verifySolapiCredentials())) return { ok: false as const, error: "문자 발송 서비스 설정을 확인해 주세요." };
  const code = randomInt(100000, 1_000_000).toString();
  await sendSolapiSms(phone, `[시끼폰] 본인인증번호는 ${code}입니다. 3분 내 입력해 주세요.`);
  challenges.set(phone, { code, requestedAt: now, expiresAt: now + SMS_CODE_TTL_MS, attempts: 0 });
  return { ok: true as const, expiresInSeconds: SMS_CODE_TTL_MS / 1000 };
}

export function verifySmsVerification(phoneInput: string, code: string) {
  const phone = normalizeSmsPhone(phoneInput);
  const current = challenges.get(phone);
  const failure = getVerificationFailureReason(current, Date.now());
  if (failure) return { ok: false as const, error: failure };
  if (!current) return { ok: false as const, error: "인증번호를 먼저 발송해 주세요." };
  current.attempts += 1;
  const expected = Buffer.from(current.code);
  const received = Buffer.from(code.trim());
  const matches = expected.length === received.length && timingSafeEqual(expected, received);
  if (!matches) return { ok: false as const, error: "인증번호가 일치하지 않습니다." };
  challenges.delete(phone);
  return { ok: true as const, resetToken: randomUUID() };
}
