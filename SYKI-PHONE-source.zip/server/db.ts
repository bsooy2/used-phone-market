import { desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { appMeta, devicePushTokens, InsertListing, InsertUser, Listing, listings, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/** 동일 기기는 최신 사용자 계정으로 갱신해 중복 알림을 막는다. */
export async function saveDevicePushToken(userId: string, token: string) {
  const db = await getDb();
  if (!db) return false;
  const existing = await db.select().from(devicePushTokens).where(eq(devicePushTokens.token, token)).limit(1);
  if (existing[0]) {
    await db.update(devicePushTokens).set({ userId, updatedAt: new Date() }).where(eq(devicePushTokens.id, existing[0].id));
  } else {
    await db.insert(devicePushTokens).values({ userId, token });
  }
  return true;
}

export async function getDevicePushTokens(userId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(devicePushTokens).where(eq(devicePushTokens.userId, userId));
}

export async function deleteDevicePushToken(token: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(devicePushTokens).where(eq(devicePushTokens.token, token));
}

// ===== 매물(listings) 쿼리 =====

/** 시드용 초기 매물 데이터 (DB가 비어있을 때 1회 적재) */
const SEED_LISTINGS: InsertListing[] = [
  { brand: "Apple", model: "iPhone 15 Pro", storage: "256GB", color: "내추럴 티타늄", grade: "S", battery: 99, price: 1090000, buyPrice: 980000, image: "#1F2937", description: "정품 미개봉에 가까운 최상급 상태입니다. 액정/외관 모두 깨끗합니다.", accessories: "본체, 정품 케이블", sold: 0 },
  { brand: "Samsung", model: "Galaxy S24 Ultra", storage: "512GB", color: "티타늄 블랙", grade: "A", battery: 95, price: 960000, buyPrice: 850000, image: "#111827", description: "S펜 정상, 생활기스 약간 있으나 전반적으로 깨끗합니다.", accessories: "본체, S펜, 박스", sold: 0 },
  { brand: "Apple", model: "iPhone 14", storage: "128GB", color: "미드나이트", grade: "A", battery: 91, price: 620000, buyPrice: 540000, image: "#1E293B", description: "배터리 효율 양호, 액정 흠집 없음. 케이스 착용 사용했습니다.", accessories: "본체만", sold: 0 },
  { brand: "Samsung", model: "Galaxy Z Flip5", storage: "256GB", color: "민트", grade: "B", battery: 88, price: 540000, buyPrice: 460000, image: "#0F766E", description: "힌지 정상 작동, 외관 사용감 있습니다. 정상 작동 확인했습니다.", accessories: "본체, 충전기", sold: 0 },
  { brand: "Apple", model: "iPhone 13 mini", storage: "128GB", color: "스타라이트", grade: "B", battery: 85, price: 410000, buyPrice: 340000, image: "#334155", description: "소형 모델 선호자에게 추천. 하단 미세 기스 있습니다.", accessories: "본체만", sold: 0 },
  { brand: "Samsung", model: "Galaxy S23", storage: "256GB", color: "라벤더", grade: "S", battery: 97, price: 560000, buyPrice: 490000, image: "#6D28D9", description: "여성 사용자가 깔끔하게 사용한 상품입니다. 거의 새것 수준.", accessories: "본체, 박스, 충전기", sold: 0 },
  { brand: "Apple", model: "iPhone 12", storage: "64GB", color: "블루", grade: "C", battery: 79, price: 290000, buyPrice: 230000, image: "#1D4ED8", description: "모서리 흠집과 후면 미세 크랙 있으나 사용에 지장 없습니다.", accessories: "본체만", sold: 0 },
  { brand: "Samsung", model: "Galaxy A54", storage: "128GB", color: "그래파이트", grade: "A", battery: 93, price: 320000, buyPrice: 260000, image: "#374151", description: "보급형 인기 모델, 상태 양호합니다. 세컨폰으로 추천.", accessories: "본체, 충전기", sold: 0 },
];

const SEED_FLAG_KEY = "listings_seeded";

/**
 * 매물 목록 조회 (최신순).
 * 최초 1회에 한해서만 시드 데이터를 적재하며,
 * 이후 관리자가 모든 매물을 삭제해 비어도 시드를 다시 채우지 않는다.
 */
export async function getListings(): Promise<Listing[]> {
  const db = await getDb();
  if (!db) return [];

  // 이미 한 번이라도 시드했는지 확인
  const seededRows = await db.select().from(appMeta).where(eq(appMeta.key, SEED_FLAG_KEY)).limit(1);
  const alreadySeeded = seededRows.length > 0;

  const rows = await db.select().from(listings).orderBy(desc(listings.createdAt));

  // 아직 한 번도 시드한 적이 없고, 매물도 비어 있을 때만 최초 1회 시드
  if (!alreadySeeded && rows.length === 0) {
    await db.insert(listings).values(SEED_LISTINGS);
    await db.insert(appMeta).values({ key: SEED_FLAG_KEY, value: new Date().toISOString() });
    return db.select().from(listings).orderBy(desc(listings.createdAt));
  }

  // 매물은 있는데 플래그가 없는 경우(기존 데이터) 플래그만 보정
  if (!alreadySeeded && rows.length > 0) {
    await db.insert(appMeta).values({ key: SEED_FLAG_KEY, value: new Date().toISOString() }).onDuplicateKeyUpdate({ set: { value: new Date().toISOString() } });
  }

  return rows;
}

/** 단일 매물 조회 */
export async function getListingById(id: number): Promise<Listing | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(listings).where(eq(listings.id, id)).limit(1);
  return rows[0] ?? null;
}

/** 매물 생성 → 생성된 id 반환 */
export async function createListing(data: InsertListing): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(listings).values(data);
  // mysql2 driver 결과는 [ResultSetHeader, ...] 형태이며 insertId는 첫 요소에 있다.
  const header = Array.isArray(result) ? (result[0] as { insertId?: number }) : (result as { insertId?: number });
  return Number(header?.insertId ?? 0);
}

/** 매물 수정 */
export async function updateListing(id: number, data: Partial<InsertListing>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(listings).set(data).where(eq(listings.id, id));
}

/** 매물 삭제 */
export async function deleteListing(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(listings).where(eq(listings.id, id));
}

/** 매물 조회수 또는 찜 횟수를 원자적으로 증감한다. */
export async function changeListingMetric(id: number, kind: "view" | "favorite", delta: 1 | -1): Promise<void> {
  const db = await getDb();
  if (!db) return;

  if (kind === "view") {
    await db
      .update(listings)
      .set({ viewCount: sql`GREATEST(0, ${listings.viewCount} + ${delta})` })
      .where(eq(listings.id, id));
    return;
  }

  await db
    .update(listings)
    .set({ favoriteCount: sql`GREATEST(0, ${listings.favoriteCount} + ${delta})` })
    .where(eq(listings.id, id));
}
