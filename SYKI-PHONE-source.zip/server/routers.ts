import { TRPCError } from "@trpc/server";
import { z } from "zod";

import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { getSmsDashboard, getSolapiCredentialHealth, requestSmsVerification, verifySmsVerification } from "./sms-verification";
import { isExpoPushToken, sendInquiryReplyPush } from "./push-notifications";

// 관리자(사장님) PIN — 환경변수 우선, 미설정 시 기본값
let ADMIN_PIN = process.env.ADMIN_PIN ?? "246810";

function assertAdminPin(pin: string) {
  if (pin !== ADMIN_PIN) {
    throw new TRPCError({ code: "FORBIDDEN", message: "관리자 PIN이 올바르지 않습니다." });
  }
}

const gradeEnum = z.enum(["S", "A", "B", "C"]);

const listingInput = z.object({
  brand: z.string().min(1).max(64),
  model: z.string().min(1).max(128),
  storage: z.string().min(1).max(32),
  color: z.string().min(1).max(64),
  grade: gradeEnum,
  battery: z.number().int().min(0).max(100),
  price: z.number().int().min(0),
  buyPrice: z.number().int().min(0).default(0),
  image: z.string().min(1).max(32).default("#1F2937"),
  photos: z.string().max(4000).default("[]"),
  description: z.string().max(2000).default(""),
  accessories: z.string().max(255).default("본체만"),
  sold: z.number().int().min(0).max(1).default(0),
});

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  sms: router({
    health: publicProcedure.query(() => getSolapiCredentialHealth()),
    dashboard: publicProcedure.input(z.object({ pin: z.string(), days: z.number().int().min(1).max(90).default(30) })).query(async ({ input }) => {
      assertAdminPin(input.pin);
      return getSmsDashboard(input.days);
    }),
    requestPasswordReset: publicProcedure.input(z.object({ phone: z.string().min(9).max(20) })).mutation(({ input }) => requestSmsVerification(input.phone)),
    verifyPasswordReset: publicProcedure.input(z.object({ phone: z.string().min(9).max(20), code: z.string().length(6) })).mutation(({ input }) => verifySmsVerification(input.phone, input.code)),
  }),

  push: router({
    registerDevice: publicProcedure.input(z.object({ userId: z.string().min(1).max(96), token: z.string().min(20).max(255) })).mutation(async ({ input }) => {
      if (!isExpoPushToken(input.token)) return { ok: false as const, error: "유효하지 않은 푸시 토큰입니다." };
      const saved = await db.saveDevicePushToken(input.userId, input.token);
      return saved ? { ok: true as const } : { ok: false as const, error: "토큰 저장소를 사용할 수 없습니다." };
    }),
    sendInquiryReply: publicProcedure.input(z.object({ pin: z.string(), userId: z.string().min(1).max(96), inquiryId: z.string().min(1).max(128), transactionLabel: z.string().min(1).max(200) })).mutation(async ({ input }) => {
      assertAdminPin(input.pin);
      return sendInquiryReplyPush(input);
    }),
  }),

  // 매물(중고폰) — 조회는 공개, 추가/수정/삭제는 관리자 PIN 검증
  listings: router({
    list: publicProcedure.query(() => db.getListings()),

    get: publicProcedure
      .input(z.object({ id: z.number().int() }))
      .query(({ input }) => db.getListingById(input.id)),

    /** 상세 화면 조회 시 조회수 증가 */
    recordView: publicProcedure
      .input(z.object({ id: z.number().int() }))
      .mutation(async ({ input }) => {
        await db.changeListingMetric(input.id, "view", 1);
        return { ok: true };
      }),

    /** 찜/찜 해제 시 통계 반영 */
    recordFavorite: publicProcedure
      .input(z.object({ id: z.number().int(), active: z.boolean() }))
      .mutation(async ({ input }) => {
        await db.changeListingMetric(input.id, "favorite", input.active ? 1 : -1);
        return { ok: true };
      }),

    // 관리자 PIN 검증 (관리자 모드 진입용)
    verifyPin: publicProcedure
      .input(z.object({ pin: z.string() }))
      .mutation(({ input }) => {
        return { ok: input.pin === ADMIN_PIN };
      }),

    create: publicProcedure
      .input(z.object({ pin: z.string(), data: listingInput }))
      .mutation(async ({ input }) => {
        assertAdminPin(input.pin);
        const id = await db.createListing(input.data);
        return { id };
      }),

    update: publicProcedure
      .input(z.object({ pin: z.string(), id: z.number().int(), data: listingInput.partial() }))
      .mutation(async ({ input }) => {
        assertAdminPin(input.pin);
        await db.updateListing(input.id, input.data);
        return { ok: true };
      }),

    delete: publicProcedure
      .input(z.object({ pin: z.string(), id: z.number().int() }))
      .mutation(async ({ input }) => {
        assertAdminPin(input.pin);
        await db.deleteListing(input.id);
        return { ok: true };
      }),

    // 관리자 PIN 변경
    changePin: publicProcedure
      .input(z.object({ currentPin: z.string(), newPin: z.string().min(4) }))
      .mutation(({ input }) => {
        assertAdminPin(input.currentPin);
        ADMIN_PIN = input.newPin;
        // 런타임 메모리에만 저장됨 — 서버 재시작 시 환경변수로 복구
        return { ok: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
