/**
 * 대인 TRADE 시세표(2026.6.17) 기반 삼성 갤럭시 매입가 데이터.
 * 단위: 만원. null = 매입 불가(X).
 * 갤럭시는 등급 체계가 A / A- / B+ / B / 중고(액파)로 매핑.
 * (액파특가 liquid 열은 갤럭시 표에는 없으므로 중고/액파가를 liquid에 동일 적용)
 */
import { BuybackModel, GradePrices, OptionDeduction } from "./buyback-data";

const P = (
  A: number | null,
  Aminus: number | null,
  Bplus: number | null,
  B: number | null,
  liquid: number | null,
  used: number | null,
): GradePrices => ({ A, Aminus, Bplus, B, liquid, used });

const D = (
  liquidCrack: number,
  backGlass: number,
  lcd: number,
  biometrics: number,
  camera: number,
  wifi: number,
  burnInMid: number,
  burnInStrong: number,
  burnInLcd?: number,
  lcdDamage?: number,
): OptionDeduction => ({
  liquidCrack,
  backGlass,
  lcd,
  biometrics,
  camera,
  wifi,
  burnInMid,
  burnInStrong,
  burnInLcd,
  lcdDamage,
});

/**
 * 갤럭시 잔상 차감은 시세표 원문(중잔상/강잔상/L급잔상) 기준으로 정교화.
 * D(액정파손, 후면, LCD불량, 지문/페이스, 카메라, WIFI, 중잔상, 강잔상, L급잔상, LCD파손차감)
 * - lcd: 일반 LCD 불량(터치/줄 등) 차감
 * - lcdDamage: 시세표 'LCD파손' 별도 매입가 기준 차감(표의 LCD파손가 컬럼)
 * - burnInLcd: LCD급(L급) 잔상 차감 (특가 미적용)
 */
export const SAMSUNG_MODELS: BuybackModel[] = [
  // ── 갤럭시 S 시리즈 ──
  {
    key: "galaxy-s20fe", brand: "Samsung", model: "갤럭시 S20 FE", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(12, 11, 10, 9, 8.5, 8.5) }],
    deductions: D(2, 2, 4, 3, 5, 3, 1, 2, 3, 4.5),
  },
  {
    key: "galaxy-s20", brand: "Samsung", model: "갤럭시 S20", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(15, 14, 13, 12.5, 11.7, 11.7) }],
    deductions: D(2, 2, 5.5, 3, 5, 3, 1.5, 3, 5, 5.5),
  },
  {
    key: "galaxy-s20plus", brand: "Samsung", model: "갤럭시 S20 PLUS", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(16, 15, 14, 13, 12.2, 12.2) }],
    deductions: D(2, 2, 6.5, 3, 5, 3, 1.5, 3, 5, 6.5),
  },
  {
    key: "galaxy-s20ultra", brand: "Samsung", model: "갤럭시 S20 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(22, 21, 19.5, 19, 17, 17) }],
    deductions: D(2, 2, 9.5, 3, 5, 3, 1.5, 4, 5.5, 9.5),
  },
  {
    key: "galaxy-s21", brand: "Samsung", model: "갤럭시 S21", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(19, 18, 16.5, 15.5, 15, 15) }],
    deductions: D(2, 2, 8.7, 3, 5, 3, 1.5, 3, 5, 8.7),
  },
  {
    key: "galaxy-s21plus", brand: "Samsung", model: "갤럭시 S21 PLUS", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(20, 19, 17.5, 16, null, 15) }],
    deductions: D(2, 2, 9.5, 3, 5, 3, 1.5, 3, 5, 9.5),
  },
  {
    key: "galaxy-s21ultra", brand: "Samsung", model: "갤럭시 S21 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(33, 32, 30.5, 29, null, 28.5) }],
    deductions: D(2, 2, 19, 3, 5, 3, 1.5, 4, 6, 19),
  },
  {
    key: "galaxy-s22", brand: "Samsung", model: "갤럭시 S22", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(26, 24, 21, 19, null, 18) }],
    deductions: D(2, 2, 9.5, 3, 5, 3, 2, 4, 6, 9.5),
  },
  {
    key: "galaxy-s22plus", brand: "Samsung", model: "갤럭시 S22 PLUS", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(28, 26, 23, 20, null, 19) }],
    deductions: D(2, 2, 10.5, 3, 5, 3, 2, 4, 6, 10.5),
  },
  {
    key: "galaxy-s22ultra", brand: "Samsung", model: "갤럭시 S22 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(44, 42, 39, 36, null, 35) }],
    deductions: D(2, 2, 21.5, 3, 5, 3, 2, 4, 7, 21.5),
  },
  {
    key: "galaxy-s23fe", brand: "Samsung", model: "갤럭시 S23 FE", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(28, 27, 25, 23, null, 20) }],
    deductions: D(2, 2, 14, 3, 5, 3, 2, 4, 6, 14),
  },
  {
    key: "galaxy-s23", brand: "Samsung", model: "갤럭시 S23", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(34, 32, 29, 26, null, 24.5) }],
    deductions: D(2, 2, 16, 3, 5, 3, 2, 4, 6, 16),
  },
  {
    key: "galaxy-s23plus", brand: "Samsung", model: "갤럭시 S23 PLUS", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(36, 34, 31, 28, null, 26.5) }],
    deductions: D(2, 2, 19, 3, 5, 3, 2, 4, 6, 19),
  },
  {
    key: "galaxy-s23ultra", brand: "Samsung", model: "갤럭시 S23 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(58, 56, 53, 50, null, 45) }],
    deductions: D(2, 2, 27, 3, 5, 3, 3, 6, 8, 27),
  },
  {
    key: "galaxy-s24fe", brand: "Samsung", model: "갤럭시 S24 FE", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(41, 39, 36.5, 34, null, 32) }],
    deductions: D(2, 2, 21, 3, 5, 3, 3, 6, 8, 21),
  },
  {
    key: "galaxy-s24", brand: "Samsung", model: "갤럭시 S24", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(44, 42, 38, 34, null, 32.5) }],
    deductions: D(2, 2, 24, 3, 5, 3, 3, 6, 8, 24),
  },
  {
    key: "galaxy-s24plus", brand: "Samsung", model: "갤럭시 S24 PLUS", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(47, 45, 41, 37, null, 33) }],
    deductions: D(2, 2, 26, 3, 5, 3, 3, 6, 8, 26),
  },
  {
    key: "galaxy-s24ultra", brand: "Samsung", model: "갤럭시 S24 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(74, 72, 69, 65, null, 63.5) }],
    deductions: D(2, 2, 46, 3, 5, 3, 4, 8, 10, 46),
  },
  {
    key: "galaxy-s25fe", brand: "Samsung", model: "갤럭시 S25 FE", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(54, 52, 49, 46, null, 39.5) }],
    deductions: D(2, 2, 18, 3, 5, 3, 2, 4, 7, 18),
  },
  {
    key: "galaxy-s25", brand: "Samsung", model: "갤럭시 S25", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(63, 61, 57, 53, null, 50.5) }],
    deductions: D(2, 2, 34, 3, 5, 3, 5, 8, 11, 34),
  },
  {
    key: "galaxy-s25plus", brand: "Samsung", model: "갤럭시 S25 PLUS", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(67, 65, 61, 57, null, 51) }],
    deductions: D(2, 2, 35, 3, 5, 3, 5, 8, 11, 35),
  },
  {
    key: "galaxy-s25edge", brand: "Samsung", model: "갤럭시 S25 엣지", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(56, 54, 51, 47, null, 41.5) }],
    deductions: D(2, 2, 27.5, 3, 5, 3, 5, 8, 11, 27.5),
  },
  {
    key: "galaxy-s25ultra", brand: "Samsung", model: "갤럭시 S25 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(94, 92, 89, 86, null, 86) }],
    deductions: D(2, 2, 57, 3, 5, 3, 5, 8, 11, 57),
  },
  // ── 갤럭시 Z 폴드/플립 ──
  {
    key: "galaxy-zflip3", brand: "Samsung", model: "갤럭시 Z플립3", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(19, 17, 14, 12, null, 12) }],
    deductions: D(8, 4, 4, 3, 5, 3, 3, 5, 8, 4),
  },
  {
    key: "galaxy-zflip4", brand: "Samsung", model: "갤럭시 Z플립4", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(21, 19, 16, 14, null, 14) }],
    deductions: D(10, 4, 4, 3, 5, 3, 3, 5, 9, 4),
  },
  {
    key: "galaxy-zflip5", brand: "Samsung", model: "갤럭시 Z플립5", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(33, 31, 29, 19, null, 19) }],
    deductions: D(15, 5, 5, 3, 5, 3, 4, 6, 12, 4.5),
  },
  {
    key: "galaxy-zflip6", brand: "Samsung", model: "갤럭시 Z플립6", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(47, 43, 37, 29, null, 29) }],
    deductions: D(23, 9, 9, 5, 5, 5, 7, 10, 17, 11.5),
  },
  {
    key: "galaxy-zfold3", brand: "Samsung", model: "갤럭시 Z폴드3", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(39, 37, 33, 31, null, 31) }],
    deductions: D(23, 8, 8, 5, 5, 5, 5, 8, 15, 12.5),
  },
  {
    key: "galaxy-zfold4", brand: "Samsung", model: "갤럭시 Z폴드4", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(49, 46, 41, 34, null, 34) }],
    deductions: D(26, 9, 9, 5, 5, 5, 5, 8, 20, 10.5),
  },
  {
    key: "galaxy-zfold5", brand: "Samsung", model: "갤럭시 Z폴드5", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(58, 55, 49, 45, null, 45) }],
    deductions: D(35, 11, 11, 5, 5, 5, 5, 8, 25, 12.5),
  },
  {
    key: "galaxy-zfold6", brand: "Samsung", model: "갤럭시 Z폴드6", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(89, 86, 78, 70, null, 70) }],
    deductions: D(55, 14, 14, 9, 9, 9, 7, 12, 30, 19),
  },
  // ── 갤럭시 노트 ──
  {
    key: "galaxy-note10", brand: "Samsung", model: "갤럭시 노트10", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(13, 13, 12, null, 11.5, 11.5) }],
    deductions: D(2, 2, 3.7, 3, 5, 3, 1, 3, 5, 3.7),
  },
  {
    key: "galaxy-note10plus", brand: "Samsung", model: "갤럭시 노트10+", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(18, 17, 16.5, null, 16.5, 16.5) }],
    deductions: D(2, 2, 6.5, 3, 5, 3, 1, 2.5, 6, 6.5),
  },
  {
    key: "galaxy-note20", brand: "Samsung", model: "갤럭시 노트20", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(17, 16, 14, 12, null, 11) }],
    deductions: D(2, 2, 7, 3, 5, 3, 1, 3, 4.5, 7),
  },
  {
    key: "galaxy-note20ultra", brand: "Samsung", model: "갤럭시 노트20 울트라", batteryMin: 80,
    variants: [{ storage: "기본", prices: P(29, 28, 26, 25, null, 24) }],
    deductions: D(2, 2, 11.7, 3, 5, 3, 1.5, 3, 6, 11.7),
  },
  // ── 갤럭시 A 시리즈 (주요) ──
  {
    key: "galaxy-a15", brand: "Samsung", model: "갤럭시 A15", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(10.5, 10.5, 9.5, 8.5, 7.2, 7.2) }],
    deductions: D(1, 1, 4.2, 2, 2, 2, 0.5, 1.5, 2.5, 4.2),
  },
  {
    key: "galaxy-a16", brand: "Samsung", model: "갤럭시 A16", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(13.5, 13.5, 12, 11, 8.8, 8.8) }],
    deductions: D(1, 1, 4.6, 2, 2, 2, 0.5, 1.5, 2.5, 4.6),
  },
  {
    key: "galaxy-a25", brand: "Samsung", model: "갤럭시 A25", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(13.5, 13, 12.5, 11.5, 9.3, 9.3) }],
    deductions: D(1, 1, 4.7, 2, 2, 2, 1, 1.5, 2.5, 4.7),
  },
  {
    key: "galaxy-a34", brand: "Samsung", model: "갤럭시 A34", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(13, 13, 12.5, 11.5, 7.6, 7.6) }],
    deductions: D(1, 1, 3.3, 2, 2, 2, 1, 2, 3, 3.3),
  },
  {
    key: "galaxy-a35", brand: "Samsung", model: "갤럭시 A35", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(20.5, 20, 19.5, 16.5, 11.4, 11.4) }],
    deductions: D(1, 1, 5.5, 2, 2, 2, 1.5, 3, 4, 5.5),
  },
  {
    key: "galaxy-a36", brand: "Samsung", model: "갤럭시 A36", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(19.5, 19, 18.5, 16.5, 13.2, 13.2) }],
    deductions: D(1, 1, 6.5, 2, 2, 2, 1.5, 3, 4, 6.5),
  },
  {
    key: "galaxy-a54", brand: "Samsung", model: "갤럭시 A54 (퀀텀4)", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(18.5, 18, 17.5, 15.5, 10.8, 10.8) }],
    deductions: D(1, 1, 5.7, 2, 2, 2, 1, 2.5, 3.5, 5.7),
  },
  {
    key: "galaxy-a55", brand: "Samsung", model: "갤럭시 A55 (퀀텀5)", batteryMin: 75,
    variants: [{ storage: "기본", prices: P(21, 21, 20.5, 17.5, 15.2, 15.2) }],
    deductions: D(1, 1, 7.5, 2, 2, 2, 1, 2.5, 3.5, 7.5),
  },
];
