export const STORE_INFO = {
  name: "SYKI PHONE",
  nameKo: "시끼폰",
  tagline: "서귀포 중고폰 매입·판매 전문점",
  slogan: "최고가 매입, 최저가 판매",
  // 영업시간 (요일별)
  hours: {
    weekday: "평일 11:00 ~ 19:00",
    weekend: "주말·공휴일 13:00 ~ 19:30",
    closed: "매주 수요일·일요일 휴무",
  },
  phone: "010-2394-1420",
  services: [
    "중고폰 매입 / 판매",
    "서브폰 · 업무폰 판매",
    "알뜰폰 선불폰 · 후불폰 개통",
  ],
  notice: "파손폰, 약정폰, 안쓰던폰, 오래된 휴대폰도 모두 매입합니다.",
} as const;
