/**
 * 대인 TRADE 시세표(2026.6.17) 기반 매입가 데이터.
 * 모든 금액 단위는 "만원" (예: 64 = 64만원).
 * null = 해당 등급 매입 불가(X).
 *
 * 등급(grade): A / Aminus / Bplus / B / liquid(액파특가·바디B급) / used(중고)
 */

export type BuybackGrade = "A" | "Aminus" | "Bplus" | "B" | "liquid" | "used";

export const GRADE_LABELS: Record<BuybackGrade, string> = {
  A: "A급",
  Aminus: "A-급",
  Bplus: "B+급",
  B: "B급(잔기스)",
  liquid: "액파특가",
  used: "중고",
};

/** 등급별 매입가(만원). null이면 해당 등급 매입 불가 */
export interface GradePrices {
  A: number | null;
  Aminus: number | null;
  Bplus: number | null;
  B: number | null;
  liquid: number | null;
  used: number | null;
}

/** 옵션(상태) 차감액(만원). 양수로 적어두고 계산 시 빼는 방식 사용 */
export interface OptionDeduction {
  /** 액정 파손/기스 */
  liquidCrack: number;
  /** 후면(뒷판/카메라캡) 파손 */
  backGlass: number;
  /** LCD 파손(액정 불량) */
  lcd: number;
  /** 지문/페이스인식 불량 */
  biometrics: number;
  /** 카메라 불량 */
  camera: number;
  /** WIFI/나침반 등 기능 불량 */
  wifi: number;
  /** 약/중잔상 */
  burnInMid: number;
  /** 강잔상 */
  burnInStrong: number;
  /** LCD급(L급) 잔상 - 삼성 등에서 특가 미적용. 미정의 시 강잔상으로 대체 */
  burnInLcd?: number;
  /** LCD 파손 차감(별도) - 미정의 시 lcd 사용 */
  lcdDamage?: number;
}

export interface BuybackModel {
  /** 고유 키 */
  key: string;
  /** 제조사 */
  brand: "Apple" | "Samsung" | "LG";
  /** 표시 모델명 */
  model: string;
  /** 용량 옵션들과 등급가 */
  variants: { storage: string; prices: GradePrices }[];
  /** 옵션 차감 (모델 공통) */
  deductions: OptionDeduction;
  /** 배터리 최소 기준(%) - 등급가 적용 최소치. 미만이면 안내 */
  batteryMin: number;
}

const P = (
  A: number | null,
  Aminus: number | null,
  Bplus: number | null,
  B: number | null,
  liquid: number | null,
  used: number | null,
): GradePrices => ({ A, Aminus, Bplus, B, liquid, used });

const D = (
  liquidCrack: number,
  backGlass: number,
  lcd: number,
  biometrics: number,
  camera: number,
  wifi: number,
  burnInMid: number,
  burnInStrong: number,
  burnInLcd?: number,
  lcdDamage?: number,
): OptionDeduction => ({
  liquidCrack,
  backGlass,
  lcd,
  biometrics,
  camera,
  wifi,
  burnInMid,
  burnInStrong,
  burnInLcd,
  lcdDamage,
});

/**
 * 아이폰 매입가 데이터.
 * 잔상(burnInMid/Strong)은 시세표의 "잔상 차감" 표 기준.
 */
export const IPHONE_MODELS: BuybackModel[] = [
  {
    key: "iphone-se2", brand: "Apple", model: "아이폰 SE2", batteryMin: 83,
    variants: [
      { storage: "64GB", prices: P(13, 13, 12, null, null, 7) },
      { storage: "128/256GB", prices: P(14, 14, 13, null, null, 7) },
    ],
    deductions: D(1, 0, 2, 2.5, 2, 2, 0, 0),
  },
  {
    key: "iphone-se3", brand: "Apple", model: "아이폰 SE3", batteryMin: 83,
    variants: [
      { storage: "64GB", prices: P(21, 20, 19, null, null, 10) },
      { storage: "128/256GB", prices: P(22, 21, 20, null, null, 12) },
    ],
    deductions: D(1, 0, 3, 3.5, 3, 2, 0, 0),
  },
  {
    key: "iphone-8", brand: "Apple", model: "아이폰 8", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(9, 9, 8, null, null, 4.5) },
      { storage: "256GB", prices: P(10, 10, 9, null, null, 4.5) },
    ],
    deductions: D(0, 0, 2, 2.5, 2, 2, 0, 0),
  },
  {
    key: "iphone-8plus", brand: "Apple", model: "아이폰 8+", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(11, 11, 10, null, null, 4.5) },
      { storage: "256GB", prices: P(12, 12, 11, null, null, 4.5) },
    ],
    deductions: D(0, 0, 2, 2.5, 3, 2, 0, 0),
  },
  {
    key: "iphone-x", brand: "Apple", model: "아이폰 X", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(15, 13, 11, null, null, 7) },
      { storage: "256GB", prices: P(17, 15, 13, null, null, 7) },
    ],
    deductions: D(1, 0, 5, 2.5, 2.5, 3, 1.5, 3),
  },
  {
    key: "iphone-xr", brand: "Apple", model: "아이폰 XR", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(16, 14, 12, null, null, 10.5) },
      { storage: "128GB", prices: P(20, 18, 16, null, null, 11.5) },
      { storage: "256GB", prices: P(21, 19, 17, null, null, 12.5) },
    ],
    deductions: D(1, 0, 3, 2.5, 2.5, 3, 1.5, 3),
  },
  {
    key: "iphone-xs", brand: "Apple", model: "아이폰 XS", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(18, 16, 14, null, null, 7) },
      { storage: "256GB", prices: P(21, 19, 17, null, null, 7) },
      { storage: "512GB", prices: P(22, 20, 18, null, null, 7) },
    ],
    deductions: D(1, 0, 5, 2.5, 2.5, 3, 1.5, 3),
  },
  {
    key: "iphone-xsmax", brand: "Apple", model: "아이폰 XS MAX", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(24, 22, 20, null, null, 11) },
      { storage: "256GB", prices: P(28, 26, 24, null, null, 12) },
      { storage: "512GB", prices: P(29, 27, 25, null, null, 13) },
    ],
    deductions: D(1, 0, 8, 2.5, 2.5, 3, 2.5, 5),
  },
  {
    key: "iphone-11", brand: "Apple", model: "아이폰 11", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(21, 20, 17, null, null, 16) },
      { storage: "128GB", prices: P(24, 23, 20, null, null, 17) },
      { storage: "256GB", prices: P(25, 24, 21, null, null, 18) },
    ],
    deductions: D(1, 0, 3, 3, 3.5, 4, 0, 0),
  },
  {
    key: "iphone-11pro", brand: "Apple", model: "아이폰 11 PRO", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(24, 22, 19, null, null, 18) },
      { storage: "256GB", prices: P(27, 25, 22, null, null, 20) },
      { storage: "512GB", prices: P(28, 26, 23, null, null, 21) },
    ],
    deductions: D(1, 0, 4, 3, 3.5, 4, 3, 5),
  },
  {
    key: "iphone-11promax", brand: "Apple", model: "아이폰 11 PRO MAX", batteryMin: 80,
    variants: [
      { storage: "64GB", prices: P(31, 29, 26, null, null, 20) },
      { storage: "256GB", prices: P(34, 32, 29, null, null, 22) },
      { storage: "512GB", prices: P(35, 33, 30, null, null, 23) },
    ],
    deductions: D(1, 0, 9, 3, 3.5, 4, 4, 6),
  },
  {
    key: "iphone-12mini", brand: "Apple", model: "아이폰 12 MINI", batteryMin: 83,
    variants: [
      { storage: "64GB", prices: P(19, 16, 15, null, null, 11.5) },
      { storage: "128GB", prices: P(22, 19, 18, null, null, 13.5) },
      { storage: "256GB", prices: P(23, 20, 19, null, null, 14.5) },
    ],
    deductions: D(1, 0, 6.5, 3, 5, 5, 4, 7),
  },
  {
    key: "iphone-12", brand: "Apple", model: "아이폰 12", batteryMin: 83,
    variants: [
      { storage: "64GB", prices: P(25, 23, 20, 18, null, 17) },
      { storage: "128GB", prices: P(29, 27, 24, 20, null, 19) },
      { storage: "256GB", prices: P(30, 28, 25, 20, null, 19) },
    ],
    deductions: D(1, 0, 9, 3, 5, 5, 4, 7),
  },
  {
    key: "iphone-12pro", brand: "Apple", model: "아이폰 12 PRO", batteryMin: 83,
    variants: [
      { storage: "128GB", prices: P(37, 35, 32, 29, null, 25.5) },
      { storage: "256GB", prices: P(40, 38, 35, 31, null, 27.5) },
      { storage: "512GB", prices: P(41, 39, 36, 32, null, 28.5) },
    ],
    deductions: D(1, 0, 9, 3, 5, 5, 4, 7),
  },
  {
    key: "iphone-12promax", brand: "Apple", model: "아이폰 12 PRO MAX", batteryMin: 83,
    variants: [
      { storage: "128GB", prices: P(47, 45, 42, 35, 30, 28) },
      { storage: "256GB", prices: P(51, 49, 46, 38, 33, 31) },
      { storage: "512GB", prices: P(53, 51, 48, 39, 34, 32) },
    ],
    deductions: D(1, 0, 14.5, 3, 5, 5, 6, 10),
  },
  {
    key: "iphone-13mini", brand: "Apple", model: "아이폰 13 MINI", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(28, 25, 23, null, null, 22.5) },
      { storage: "256GB", prices: P(34, 31, 29, null, null, 26.5) },
      { storage: "512GB", prices: P(35, 32, 30, null, null, 27.5) },
    ],
    deductions: D(1, 0, 12, 5, 5, 5, 4, 8),
  },
  {
    key: "iphone-13", brand: "Apple", model: "아이폰 13", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(36, 33, 30, 29, null, 28.5) },
      { storage: "256GB", prices: P(41, 38, 35, 31, null, 30.5) },
      { storage: "512GB", prices: P(42, 39, 36, 32, null, 31.5) },
    ],
    deductions: D(1, 0, 9, 5, 5, 5, 4, 8),
  },
  {
    key: "iphone-13pro", brand: "Apple", model: "아이폰 13 PRO", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(46, 44, 41, 39, 36, 37) },
      { storage: "256GB", prices: P(52, 50, 47, 41, 38, 39) },
      { storage: "512GB", prices: P(53, 51, 48, 42, 39, 40) },
      { storage: "1TB", prices: P(54, 52, 49, 43, 40, 41) },
    ],
    deductions: D(1, 0, 14, 5, 5, 5, 6, 10),
  },
  {
    key: "iphone-13promax", brand: "Apple", model: "아이폰 13 PRO MAX", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(60, 58, 55, 48, 45, 42) },
      { storage: "256GB", prices: P(65, 63, 60, 52, 49, 46) },
      { storage: "512GB", prices: P(67, 65, 62, 53, 50, 47) },
      { storage: "1TB", prices: P(68, 66, 63, 54, 51, 48) },
    ],
    deductions: D(1, 0, 20, 5, 5, 5, 7, 13),
  },
  {
    key: "iphone-14", brand: "Apple", model: "아이폰 14", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(44, 42, 37, null, null, 33) },
      { storage: "256GB", prices: P(49, 47, 42, null, null, 36.5) },
      { storage: "512GB", prices: P(51, 49, 44, null, null, 37.5) },
    ],
    deductions: D(1, 0, 13, 7, 7, 6, 5, 10),
  },
  {
    key: "iphone-14plus", brand: "Apple", model: "아이폰 14 PLUS", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(47, 45, 42, 38.5, null, 36.5) },
      { storage: "256GB", prices: P(54, 52, 49, 42.5, null, 40.5) },
      { storage: "512GB", prices: P(55, 53, 50, 43.5, null, 41.5) },
    ],
    deductions: D(1, 0, 14, 7, 7, 6, 5, 10),
  },
  {
    key: "iphone-14pro", brand: "Apple", model: "아이폰 14 PRO", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(64, 59, 55, 50, 48, 51) },
      { storage: "256GB", prices: P(70, 65, 61, 54, 52, 55) },
      { storage: "512GB", prices: P(73, 68, 64, 55, 53, 56) },
      { storage: "1TB", prices: P(74, 69, 65, 56, 54, 57) },
    ],
    deductions: D(1, 0, 21, 7, 7, 6, 8, 17),
  },
  {
    key: "iphone-14promax", brand: "Apple", model: "아이폰 14 PRO MAX", batteryMin: 85,
    variants: [
      { storage: "128GB", prices: P(81, 76, 72, 65, 59, 61) },
      { storage: "256GB", prices: P(87, 82, 78, 70, 64, 66) },
      { storage: "512GB", prices: P(90, 85, 81, 71, 65, 67) },
      { storage: "1TB", prices: P(91, 86, 82, 72, 66, 68) },
    ],
    deductions: D(1, 0, 27, 7, 7, 6, 10, 20),
  },
  {
    key: "iphone-15", brand: "Apple", model: "아이폰 15", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(61, 58, 52, 50.5, null, 49.5) },
      { storage: "256GB", prices: P(69, 66, 60, 54.5, null, 53) },
      { storage: "512GB", prices: P(71, 68, 62, 56.5, null, 54) },
    ],
    deductions: D(1, 0, 16, 11, 11, 8, 7, 13),
  },
  {
    key: "iphone-15plus", brand: "Apple", model: "아이폰 15 PLUS", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(64, 60, 55, 54, null, 52) },
      { storage: "256GB", prices: P(74, 70, 65, 60, null, 58) },
      { storage: "512GB", prices: P(77, 73, 67, 60, null, 58) },
    ],
    deductions: D(1, 0, 19, 11, 11, 8, 7, 13),
  },
  {
    key: "iphone-15pro", brand: "Apple", model: "아이폰 15 PRO", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(81, 79, 75, 68, 64, 65.5) },
      { storage: "256GB", prices: P(90, 88, 84, 72, 68, 70.5) },
      { storage: "512GB", prices: P(93, 90, 85, 73, 69, 71.5) },
      { storage: "1TB", prices: P(94, 91, 86, 74, 70, 72.5) },
    ],
    deductions: D(1, 0, 25, 11, 11, 8, 11, 21),
  },
  {
    key: "iphone-15promax", brand: "Apple", model: "아이폰 15 PRO MAX", batteryMin: 87,
    variants: [
      { storage: "256GB", prices: P(101, 98, 93, 88, 83, 84) },
      { storage: "512GB", prices: P(106, 103, 98, 94, 89, 90) },
      { storage: "1TB", prices: P(111, 107, 101, 95, 90, 91) },
    ],
    deductions: D(1, 0, 31, 11, 11, 8, 13, 21),
  },
  {
    key: "iphone-16e", brand: "Apple", model: "아이폰 16E", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(52, 48, 45, 39, null, 38) },
      { storage: "256GB", prices: P(64, 60, 57, 43, null, 42) },
      { storage: "512GB", prices: P(74, 70, 67, 45, null, 44) },
    ],
    deductions: D(2, 0, 19, 15, 14, 10, 0, 0),
  },
  {
    key: "iphone-16", brand: "Apple", model: "아이폰 16", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(79, 76, 72, 68, 64, 65) },
      { storage: "256GB", prices: P(89, 86, 82, 75, 71, 72) },
      { storage: "512GB", prices: P(99, 96, 92, 76, 72, 73) },
    ],
    deductions: D(2, 0, 22, 15, 14, 10, 0, 0),
  },
  {
    key: "iphone-16plus", brand: "Apple", model: "아이폰 16 PLUS", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(85, 82, 79, 71, 64.5, 66) },
      { storage: "256GB", prices: P(95, 92, 89, 78, 72.5, 73) },
      { storage: "512GB", prices: P(105, 102, 99, 79, 73.5, 74) },
    ],
    deductions: D(2, 0, 24, 15, 14, 10, 0, 0),
  },
  {
    key: "iphone-16pro", brand: "Apple", model: "아이폰 16 PRO", batteryMin: 87,
    variants: [
      { storage: "128GB", prices: P(99, 96, 92, 85, 79, 80) },
      { storage: "256GB", prices: P(109, 106, 102, 92, 86, 89) },
      { storage: "512GB", prices: P(117, 114, 110, 93, 87, 90) },
      { storage: "1TB", prices: P(119, 116, 112, 95, 89, 92) },
    ],
    deductions: D(2, 0, 28, 15, 14, 10, 0, 0),
  },
  {
    key: "iphone-16promax", brand: "Apple", model: "아이폰 16 PRO MAX", batteryMin: 87,
    variants: [
      { storage: "256GB", prices: P(126, 123, 119, 113, 106, 103) },
      { storage: "512GB", prices: P(139, 136, 132, 121, 114, 111) },
      { storage: "1TB", prices: P(154, 151, 147, 122, 115, 113) },
    ],
    deductions: D(2, 0, 35, 15, 14, 12, 0, 0),
  },
  {
    key: "iphone-17", brand: "Apple", model: "아이폰 17", batteryMin: 90,
    variants: [
      { storage: "256GB", prices: P(99, 96, 93, 85, 78, 78) },
      { storage: "512GB", prices: P(108, 105, 102, 95, 88, 88) },
    ],
    deductions: D(5, 4, 35, 20, 20, 20, 0, 0),
  },
  {
    key: "iphone-17air", brand: "Apple", model: "아이폰 17 AIR", batteryMin: 90,
    variants: [
      { storage: "256GB", prices: P(99, 96, 93, 85, 77, 77) },
      { storage: "512GB", prices: P(108, 105, 102, 95, 87, 87) },
      { storage: "1TB", prices: P(116, 113, 110, 100, 92, 92) },
    ],
    deductions: D(5, 4, 35, 20, 20, 20, 0, 0),
  },
  {
    key: "iphone-17pro", brand: "Apple", model: "아이폰 17 PRO", batteryMin: 90,
    variants: [
      { storage: "256GB", prices: P(152, 149, 145, 125, 110, 107) },
      { storage: "512GB", prices: P(166, 163, 159, 135, 120, 117) },
      { storage: "1TB", prices: P(180, 177, 173, 145, 130, 127) },
    ],
    deductions: D(5, 4, 45, 20, 20, 20, 0, 0),
  },
  {
    key: "iphone-17promax", brand: "Apple", model: "아이폰 17 PRO MAX", batteryMin: 90,
    variants: [
      { storage: "256GB", prices: P(173, 170, 166, 160, 150, 147) },
      { storage: "512GB", prices: P(188, 185, 181, 165, 155, 152) },
      { storage: "1TB", prices: P(205, 202, 198, 170, 160, 157) },
    ],
    deductions: D(5, 4, 55, 20, 20, 20, 0, 0),
  },
];

export const ALL_IPHONE_MODELS: BuybackModel[] = [...IPHONE_MODELS];
