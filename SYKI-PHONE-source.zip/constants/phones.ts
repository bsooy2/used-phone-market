import { Grade, GradeInfo, Phone } from "./types";

export const GRADE_INFO: Record<Grade, GradeInfo> = {
  S: { label: "S급", color: "#16A34A", description: "미사용에 가까운 최상급" },
  A: { label: "A급", color: "#2563EB", description: "생활기스 거의 없는 상급" },
  B: { label: "B급", color: "#F59E0B", description: "사용감 있는 보통 상태" },
  C: { label: "C급", color: "#EF4444", description: "기스/흠집 있는 중하급" },
};

// 매물 시드 데이터 (구매용)
export const PHONES: Phone[] = [
  {
    id: "p1",
    brand: "Apple",
    model: "iPhone 15 Pro",
    storage: "256GB",
    color: "내추럴 티타늄",
    grade: "S",
    battery: 99,
    price: 1090000,
    buyPrice: 980000,
    image: "#1F2937",
    description: "정품 미개봉에 가까운 최상급 상태입니다. 액정/외관 모두 깨끗합니다.",
    accessories: "본체, 정품 케이블",
    createdAt: "2026-06-08",
  },
  {
    id: "p2",
    brand: "Samsung",
    model: "Galaxy S24 Ultra",
    storage: "512GB",
    color: "티타늄 블랙",
    grade: "A",
    battery: 95,
    price: 960000,
    buyPrice: 850000,
    image: "#111827",
    description: "S펜 정상, 생활기스 약간 있으나 전반적으로 깨끗합니다.",
    accessories: "본체, S펜, 박스",
    createdAt: "2026-06-08",
  },
  {
    id: "p3",
    brand: "Apple",
    model: "iPhone 14",
    storage: "128GB",
    color: "미드나이트",
    grade: "A",
    battery: 91,
    price: 620000,
    buyPrice: 540000,
    image: "#1E293B",
    description: "배터리 효율 양호, 액정 흠집 없음. 케이스 착용 사용했습니다.",
    accessories: "본체만",
    createdAt: "2026-06-07",
  },
  {
    id: "p4",
    brand: "Samsung",
    model: "Galaxy Z Flip5",
    storage: "256GB",
    color: "민트",
    grade: "B",
    battery: 88,
    price: 540000,
    buyPrice: 460000,
    image: "#0F766E",
    description: "힌지 정상 작동, 외관 사용감 있습니다. 정상 작동 확인했습니다.",
    accessories: "본체, 충전기",
    createdAt: "2026-06-07",
  },
  {
    id: "p5",
    brand: "Apple",
    model: "iPhone 13 mini",
    storage: "128GB",
    color: "스타라이트",
    grade: "B",
    battery: 85,
    price: 410000,
    buyPrice: 340000,
    image: "#334155",
    description: "소형 모델 선호자에게 추천. 하단 미세 기스 있습니다.",
    accessories: "본체만",
    createdAt: "2026-06-06",
  },
  {
    id: "p6",
    brand: "Samsung",
    model: "Galaxy S23",
    storage: "256GB",
    color: "라벤더",
    grade: "S",
    battery: 97,
    price: 560000,
    buyPrice: 490000,
    image: "#6D28D9",
    description: "여성 사용자가 깔끔하게 사용한 상품입니다. 거의 새것 수준.",
    accessories: "본체, 박스, 충전기",
    createdAt: "2026-06-06",
  },
  {
    id: "p7",
    brand: "Apple",
    model: "iPhone 12",
    storage: "64GB",
    color: "블루",
    grade: "C",
    battery: 79,
    price: 290000,
    buyPrice: 230000,
    image: "#1D4ED8",
    description: "모서리 흠집과 후면 미세 크랙 있으나 사용에 지장 없습니다.",
    accessories: "본체만",
    createdAt: "2026-06-05",
  },
  {
    id: "p8",
    brand: "Samsung",
    model: "Galaxy A54",
    storage: "128GB",
    color: "그래파이트",
    grade: "A",
    battery: 93,
    price: 320000,
    buyPrice: 260000,
    image: "#374151",
    description: "보급형 인기 모델, 상태 양호합니다. 세컨폰으로 추천.",
    accessories: "본체, 충전기",
    createdAt: "2026-06-05",
  },
];

// 판매 시세표: 모델별 기본 매입가 (상태 S 기준)
export type ModelPrice = {
  brand: string;
  model: string;
  storages: { storage: string; basePrice: number }[];
};

export const SELL_PRICE_TABLE: ModelPrice[] = [
  {
    brand: "Apple",
    model: "iPhone 15 Pro Max",
    storages: [
      { storage: "256GB", basePrice: 1180000 },
      { storage: "512GB", basePrice: 1320000 },
    ],
  },
  {
    brand: "Apple",
    model: "iPhone 15 Pro",
    storages: [
      { storage: "128GB", basePrice: 980000 },
      { storage: "256GB", basePrice: 1080000 },
    ],
  },
  {
    brand: "Apple",
    model: "iPhone 15",
    storages: [
      { storage: "128GB", basePrice: 780000 },
      { storage: "256GB", basePrice: 860000 },
    ],
  },
  {
    brand: "Apple",
    model: "iPhone 14",
    storages: [
      { storage: "128GB", basePrice: 560000 },
      { storage: "256GB", basePrice: 640000 },
    ],
  },
  {
    brand: "Apple",
    model: "iPhone 13",
    storages: [
      { storage: "128GB", basePrice: 430000 },
      { storage: "256GB", basePrice: 500000 },
    ],
  },
  {
    brand: "Samsung",
    model: "Galaxy S24 Ultra",
    storages: [
      { storage: "256GB", basePrice: 920000 },
      { storage: "512GB", basePrice: 1020000 },
    ],
  },
  {
    brand: "Samsung",
    model: "Galaxy S24",
    storages: [
      { storage: "256GB", basePrice: 640000 },
      { storage: "512GB", basePrice: 720000 },
    ],
  },
  {
    brand: "Samsung",
    model: "Galaxy Z Flip5",
    storages: [
      { storage: "256GB", basePrice: 540000 },
      { storage: "512GB", basePrice: 620000 },
    ],
  },
  {
    brand: "Samsung",
    model: "Galaxy S23",
    storages: [
      { storage: "256GB", basePrice: 500000 },
      { storage: "512GB", basePrice: 560000 },
    ],
  },
];

export const BRANDS = ["Apple", "Samsung"];

// 가격 포맷
export function formatPrice(price: number): string {
  return price.toLocaleString("ko-KR") + "원";
}

// 인기 모델 (홈 가로 스크롤용)
export const POPULAR_MODELS = [
  { brand: "Apple", model: "iPhone 15 Pro", maxBuy: 1080000, image: "#1F2937" },
  { brand: "Samsung", model: "Galaxy S24 Ultra", maxBuy: 1020000, image: "#111827" },
  { brand: "Apple", model: "iPhone 14", maxBuy: 640000, image: "#1E293B" },
  { brand: "Samsung", model: "Galaxy S23", maxBuy: 560000, image: "#6D28D9" },
];
