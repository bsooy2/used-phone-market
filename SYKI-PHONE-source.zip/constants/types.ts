export type Grade = "S" | "A" | "B" | "C";

export type Phone = {
  id: string;
  brand: string; // Apple, Samsung 등
  model: string; // iPhone 15 Pro 등
  storage: string; // 128GB
  color: string;
  grade: Grade; // 상태 등급
  battery: number; // 배터리 효율 %
  price: number; // 판매가 (원)
  buyPrice: number; // 매입가(참고)
  image: string; // 이미지 키워드/색상
  /** 관리자 등록 매물 사진 URL/URI 목록 */
  photos?: string[];
  description: string;
  accessories: string; // 구성품
  createdAt: string;
  sellerId?: string; // 등록한 판매자 ID (시드 데이터는 undefined = 공식 매물)
  sellerName?: string; // 등록자 닉네임
  /** 공식 매물의 누적 상세 조회수 */
  viewCount?: number;
  /** 공식 매물의 누적 찜 횟수 */
  favoriteCount?: number;
};

export type SellRequest = {
  id: string;
  brand: string;
  model: string;
  storage: string;
  /** 선택 등급 라벨 (예: "A급", "B+급") */
  gradeLabel?: string;
  /** 선택한 상태 옵션 라벨 목록 */
  conditionLabels?: string[];
  /** IMEI 번호 (15자리) */
  imei?: string;
  /** IMEI로 조회된 기기 정보 */
  imeiDeviceInfo?: { brand: string; model: string };
  /** 첨부된 기기 사진 URI 배열 (최대 4장) */
  images?: string[];
  /** 동의 내역 */
  agreements?: {
    privacy: boolean;
    tradeTerms: boolean;
    notStolen: boolean;
    agreedAt: string;
  };
  estimatedPrice: number;
  status: "접수" | "검수중" | "입금완료";
  createdAt: string;
  /** 관리자 보관함으로 이동한 시각. 고객의 신청 내역에는 계속 유지된다. */
  archivedAt?: string;
};

export type Order = {
  id: string; // orderId
  productId: string;
  productName: string;
  amount: number;
  method: "card" | "transfer" | "kakaopay" | "naverpay";
  status: "결제완료" | "배송준비" | "배송중" | "배송완료";
  buyerId: string;
  receiptId: string;
  createdAt: string;
};

export type NotificationKind = "order" | "sell" | "system";

export type AppNotification = {
  id: string;
  kind: NotificationKind;
  title: string;
  body: string;
  userId: string; // 수신 대상 사용자 ID
  refId?: string; // 관련 주문/판매 ID
  read: boolean;
  createdAt: string;
};

export type GradeInfo = {
  label: string;
  color: string; // hex
  description: string;
};
