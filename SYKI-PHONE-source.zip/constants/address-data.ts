/**
 * 우편번호/주소 검색용 로컬 데이터.
 * 외부 API 키 없이 동작하도록 대표적인 도로명 주소 샘플을 내장한다.
 * (실서비스 전환 시 행정안전부 도로명주소 API 또는 카카오 주소 검색 API로 교체 가능)
 */
export type AddressItem = {
  zipcode: string; // 우편번호 (5자리)
  road: string; // 도로명 주소
  jibun: string; // 지번 주소
  region: string; // 시/도 + 시군구 (검색 보조)
};

export const ADDRESS_DB: AddressItem[] = [
  // 제주 서귀포 (시끼폰 매장 지역 위주)
  { zipcode: "63591", road: "제주특별자치도 서귀포시 중앙로 105", jibun: "서귀포시 서귀동 314-1", region: "제주 서귀포시" },
  { zipcode: "63565", road: "제주특별자치도 서귀포시 중정로 67", jibun: "서귀포시 서귀동 277", region: "제주 서귀포시" },
  { zipcode: "63601", road: "제주특별자치도 서귀포시 일주동로 8593", jibun: "서귀포시 동홍동 1565", region: "제주 서귀포시" },
  { zipcode: "63309", road: "제주특별자치도 제주시 첨단로 242", jibun: "제주시 영평동 2181", region: "제주 제주시" },
  { zipcode: "63122", road: "제주특별자치도 제주시 연동 1435", jibun: "제주시 연동 261-13", region: "제주 제주시" },
  // 서울
  { zipcode: "06236", road: "서울특별시 강남구 테헤란로 152", jibun: "강남구 역삼동 737", region: "서울 강남구" },
  { zipcode: "06164", road: "서울특별시 강남구 영동대로 511", jibun: "강남구 삼성동 159", region: "서울 강남구" },
  { zipcode: "04524", road: "서울특별시 중구 세종대로 110", jibun: "중구 태평로1가 31", region: "서울 중구" },
  { zipcode: "03187", road: "서울특별시 종로구 세종대로 175", jibun: "종로구 세종로 81-3", region: "서울 종로구" },
  { zipcode: "07327", road: "서울특별시 영등포구 여의대로 108", jibun: "영등포구 여의도동 23", region: "서울 영등포구" },
  { zipcode: "04637", road: "서울특별시 중구 을지로 281", jibun: "중구 을지로7가 22", region: "서울 중구" },
  { zipcode: "05551", road: "서울특별시 송파구 올림픽로 300", jibun: "송파구 신천동 29", region: "서울 송파구" },
  { zipcode: "08380", road: "서울특별시 구로구 디지털로 300", jibun: "구로구 구로동 197", region: "서울 구로구" },
  { zipcode: "03925", road: "서울특별시 마포구 월드컵북로 396", jibun: "마포구 상암동 1602", region: "서울 마포구" },
  // 경기
  { zipcode: "13529", road: "경기도 성남시 분당구 판교역로 235", jibun: "성남시 분당구 삼평동 681", region: "경기 성남시" },
  { zipcode: "16677", road: "경기도 수원시 영통구 광교로 145", jibun: "수원시 영통구 이의동 1268", region: "경기 수원시" },
  { zipcode: "10402", road: "경기도 고양시 일산동구 중앙로 1275", jibun: "고양시 일산동구 장항동 888", region: "경기 고양시" },
  { zipcode: "14523", road: "경기도 부천시 길주로 210", jibun: "부천시 중동 1156", region: "경기 부천시" },
  // 인천
  { zipcode: "21999", road: "인천광역시 연수구 컨벤시아대로 165", jibun: "연수구 송도동 24-5", region: "인천 연수구" },
  { zipcode: "22382", road: "인천광역시 중구 공항로 272", jibun: "중구 운서동 2851", region: "인천 중구" },
  // 부산
  { zipcode: "48058", road: "부산광역시 해운대구 센텀중앙로 79", jibun: "해운대구 우동 1495", region: "부산 해운대구" },
  { zipcode: "47545", road: "부산광역시 연제구 중앙대로 1001", jibun: "연제구 연산동 1000", region: "부산 연제구" },
  // 대구/대전/광주/울산
  { zipcode: "41911", road: "대구광역시 중구 공평로 88", jibun: "중구 동인동1가 2", region: "대구 중구" },
  { zipcode: "35229", road: "대전광역시 서구 둔산로 100", jibun: "서구 둔산동 1420", region: "대전 서구" },
  { zipcode: "61945", road: "광주광역시 서구 내방로 111", jibun: "서구 치평동 1200", region: "광주 서구" },
  { zipcode: "44538", road: "울산광역시 중구 종가로 345", jibun: "중구 성안동 543", region: "울산 중구" },
];

/** 검색어로 주소 후보를 찾는다. 도로명/지번/지역/우편번호 부분 일치. */
export function searchAddress(query: string): AddressItem[] {
  const q = query.trim().toLowerCase();
  if (q.length < 1) return [];
  return ADDRESS_DB.filter((a) => {
    return (
      a.road.toLowerCase().includes(q) ||
      a.jibun.toLowerCase().includes(q) ||
      a.region.toLowerCase().includes(q) ||
      a.zipcode.includes(q)
    );
  }).slice(0, 30);
}
