import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const gradlePath = resolve("android/app/build.gradle");
const requiredVariables = ["CM_KEYSTORE_PATH", "CM_KEYSTORE_PASSWORD", "CM_KEY_ALIAS", "CM_KEY_PASSWORD"];

if (!existsSync(gradlePath)) {
  throw new Error("Android project was not generated. Run Expo prebuild before configuring signing.");
}

if (!requiredVariables.every((name) => process.env[name])) {
  console.log("No Codemagic keystore is configured. Building an unsigned test artifact only.");
  process.exit(0);
}

let source = readFileSync(gradlePath, "utf8");
const marker = "// SYKI_CODEMAGIC_RELEASE_SIGNING";
if (source.includes(marker)) {
  console.log("Codemagic Android signing is already configured.");
  process.exit(0);
}

const releaseSigning = `
    ${marker}
    release {
        storeFile file(System.getenv("CM_KEYSTORE_PATH"))
        storePassword System.getenv("CM_KEYSTORE_PASSWORD")
        keyAlias System.getenv("CM_KEY_ALIAS")
        keyPassword System.getenv("CM_KEY_PASSWORD")
    }
`;

if (source.includes("signingConfigs {")) {
  source = source.replace("signingConfigs {", `signingConfigs {${releaseSigning}`);
} else if (source.includes("buildTypes {")) {
  source = source.replace("buildTypes {", `signingConfigs {${releaseSigning}    }

    buildTypes {`);
} else {
  throw new Error("Could not locate Android signing configuration in build.gradle.");
}

source = source.replace(/(release\s*\{[\s\S]*?)signingConfig signingConfigs\.debug/, "$1signingConfig signingConfigs.release");
writeFileSync(gradlePath, source);
console.log("Codemagic release signing has been configured.");
