/** @type {const} */
const themeColors = {
  // 블랙 앤 화이트 톤. primary = 블랙(라이트) / 화이트(다크)
  primary: { light: '#111111', dark: '#FFFFFF' },
  background: { light: '#FFFFFF', dark: '#0A0A0A' },
  surface: { light: '#F4F4F5', dark: '#161616' },
  foreground: { light: '#0A0A0A', dark: '#F5F5F5' },
  muted: { light: '#6B6B6B', dark: '#9A9A9A' },
  border: { light: '#E4E4E7', dark: '#2A2A2A' },
  success: { light: '#1F1F1F', dark: '#E5E5E5' },
  warning: { light: '#4B4B4B', dark: '#C8C8C8' },
  error: { light: '#000000', dark: '#FFFFFF' },
};

module.exports = { themeColors };
