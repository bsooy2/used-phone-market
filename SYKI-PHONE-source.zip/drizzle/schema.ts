import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** 앱에서 수집한 Expo 푸시 토큰. 거래 문의 답변 알림 전송에 사용한다. */
export const devicePushTokens = mysqlTable("device_push_tokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: varchar("userId", { length: 96 }).notNull(),
  token: varchar("token", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DevicePushToken = typeof devicePushTokens.$inferSelect;

/**
 * 매물(중고폰) 테이블.
 * 사장님(관리자)이 등록/수정/삭제하며, 모든 사용자에게 공유된다.
 */
export const listings = mysqlTable("listings", {
  id: int("id").autoincrement().primaryKey(),
  brand: varchar("brand", { length: 64 }).notNull(), // Apple, Samsung 등
  model: varchar("model", { length: 128 }).notNull(),
  storage: varchar("storage", { length: 32 }).notNull(), // 128GB
  color: varchar("color", { length: 64 }).notNull(),
  grade: mysqlEnum("grade", ["S", "A", "B", "C"]).default("A").notNull(), // 상태 등급
  battery: int("battery").default(100).notNull(), // 배터리 효율 %
  price: int("price").notNull(), // 판매가 (원)
  buyPrice: int("buyPrice").default(0).notNull(), // 매입가(참고)
  image: varchar("image", { length: 32 }).default("#1F2937").notNull(), // 카드 배경 색상 hex
  photos: text("photos"), // JSON 배열 문자열 - 매물 사진 URL 목록
  description: text("description"),
  accessories: varchar("accessories", { length: 255 }).default("본체만").notNull(), // 구성품
  sold: int("sold").default(0).notNull(), // 0=판매중, 1=판매완료
  viewCount: int("viewCount").default(0).notNull(), // 상세 조회수
  favoriteCount: int("favoriteCount").default(0).notNull(), // 찜 횟수
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Listing = typeof listings.$inferSelect;
export type InsertListing = typeof listings.$inferInsert;

/**
 * 앱 메타데이터(키-값) 테이블.
 * 예: "listings_seeded" 플래그를 저장해 시드 데이터 재생성을 막는다.
 */
export const appMeta = mysqlTable("app_meta", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: varchar("value", { length: 255 }).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AppMeta = typeof appMeta.$inferSelect;
export type InsertAppMeta = typeof appMeta.$inferInsert;
