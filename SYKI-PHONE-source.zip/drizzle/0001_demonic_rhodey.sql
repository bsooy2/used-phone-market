CREATE TABLE `listings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`brand` varchar(64) NOT NULL,
	`model` varchar(128) NOT NULL,
	`storage` varchar(32) NOT NULL,
	`color` varchar(64) NOT NULL,
	`grade` enum('S','A','B','C') NOT NULL DEFAULT 'A',
	`battery` int NOT NULL DEFAULT 100,
	`price` int NOT NULL,
	`buyPrice` int NOT NULL DEFAULT 0,
	`image` varchar(32) NOT NULL DEFAULT '#1F2937',
	`description` text,
	`accessories` varchar(255) NOT NULL DEFAULT '본체만',
	`sold` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `listings_id` PRIMARY KEY(`id`)
);
