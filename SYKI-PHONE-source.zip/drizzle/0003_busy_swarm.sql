ALTER TABLE `listings` ADD `viewCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `listings` ADD `favoriteCount` int DEFAULT 0 NOT NULL;
