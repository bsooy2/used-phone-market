CREATE TABLE `app_meta` (
	`key` varchar(64) NOT NULL,
	`value` varchar(255) NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `app_meta_key` PRIMARY KEY(`key`)
);
