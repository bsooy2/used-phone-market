import { describe, expect, it } from "vitest";

import { SellRequest } from "../constants/types";
import { archiveSellRequests, deleteSellRequests, restoreSellRequests } from "../lib/sell-request-management";

const requests: SellRequest[] = [
  { id: "quote-1", brand: "Apple", model: "iPhone 15", storage: "128GB", estimatedPrice: 800000, status: "접수", createdAt: "2026-08-15" },
  { id: "quote-2", brand: "Samsung", model: "Galaxy S24", storage: "256GB", estimatedPrice: 700000, status: "검수중", createdAt: "2026-08-15" },
];

describe("견적 신청 보관·삭제 관리", () => {
  it("선택한 신청만 보관 처리한다", () => {
    const archived = archiveSellRequests(requests, ["quote-2"], "2026-08-16T10:00:00.000Z");
    expect(archived[0].archivedAt).toBeUndefined();
    expect(archived[1].archivedAt).toBe("2026-08-16T10:00:00.000Z");
  });

  it("보관한 신청을 일반 목록으로 복원한다", () => {
    const archived = archiveSellRequests(requests, ["quote-1"], "2026-08-16T10:00:00.000Z");
    expect(restoreSellRequests(archived, ["quote-1"])[0].archivedAt).toBeUndefined();
  });

  it("선택한 신청만 영구 삭제한다", () => {
    expect(deleteSellRequests(requests, ["quote-1"])).toEqual([requests[1]]);
  });
});
