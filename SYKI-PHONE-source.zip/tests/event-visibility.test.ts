import { describe, expect, it } from "vitest";
import { isEventVisible } from "../lib/event-visibility";

const now = new Date("2026-08-18T12:00:00.000Z");

describe("이벤트 유효기간 노출 규칙", () => {
  it("활성화되고 기간 내인 이벤트를 노출한다", () => {
    expect(isEventVisible({ active: true, startDate: "2026-08-01T00:00:00.000Z", endDate: "2026-08-31T23:59:59.999Z" }, now)).toBe(true);
  });

  it("시작일 전 또는 종료일 후 이벤트를 숨긴다", () => {
    expect(isEventVisible({ active: true, startDate: "2026-08-19T00:00:00.000Z" }, now)).toBe(false);
    expect(isEventVisible({ active: true, endDate: "2026-08-17T23:59:59.999Z" }, now)).toBe(false);
  });

  it("비활성 이벤트를 숨긴다", () => {
    expect(isEventVisible({ active: false }, now)).toBe(false);
  });
});
