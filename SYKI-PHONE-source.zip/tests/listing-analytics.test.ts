import { describe, expect, it } from "vitest";
import { getListingAnalyticsSummary, rankListingPopularity } from "../lib/listing-analytics";
import type { Phone } from "../constants/types";

const base = (id: string, views: number, favorites: number): Phone => ({
  id, brand: "Apple", model: id, storage: "128GB", color: "블랙", grade: "A", battery: 90,
  price: 500_000, buyPrice: 400_000, image: "#111", description: "", accessories: "본체", createdAt: "2026-01-01",
  viewCount: views, favoriteCount: favorites,
});

describe("매물 조회·찜 분석", () => {
  it("조회수 우선, 찜 횟수 보조 기준으로 인기 매물을 정렬한다", () => {
    const ranked = rankListingPopularity([base("A", 5, 1), base("B", 5, 3), base("C", 7, 0)]);
    expect(ranked.map((item) => item.id)).toEqual(["C", "B", "A"]);
  });

  it("통계 합계를 정확히 계산하고 음수 값은 0으로 보정한다", () => {
    const rows = rankListingPopularity([base("A", 5, 1), base("B", -2, 3)]);
    expect(getListingAnalyticsSummary(rows)).toEqual({ totalViews: 5, totalFavorites: 4 });
  });
});
