import { describe, expect, it } from "vitest";

import {
  CONSUMER_PRICE_RATE,
  ServerListing,
  mapServerListings,
  parseListingPhotos,
  phoneIdToServerId,
  serverListingToPhone,
  toConsumerPrice,
} from "../lib/listing-adapter";

const sample: ServerListing = {
  id: 7,
  brand: "Apple",
  model: "iPhone 14",
  storage: "128GB",
  color: "미드나이트",
  grade: "A",
  battery: 91,
  price: 620000,
  buyPrice: 540000,
  image: "#1E293B",
  description: "양호한 상태",
  accessories: "본체만",
  sold: 0,
  createdAt: "2026-06-17T01:57:01.000Z",
  updatedAt: "2026-06-17T01:57:01.000Z",
};

describe("serverListingToPhone", () => {
  it("서버 매물을 Phone 타입으로 변환하고 id에 srv_ 접두사를 붙인다", () => {
    const phone = serverListingToPhone(sample);
    expect(phone.id).toBe("srv_7");
    expect(phone.model).toBe("iPhone 14");
    // 20% 인하 제거: 원본가 620000이 그대로 표시된다
    expect(phone.price).toBe(620000);
    expect(phone.sellerName).toBe("시끼폰");
    expect(phone.sellerId).toBeUndefined();
  });

  it("createdAt을 YYYY-MM-DD 형식으로 변환한다", () => {
    const phone = serverListingToPhone(sample);
    expect(phone.createdAt).toBe("2026-06-17");
  });

  it("description이 null이면 빈 문자열로 변환한다", () => {
    const phone = serverListingToPhone({ ...sample, description: null });
    expect(phone.description).toBe("");
  });

  it("저장된 사진 JSON을 Phone의 사진 목록으로 전달한다", () => {
    const phone = serverListingToPhone({
      ...sample,
      photos: '["https://cdn.example.com/front.jpg", "https://cdn.example.com/back.jpg"]',
    });
    expect(phone.photos).toEqual([
      "https://cdn.example.com/front.jpg",
      "https://cdn.example.com/back.jpg",
    ]);
  });
});

describe("parseListingPhotos", () => {
  it("빈 값 또는 잘못된 JSON은 빈 사진 목록으로 처리한다", () => {
    expect(parseListingPhotos(null)).toEqual([]);
    expect(parseListingPhotos("not-json")).toEqual([]);
    expect(parseListingPhotos('{"photo":"https://cdn.example.com/a.jpg"}')).toEqual([]);
  });

  it("문자열이 아닌 사진 항목과 빈 항목은 제거한다", () => {
    expect(parseListingPhotos('["https://cdn.example.com/a.jpg", "", 12, null]')).toEqual([
      "https://cdn.example.com/a.jpg",
    ]);
  });
});

describe("toConsumerPrice (20% 인하 제거)", () => {
  it("소비자 비율은 1이다(원본가 그대로)", () => {
    expect(CONSUMER_PRICE_RATE).toBe(1);
  });

  it("원본 가격을 그대로 반환한다", () => {
    expect(toConsumerPrice(1000000)).toBe(1000000);
    expect(toConsumerPrice(620000)).toBe(620000);
  });

  it("0원은 0원으로 유지된다", () => {
    expect(toConsumerPrice(0)).toBe(0);
  });
});

describe("phoneIdToServerId", () => {
  it("srv_ 접두사 id에서 숫자 id를 추출한다", () => {
    expect(phoneIdToServerId("srv_42")).toBe(42);
  });

  it("서버 매물이 아닌 id(user_, seed)는 null을 반환한다", () => {
    expect(phoneIdToServerId("user_1700000000000")).toBeNull();
    expect(phoneIdToServerId("p1")).toBeNull();
  });
});

describe("mapServerListings", () => {
  it("여러 매물을 일괄 변환한다", () => {
    const rows: ServerListing[] = [sample, { ...sample, id: 8, model: "Galaxy A54" }];
    const phones = mapServerListings(rows);
    expect(phones).toHaveLength(2);
    expect(phones[0].id).toBe("srv_7");
    expect(phones[1].id).toBe("srv_8");
    expect(phones[1].model).toBe("Galaxy A54");
  });

  it("빈 배열을 안전하게 처리한다", () => {
    expect(mapServerListings([])).toEqual([]);
  });
});
