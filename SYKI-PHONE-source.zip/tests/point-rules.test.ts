import { describe, expect, it } from "vitest";
import { calculatePurchasePoints, isValidPointRedemption, maxRedeemablePoints } from "../lib/point-rules";

describe("포인트 적립·사용 규칙", () => {
  it("상품 실결제금액의 2%를 적립한다", () => {
    expect(calculatePurchasePoints(500_000)).toBe(10_000);
    expect(calculatePurchasePoints(459_900)).toBe(9_198);
    expect(calculatePurchasePoints(0)).toBe(0);
  });

  it("사용 가능 최대 포인트를 천원 단위로 제한한다", () => {
    expect(maxRedeemablePoints(12_700, 100_000)).toBe(12_000);
    expect(maxRedeemablePoints(80_000, 35_900)).toBe(35_000);
  });

  it("천원 단위이며 보유량과 상품 금액 이하일 때만 사용할 수 있다", () => {
    expect(isValidPointRedemption(10_000, 12_700, 100_000)).toBe(true);
    expect(isValidPointRedemption(10_500, 12_700, 100_000)).toBe(false);
    expect(isValidPointRedemption(13_000, 12_700, 100_000)).toBe(false);
  });
});
