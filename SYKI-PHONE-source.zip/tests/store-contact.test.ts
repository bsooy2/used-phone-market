import { describe, expect, it } from "vitest";

import { makeStoreTelUrl } from "../lib/store-contact";

describe("makeStoreTelUrl", () => {
  it("하이픈이 포함된 매장 전화번호를 tel URL로 변환한다", () => {
    expect(makeStoreTelUrl("010-2394-1420")).toBe("tel:01023941420");
  });

  it("공백과 괄호 등 전화번호 구분 문자를 제거한다", () => {
    expect(makeStoreTelUrl("(02) 1234-5678")).toBe("tel:0212345678");
  });
});
