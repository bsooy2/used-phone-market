import { describe, expect, it } from "vitest";

// 실제 SOLAPI 계정·실행 서버가 모두 준비된 환경에서만 명시적으로 실행한다.
// 예: VITEST_VERIFY_SOLAPI=true pnpm vitest run tests/solapi-credentials.test.ts
const integrationIt = process.env.VITEST_VERIFY_SOLAPI === "true" ? it : it.skip;

describe("SOLAPI 발송 계정", () => {
  integrationIt("실행 중인 서버에서 SOLAPI 잔액 조회를 인증한다", async () => {
    const response = await fetch("http://127.0.0.1:3000/api/trpc/sms.health?input=%7B%22json%22%3Anull%7D");
    expect(response.ok).toBe(true);
    const data = await response.json() as { result?: { data?: { json?: { ok?: boolean; status?: number | null } } } };
    expect(data.result?.data?.json?.ok).toBe(true);
    expect(data.result?.data?.json?.status).toBe(200);
  }, 15_000);
});
