import { beforeAll, describe, expect, it } from "vitest";

/**
 * 관리자 PIN 검증 API 통합 테스트.
 * 개발 서버(API: 3000)가 실행 중일 때, 설정된 ADMIN_PIN(246810)으로
 * verifyPin 엔드포인트가 정상 동작하는지 검증한다.
 */
const API_BASE = "http://127.0.0.1:3000";
let apiAvailable = false;

async function verifyPin(pin: string): Promise<boolean> {
  const res = await fetch(`${API_BASE}/api/trpc/listings.verifyPin`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ json: { pin } }),
  });
  const data = await res.json();
  return data?.result?.data?.json?.ok === true;
}

describe("관리자 PIN 검증 API", () => {
  beforeAll(async () => {
    try {
      const response = await fetch(`${API_BASE}/api/trpc/listings.list`);
      apiAvailable = response.ok;
    } catch {
      apiAvailable = false;
    }
  });

  it("올바른 PIN(246810)은 통과한다", async (context) => {
    if (!apiAvailable) return context.skip();
    const ok = await verifyPin("246810");
    expect(ok).toBe(true);
  });

  it("잘못된 PIN(000000)은 거부된다", async (context) => {
    if (!apiAvailable) return context.skip();
    const ok = await verifyPin("000000");
    expect(ok).toBe(false);
  });

  it("매물 목록 API가 시드 데이터를 반환한다", async (context) => {
    if (!apiAvailable) return context.skip();
    const res = await fetch(`${API_BASE}/api/trpc/listings.list`);
    const data = await res.json();
    const rows = data?.result?.data?.json;
    expect(Array.isArray(rows)).toBe(true);
    // 시드 데이터가 삭제 테스트 등으로 비어있을 수 있으므로 배열 여부만 검증
    expect(rows.length).toBeGreaterThanOrEqual(0);
  });
});
