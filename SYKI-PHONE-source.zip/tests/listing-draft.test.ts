import { beforeEach, describe, expect, it, vi } from "vitest";

const store = new Map<string, string>();

vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(async (key: string) => store.get(key) ?? null),
    setItem: vi.fn(async (key: string, value: string) => {
      store.set(key, value);
    }),
    removeItem: vi.fn(async (key: string) => {
      store.delete(key);
    }),
  },
}));

import {
  clearListingDraft,
  getListingDraftKey,
  hasListingDraftContent,
  loadListingDraft,
  saveListingDraft,
  type ListingDraft,
} from "../lib/listing-draft";

const baseDraft: ListingDraft = {
  version: 1,
  brand: "Apple",
  model: "iPhone 15",
  storage: "256GB",
  color: "블랙",
  grade: "A",
  battery: "92",
  price: "850000",
  buyPrice: "700000",
  accessories: "본체만",
  description: "상태 양호",
  swatch: "#1F2937",
  sold: false,
  photos: ["file:///draft/photo.jpg"],
  savedAt: "2026-08-14T00:00:00.000Z",
};

describe("listing draft", () => {
  beforeEach(() => store.clear());

  it("신규 등록과 수정 매물의 임시저장 키를 구분한다", () => {
    expect(getListingDraftKey()).toBe("@syki/listing-draft:new");
    expect(getListingDraftKey(12)).toBe("@syki/listing-draft:edit:12");
  });

  it("입력된 내용이 있는지 판별한다", () => {
    expect(hasListingDraftContent(baseDraft)).toBe(true);
    expect(
      hasListingDraftContent({
        ...baseDraft,
        model: "",
        storage: "",
        color: "",
        price: "",
        buyPrice: "",
        description: "",
        photos: [],
        battery: "100",
      }),
    ).toBe(false);
  });

  it("임시저장 내용을 저장·복원·삭제한다", async () => {
    const key = getListingDraftKey();
    await saveListingDraft(key, baseDraft);
    await expect(loadListingDraft(key)).resolves.toEqual(baseDraft);
    await clearListingDraft(key);
    await expect(loadListingDraft(key)).resolves.toBeNull();
  });

  it("손상된 임시저장 데이터는 무시한다", async () => {
    store.set(getListingDraftKey(), "not-json");
    await expect(loadListingDraft(getListingDraftKey())).resolves.toBeNull();
  });
});
