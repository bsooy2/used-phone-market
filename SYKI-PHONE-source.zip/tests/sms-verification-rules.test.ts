import { describe, expect, it } from "vitest";

import { canRequestSmsCode, getVerificationFailureReason, normalizeSmsPhone, SMS_CODE_TTL_MS, SMS_MAX_VERIFY_ATTEMPTS } from "../lib/sms-verification-rules";

describe("SMS 본인인증 보안 규칙", () => {
  it("휴대폰 번호에서 하이픈과 공백을 제거한다", () => {
    expect(normalizeSmsPhone("010-2394 1420")).toBe("01023941420");
  });

  it("1분 내 재발송을 제한한다", () => {
    expect(canRequestSmsCode(1_000, 30_000)).toBe(false);
    expect(canRequestSmsCode(1_000, 61_000)).toBe(true);
  });

  it("만료 또는 시도 제한을 초과한 인증번호를 거부한다", () => {
    expect(getVerificationFailureReason({ expiresAt: 1_000 + SMS_CODE_TTL_MS, attempts: SMS_MAX_VERIFY_ATTEMPTS }, 1_500)).toContain("초과");
    expect(getVerificationFailureReason({ expiresAt: 1_000, attempts: 0 }, 1_001)).toContain("만료");
  });
});
