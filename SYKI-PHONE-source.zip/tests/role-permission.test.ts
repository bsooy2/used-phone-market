import { describe, expect, it } from "vitest";

import type { UserRole } from "@/lib/auth-store";

/**
 * 매물 등록 권한 규칙:
 * - 로그인하지 않은 사용자(null): 등록 불가
 * - 구매자(buyer): 등록 불가
 * - 판매자(seller): 등록 가능
 */
function canCreateListing(role: UserRole | null): boolean {
  return role === "seller";
}

describe("매물 등록 권한 제어", () => {
  it("비로그인 사용자는 매물을 등록할 수 없다", () => {
    expect(canCreateListing(null)).toBe(false);
  });

  it("구매자는 매물을 등록할 수 없다", () => {
    expect(canCreateListing("buyer")).toBe(false);
  });

  it("판매자는 매물을 등록할 수 있다", () => {
    expect(canCreateListing("seller")).toBe(true);
  });
});
