import { describe, expect, it } from "vitest";
import { isPriceInRange, PRICE_RANGES } from "../lib/price-filter";

describe("매물 가격대 필터", () => {
  it("경계 금액을 포함해 가격대를 판별한다", () => {
    const under300 = PRICE_RANGES.find((range) => range.id === "under-300")!;
    expect(isPriceInRange(300_000, under300)).toBe(true);
    expect(isPriceInRange(300_001, under300)).toBe(false);
  });

  it("최소·최대 범위 안의 가격만 허용한다", () => {
    const range = PRICE_RANGES.find((item) => item.id === "300-500")!;
    expect(isPriceInRange(300_000, range)).toBe(true);
    expect(isPriceInRange(500_000, range)).toBe(true);
    expect(isPriceInRange(299_999, range)).toBe(false);
    expect(isPriceInRange(500_001, range)).toBe(false);
  });

  it("전체 필터는 모든 정상 가격을 허용한다", () => {
    expect(isPriceInRange(1_080_000, PRICE_RANGES[0])).toBe(true);
    expect(isPriceInRange(-1, PRICE_RANGES[0])).toBe(false);
  });
});
