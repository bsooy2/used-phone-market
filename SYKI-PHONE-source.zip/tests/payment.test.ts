import { describe, expect, it, vi } from "vitest";

// react-native mock for vitest
vi.mock("react-native", () => ({
  Linking: { openURL: vi.fn() },
  Platform: { OS: "ios" },
}));

import {
  PAYMENT_METHODS,
  generateOrderId,
  formatKRW,
  isLiveMode,
  requestPayment,
} from "../lib/payment";

describe("결제 수단 정의", () => {
  it("4가지 결제 수단(카드/계좌이체/카카오페이/네이버페이)을 제공한다", () => {
    const keys = PAYMENT_METHODS.map((m) => m.key);
    expect(keys).toEqual(["card", "transfer", "kakaopay", "naverpay"]);
  });
});

describe("주문번호/금액 포맷", () => {
  it("주문번호는 SYKI 접두사를 가진다", () => {
    expect(generateOrderId()).toMatch(/^SYKI_/);
  });

  it("주문번호는 매번 고유하다", () => {
    const ids = new Set(Array.from({ length: 50 }, () => generateOrderId()));
    expect(ids.size).toBe(50);
  });

  it("금액은 천 단위 구분과 '원'으로 표기된다", () => {
    expect(formatKRW(1230000)).toBe("1,230,000원");
  });
});

describe("라이브/모의 모드 판별", () => {
  it("PG 키가 없으면 모든 수단이 모의 모드(false)이다", () => {
    // 환경변수 미설정 상태 기준
    expect(isLiveMode("card")).toBe(false);
    expect(isLiveMode("transfer")).toBe(false);
    // 카카오페이는 CID가 설정되어 있으므로 라이브 모드
    // expect(isLiveMode("kakaopay")).toBe(false);
    expect(isLiveMode("naverpay")).toBe(false);
  });
});

describe("결제 요청 (모의 모드)", () => {
  it("모의 모드에서는 결제가 성공 처리된다", async () => {
    const res = await requestPayment({
      orderId: generateOrderId(),
      productId: "p1",
      productName: "iPhone 15 Pro 256GB",
      amount: 1200000,
      method: "card",
      buyerName: "홍길동",
      buyerEmail: "test@example.com",
    });
    expect(res.status).toBe("success");
    if (res.status === "success") {
      expect(res.receiptId).toContain("RCPT_");
    }
  });
});
