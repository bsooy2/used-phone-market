import { describe, it, expect, vi } from "vitest";

// react-native mock
vi.mock("react-native", () => ({
  Linking: { openURL: vi.fn() },
  Platform: { OS: "ios" },
}));

import { PAYMENT_CONFIG, isLiveMode } from "../lib/payment";

describe("카카오페이 CID 환경변수 검증", () => {
  it("EXPO_PUBLIC_KAKAOPAY_CID가 설정되어 있다", () => {
    expect(PAYMENT_CONFIG.kakaoPayCid).toBeTruthy();
    expect(PAYMENT_CONFIG.kakaoPayCid.length).toBeGreaterThan(5);
  });

  it("카카오페이가 라이브 모드로 인식된다", () => {
    expect(isLiveMode("kakaopay")).toBe(true);
  });

  it("CID 형식이 올바르다 (영문+숫자 조합)", () => {
    expect(PAYMENT_CONFIG.kakaoPayCid).toMatch(/^[A-Z0-9]+$/);
  });
});
