import { describe, expect, it } from "vitest";

import { getSmsLimitStatus } from "../lib/sms-budget-rules";

describe("문자 발송 한도 경고", () => {
  it("잔액 부족 또는 일일 한도 도달 시 발송 차단 상태를 표시한다", () => {
    expect(getSmsLimitStatus({ balance: 0, dailySentCount: 3, dailyLimit: 100, balanceWarningThreshold: 5000 }).status).toBe("blocked");
    expect(getSmsLimitStatus({ balance: 10000, dailySentCount: 100, dailyLimit: 100, balanceWarningThreshold: 5000 }).status).toBe("blocked");
  });

  it("낮은 잔액 또는 80% 이상 발송 시 경고하고 여유가 있으면 정상으로 표시한다", () => {
    expect(getSmsLimitStatus({ balance: 4000, dailySentCount: 1, dailyLimit: 100, balanceWarningThreshold: 5000 }).status).toBe("warning");
    expect(getSmsLimitStatus({ balance: 10000, dailySentCount: 80, dailyLimit: 100, balanceWarningThreshold: 5000 }).status).toBe("warning");
    expect(getSmsLimitStatus({ balance: 10000, dailySentCount: 10, dailyLimit: 100, balanceWarningThreshold: 5000 })).toMatchObject({ status: "safe", remainingQuota: 90 });
  });
});
