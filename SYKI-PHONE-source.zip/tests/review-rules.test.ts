import { describe, expect, it } from "vitest";
import {
  canEditReview,
  isPhotoReviewRewardEligible,
  REVIEW_MAX_EDITS,
  REVIEW_MAX_PHOTOS,
  isValidReviewRating,
  validateReviewDraft,
} from "../lib/review-rules";

describe("거래 후기 규칙", () => {
  it("10자 이상, 1000자 이하, 사진 3장 이하의 후기를 허용한다", () => {
    expect(validateReviewDraft("정말 만족스러운 거래였습니다!", REVIEW_MAX_PHOTOS)).toBeNull();
  });

  it("짧은 내용·초과 사진을 거부한다", () => {
    expect(validateReviewDraft("좋아요", 1)).toContain("10자");
    expect(validateReviewDraft("충분히 긴 후기 내용입니다.", REVIEW_MAX_PHOTOS + 1)).toContain("최대");
  });

  it("수정은 최대 3회까지만 허용한다", () => {
    expect(canEditReview(REVIEW_MAX_EDITS - 1)).toBe(true);
    expect(canEditReview(REVIEW_MAX_EDITS)).toBe(false);
  });

  it("사진이 1장 이상인 최초 후기만 포인트 보상 대상이다", () => {
    expect(isPhotoReviewRewardEligible(0)).toBe(false);
    expect(isPhotoReviewRewardEligible(1)).toBe(true);
  });

  it("후기 별점은 1점부터 5점까지만 허용한다", () => {
    expect(isValidReviewRating(1)).toBe(true);
    expect(isValidReviewRating(5)).toBe(true);
    expect(isValidReviewRating(0)).toBe(false);
    expect(isValidReviewRating(6)).toBe(false);
    expect(isValidReviewRating(3.5)).toBe(false);
  });
});
