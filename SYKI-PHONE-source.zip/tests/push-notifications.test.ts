import { describe, expect, it } from "vitest";

import { isExpoPushToken } from "../server/push-notifications";

describe("Expo 푸시 토큰 검증", () => {
  it("유효한 Expo 형식만 기기 등록 대상으로 허용한다", () => {
    expect(isExpoPushToken("ExponentPushToken[xxxxxxxxxxxxxxxxxxxxxx]")).toBe(true);
    expect(isExpoPushToken("ExpoPushToken[xxxxxxxxxxxxxxxxxxxxxx]")).toBe(true);
    expect(isExpoPushToken("not-a-push-token")).toBe(false);
  });
});
