import { describe, expect, it } from "vitest";

import { getBannerClickSummary, getBannerPeriodChannelComparison } from "../lib/banner-analytics";

describe("광고 클릭 통계", () => {
  it("배너별 클릭 수를 합산하고 클릭 순으로 정렬한다", () => {
    const result = getBannerClickSummary([
      { id: "a", title: "첫 광고", clickCount: 2, conversionCount: 1 },
      { id: "b", title: "둘 광고", clickCount: 7, conversionCount: 4 },
      { id: "c", title: "셋 광고" },
    ]);
    expect(result.totalClicks).toBe(9);
    expect(result.totalConversions).toBe(5);
    expect(result.ranked.map((banner) => banner.id)).toEqual(["b", "a", "c"]);
  });

  it("선택 기간 안의 전화·웹 채널별 탭과 링크 실행을 비교한다", () => {
    const now = new Date("2026-08-20T12:00:00.000Z");
    const result = getBannerPeriodChannelComparison([
      { id: "phone", title: "전화 광고", linkUrl: "tel:01023941420", performanceEvents: [{ type: "tap", channel: "전화", occurredAt: "2026-08-19T10:00:00.000Z" }, { type: "conversion", channel: "전화", occurredAt: "2026-08-19T10:00:02.000Z" }] },
      { id: "web", title: "웹 광고", linkUrl: "https://example.com", performanceEvents: [{ type: "tap", channel: "웹", occurredAt: "2026-08-10T10:00:00.000Z" }] },
    ], 7, now);
    expect(result).toEqual([{ id: "phone", title: "전화 광고", channel: "전화", taps: 1, conversions: 1, conversionRate: 100 }, { id: "web", title: "웹 광고", channel: "웹", taps: 0, conversions: 0, conversionRate: 0 }]);
  });
});
