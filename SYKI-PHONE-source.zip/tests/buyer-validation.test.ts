import { describe, expect, it } from "vitest";

import { EMPTY_BUYER_PROFILE, validateBuyerProfile, type BuyerProfile } from "../lib/auth-store";

const VALID: BuyerProfile = {
  name: "홍길동",
  birth: "1995-03-21",
  gender: "male",
  email: "hong@example.com",
  zipcode: "06236",
  address: "서울특별시 강남구 테헤란로 152",
  addressDetail: "3층 301호",
  refundBank: "국민은행",
  refundAccount: "12345678901234",
  refundHolder: "홍길동",
};

describe("구매자 상세정보 검증", () => {
  it("모든 필드가 채워지면 통과한다(null 반환)", () => {
    expect(validateBuyerProfile(VALID)).toBeNull();
  });

  it("빈 프로필은 이름 누락 에러를 반환한다", () => {
    expect(validateBuyerProfile(EMPTY_BUYER_PROFILE)).toBe("이름을 입력해 주세요.");
  });

  it("성별 미선택 시 에러를 반환한다", () => {
    expect(validateBuyerProfile({ ...VALID, gender: "none" })).toBe("성별을 선택해 주세요.");
  });

  it("잘못된 이메일은 에러를 반환한다", () => {
    expect(validateBuyerProfile({ ...VALID, email: "invalid-email" })).toBe("올바른 이메일을 입력해 주세요.");
  });

  it("입금 계좌번호 누락 시 에러를 반환한다", () => {
    expect(validateBuyerProfile({ ...VALID, refundAccount: "" })).toBe("입금 계좌번호를 입력해 주세요.");
  });
});

import { searchAddress } from "../constants/address-data";

describe("주소 검색", () => {
  it("도로명 일부로 검색하면 결과를 반환한다", () => {
    const r = searchAddress("테헤란로");
    expect(r.length).toBeGreaterThan(0);
    expect(r[0].road).toContain("테헤란로");
  });

  it("지역명으로 검색할 수 있다", () => {
    const r = searchAddress("서귀포");
    expect(r.length).toBeGreaterThan(0);
    expect(r.every((a) => a.region.includes("서귀포") || a.road.includes("서귀포"))).toBe(true);
  });

  it("우편번호로 검색할 수 있다", () => {
    const r = searchAddress("06236");
    expect(r.length).toBeGreaterThan(0);
    expect(r[0].zipcode).toBe("06236");
  });

  it("빈 검색어는 빈 배열을 반환한다", () => {
    expect(searchAddress("")).toEqual([]);
  });
});
