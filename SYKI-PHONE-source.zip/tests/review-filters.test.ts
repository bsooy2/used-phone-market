import { describe, expect, it } from "vitest";

import { filterReviews, normalizeReviewSearchQuery } from "../lib/review-filters";

const reviews = [
  { text: "갤럭시 S24 상태가 좋아서 만족합니다.", authorName: "배수영", transactionLabel: "Galaxy S24 Ultra", rating: 5 },
  { text: "배송은 빨랐지만 배터리 상태는 보통입니다.", authorName: "김고객", transactionLabel: "iPhone 15 Pro", rating: 3 },
  { text: "친절하게 매입 상담해 주셨어요.", authorName: "이판매", transactionLabel: "iPhone 14", rating: 5 },
];

describe("고객 후기 검색·별점 필터", () => {
  it("공백과 대소문자를 무시하고 후기 내용 및 거래 모델을 검색한다", () => {
    expect(normalizeReviewSearchQuery("  S24 ")).toBe("s24");
    expect(filterReviews(reviews, "배터리", "all")).toHaveLength(1);
    expect(filterReviews(reviews, "IPHONE 15", "all")).toHaveLength(1);
  });

  it("작성자 이름도 키워드 검색 대상에 포함한다", () => {
    expect(filterReviews(reviews, "배수영", "all")).toEqual([reviews[0]]);
  });

  it("선택한 별점과 정확히 일치하는 후기만 표시한다", () => {
    expect(filterReviews(reviews, "", 5)).toEqual([reviews[0], reviews[2]]);
    expect(filterReviews(reviews, "", 3)).toEqual([reviews[1]]);
  });

  it("키워드와 별점 필터는 동시에 적용된다", () => {
    expect(filterReviews(reviews, "아이폰", 5)).toEqual([reviews[2]]);
    expect(filterReviews(reviews, "아이폰", 4)).toEqual([]);
  });
});
