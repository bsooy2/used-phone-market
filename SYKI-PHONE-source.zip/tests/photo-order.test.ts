import { describe, expect, it } from "vitest";

import { getPhotoDropIndex, moveArrayItem } from "../lib/photo-order";

describe("moveArrayItem", () => {
  it("선택한 사진을 앞으로 이동한다", () => {
    expect(moveArrayItem(["1", "2", "3"], 2, 1)).toEqual(["1", "3", "2"]);
  });

  it("선택한 사진을 뒤로 이동한다", () => {
    expect(moveArrayItem(["1", "2", "3"], 0, 2)).toEqual(["2", "3", "1"]);
  });

  it("유효하지 않은 이동은 원본 순서를 유지한다", () => {
    expect(moveArrayItem(["1", "2"], 0, -1)).toEqual(["1", "2"]);
    expect(moveArrayItem(["1", "2"], 4, 1)).toEqual(["1", "2"]);
  });

  it("드래그 거리로 사진 그리드의 놓을 위치를 계산한다", () => {
    expect(getPhotoDropIndex(0, 82, 103, 6, 3, 82, 103)).toBe(4);
    expect(getPhotoDropIndex(5, 200, 200, 6, 3, 82, 103)).toBe(5);
    expect(getPhotoDropIndex(1, -200, 0, 6, 3, 82, 103)).toBe(0);
  });
});
