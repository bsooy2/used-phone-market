import { describe, expect, it } from "vitest";

import { searchAddress, ADDRESS_DB } from "../constants/address-data";

describe("주소 검색 (searchAddress)", () => {
  it("빈 문자열 또는 공백만 입력하면 결과가 없다", () => {
    expect(searchAddress("")).toEqual([]);
    expect(searchAddress("   ")).toEqual([]);
  });

  it("도로명 일부로 검색하면 일치하는 주소를 찾는다", () => {
    const results = searchAddress("테헤란로");
    expect(results.length).toBeGreaterThan(0);
    expect(results.every((a) => a.road.includes("테헤란로"))).toBe(true);
  });

  it("우편번호로 검색하면 해당 주소를 찾는다", () => {
    const results = searchAddress("63591");
    expect(results.length).toBe(1);
    expect(results[0].zipcode).toBe("63591");
  });

  it("지역명(서귀포)으로 검색하면 매장 지역 주소들을 찾는다", () => {
    const results = searchAddress("서귀포");
    expect(results.length).toBeGreaterThanOrEqual(3);
    expect(results.every((a) => a.region.includes("서귀포") || a.road.includes("서귀포") || a.jibun.includes("서귀포"))).toBe(true);
  });

  it("지번 주소 일부로도 검색된다", () => {
    const sample = ADDRESS_DB[0];
    const token = sample.jibun.split(" ")[0];
    const results = searchAddress(token);
    expect(results.length).toBeGreaterThan(0);
  });

  it("일치하는 주소가 없으면 빈 배열을 반환한다", () => {
    expect(searchAddress("존재하지않는도로명ZZZ")).toEqual([]);
  });

  it("결과는 최대 30건으로 제한된다", () => {
    const results = searchAddress("로");
    expect(results.length).toBeLessThanOrEqual(30);
  });
});
