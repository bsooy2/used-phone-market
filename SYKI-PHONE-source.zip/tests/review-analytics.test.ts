import { describe, expect, it } from "vitest";

import { getReviewAnalyticsSummary } from "../lib/review-analytics";

describe("후기 관리자 통계", () => {
  it("후기 작성률·평균 평점·공개 후기를 계산한다", () => {
    const summary = getReviewAnalyticsSummary([
      { rating: 5, visibility: "public" },
      { rating: 3, visibility: "hidden" },
    ], 4);
    expect(summary).toMatchObject({ totalReviews: 2, publicReviews: 1, averageRating: 4, reviewWriteRate: 50 });
  });

  it("완료 거래가 없으면 후기 작성률은 0%다", () => {
    expect(getReviewAnalyticsSummary([], 0).reviewWriteRate).toBe(0);
  });
});
