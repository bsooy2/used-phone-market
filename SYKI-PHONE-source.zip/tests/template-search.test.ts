import { describe, expect, it } from "vitest";
import { filterReplyTemplatesByKeyword, sortReplyTemplatesByFavorite } from "../lib/template-search";

describe("답변 템플릿 키워드 검색", () => {
  const folders = [{ id: "unclassified", name: "미분류" }, { id: "visit", name: "매장 방문" }];
  const templates = [
    { id: "1", title: "방문 상담", body: "매장 방문 전에 전화 주세요.", folderId: "visit" },
    { id: "2", title: "배송 안내", body: "출고 후 배송 조회 번호를 드립니다.", folderId: "unclassified" },
  ];
  it("제목·내용·폴더명에서 대소문자와 공백을 무시해 검색한다", () => {
    expect(filterReplyTemplatesByKeyword(templates, folders, " 상담 ").map((template) => template.id)).toEqual(["1"]);
    expect(filterReplyTemplatesByKeyword(templates, folders, "전화").map((template) => template.id)).toEqual(["1"]);
    expect(filterReplyTemplatesByKeyword(templates, folders, "매장 방문").map((template) => template.id)).toEqual(["1"]);
  });
  it("빈 검색어는 모든 템플릿을 반환한다", () => {
    expect(filterReplyTemplatesByKeyword(templates, folders, "  ")).toHaveLength(2);
  });

  it("즐겨찾기 템플릿을 최근 수정 순서로 상단에 고정한다", () => {
    const sorted = sortReplyTemplatesByFavorite([
      { id: "normal", title: "일반", body: "", updatedAt: "2026-08-20T00:00:00.000Z" },
      { id: "favorite-old", title: "즐겨찾기", body: "", isFavorite: true, updatedAt: "2026-08-19T00:00:00.000Z" },
      { id: "favorite-new", title: "즐겨찾기 새", body: "", isFavorite: true, updatedAt: "2026-08-20T01:00:00.000Z" },
    ]);
    expect(sorted.map((template) => template.id)).toEqual(["favorite-new", "favorite-old", "normal"]);
  });
});
