import { describe, expect, it } from "vitest";

import { getFavoriteAlertSignals } from "../lib/favorite-alerts";

describe("찜 매물 알림 규칙", () => {
  it("기준 가격보다 낮아졌을 때 가격 인하 신호를 만든다", () => {
    const signals = getFavoriteAlertSignals(
      { id: "p1", model: "iPhone 15", price: 790_000, favoriteCount: 2 },
      { priceDrop: true, lowStock: false, baselinePrice: 850_000 },
    );
    expect(signals).toEqual(["priceDrop"]);
  });

  it("찜 수가 10명 이상이면 품절 임박 신호를 만들고 재발송은 막는다", () => {
    expect(getFavoriteAlertSignals({ id: "p1", model: "iPhone 15", price: 850_000, favoriteCount: 10 }, { priceDrop: false, lowStock: true, baselinePrice: 850_000 })).toEqual(["lowStock"]);
    expect(getFavoriteAlertSignals({ id: "p1", model: "iPhone 15", price: 850_000, favoriteCount: 10 }, { priceDrop: false, lowStock: true, baselinePrice: 850_000, lowStockAlerted: true })).toEqual([]);
  });
});
