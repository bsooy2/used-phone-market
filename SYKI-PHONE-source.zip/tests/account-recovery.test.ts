import { describe, expect, it } from "vitest";

import { isAccountRecoveryNameMatch, validatePasswordResetRequest } from "../lib/account-recovery";

describe("계정 복구 규칙", () => {
  it("휴대폰 번호와 이름 또는 닉네임이 비어 있으면 발급 요청을 거부한다", () => {
    expect(validatePasswordResetRequest("", "배수영")).toContain("모두 입력");
    expect(validatePasswordResetRequest("01023941420", " ")).toContain("모두 입력");
  });

  it("하이픈이 포함된 올바른 휴대폰 번호와 이름을 허용한다", () => {
    expect(validatePasswordResetRequest("010-2394-1420", "배수영")).toBeNull();
  });

  it("구매자 실명과 판매자 닉네임을 모두 비밀번호 찾기 이름으로 인식한다", () => {
    const buyer = { nickname: "폰사랑", buyerProfile: { name: "배수영" } };
    const seller = { nickname: "시끼폰사장" };

    expect(isAccountRecoveryNameMatch(buyer, "배수영")).toBe(true);
    expect(isAccountRecoveryNameMatch(seller, "시끼폰사장")).toBe(true);
    expect(isAccountRecoveryNameMatch(buyer, "다른이름")).toBe(false);
  });
});
