import { describe, expect, it } from "vitest";

import {
  BUYBACK_MODELS,
  CONDITION_OPTIONS,
  availableGrades,
  calculateQuote,
  getModelByKey,
  manwonToWon,
} from "../lib/buyback";

describe("buyback 데이터 무결성", () => {
  it("아이폰과 삼성 모델이 모두 포함된다", () => {
    expect(BUYBACK_MODELS.some((m) => m.brand === "Apple")).toBe(true);
    expect(BUYBACK_MODELS.some((m) => m.brand === "Samsung")).toBe(true);
    expect(BUYBACK_MODELS.length).toBeGreaterThan(50);
  });

  it("모델 key는 중복되지 않는다", () => {
    const keys = BUYBACK_MODELS.map((m) => m.key);
    expect(new Set(keys).size).toBe(keys.length);
  });

  it("모든 모델은 최소 1개 용량과 A급 가격을 가진다", () => {
    for (const m of BUYBACK_MODELS) {
      expect(m.variants.length).toBeGreaterThan(0);
      expect(m.variants[0].prices.A).not.toBeNull();
    }
  });
});

describe("calculateQuote - 기본 등급가", () => {
  it("옵션이 없으면 기준 등급가를 그대로 반환한다", () => {
    const model = BUYBACK_MODELS.find((m) => m.brand === "Apple")!;
    const storage = model.variants[0].storage;
    const q = calculateQuote({
      modelKey: model.key,
      storage,
      grade: "A",
      conditions: [],
    });
    expect(q.ok).toBe(true);
    expect(q.finalPrice).toBe(model.variants[0].prices.A);
    expect(q.deductions.length).toBe(0);
  });
});

describe("calculateQuote - 옵션 차감", () => {
  it("상태 옵션 선택 시 차감액이 반영된다", () => {
    const model = getModelByKey("galaxy-s24ultra")!;
    const storage = model.variants[0].storage;
    const base = model.variants[0].prices.A!;
    const q = calculateQuote({
      modelKey: model.key,
      storage,
      grade: "A",
      conditions: ["lcd"],
    });
    expect(q.ok).toBe(true);
    expect(q.deductions.length).toBe(1);
    expect(q.finalPrice).toBeCloseTo(base - model.deductions.lcd, 5);
  });

  it("여러 옵션 선택 시 누적 차감된다", () => {
    const model = getModelByKey("galaxy-s24ultra")!;
    const storage = model.variants[0].storage;
    const base = model.variants[0].prices.A!;
    const q = calculateQuote({
      modelKey: model.key,
      storage,
      grade: "A",
      conditions: ["liquidCrack", "backGlass"],
    });
    const expected = base - model.deductions.liquidCrack - model.deductions.backGlass;
    expect(q.finalPrice).toBeCloseTo(expected, 5);
  });

  it("중복 옵션은 한 번만 차감된다", () => {
    const model = getModelByKey("galaxy-s24ultra")!;
    const storage = model.variants[0].storage;
    const base = model.variants[0].prices.A!;
    const q = calculateQuote({
      modelKey: model.key,
      storage,
      grade: "A",
      conditions: ["lcd", "lcd", "lcd"],
    });
    expect(q.deductions.length).toBe(1);
    expect(q.finalPrice).toBeCloseTo(base - model.deductions.lcd, 5);
  });

  it("최종가는 0 미만으로 내려가지 않는다", () => {
    const model = getModelByKey("galaxy-a15")!;
    const storage = model.variants[0].storage;
    const q = calculateQuote({
      modelKey: model.key,
      storage,
      grade: "used",
      conditions: CONDITION_OPTIONS.map((o) => o.key),
    });
    expect(q.finalPrice).toBeGreaterThanOrEqual(0);
  });
});

describe("calculateQuote - 매입 불가/오류 처리", () => {
  it("존재하지 않는 모델은 ok=false", () => {
    const q = calculateQuote({
      modelKey: "no-such-model",
      storage: "기본",
      grade: "A",
      conditions: [],
    });
    expect(q.ok).toBe(false);
  });

  it("해당 등급 가격이 null이면 ok=false와 사유를 반환한다", () => {
    // liquid 가격이 null인 모델을 찾는다
    const model = BUYBACK_MODELS.find((m) => m.variants[0].prices.liquid === null);
    expect(model).toBeDefined();
    const q = calculateQuote({
      modelKey: model!.key,
      storage: model!.variants[0].storage,
      grade: "liquid",
      conditions: [],
    });
    expect(q.ok).toBe(false);
    expect(q.reason).toBeTruthy();
  });
});

describe("availableGrades", () => {
  it("가격이 있는 등급만 반환한다", () => {
    const model = BUYBACK_MODELS.find((m) => m.variants[0].prices.liquid === null)!;
    const grades = availableGrades(model, model.variants[0].storage);
    expect(grades).not.toContain("liquid");
    expect(grades).toContain("A");
  });
});

describe("manwonToWon", () => {
  it("만원 단위를 원 단위로 변환한다", () => {
    expect(manwonToWon(12)).toBe(120000);
    expect(manwonToWon(12.5)).toBe(125000);
  });
});
