import { describe, expect, it } from "vitest";
import { resolveTemplateFolderId, UNCLASSIFIED_FOLDER_ID, validateTemplateFolderName } from "../lib/template-folder-rules";

describe("답변 템플릿 폴더 규칙", () => {
  const folders = [{ id: UNCLASSIFIED_FOLDER_ID, name: "미분류" }, { id: "visit", name: "매장 방문" }];
  it("폴더 이름 길이와 중복을 검증한다", () => {
    expect(validateTemplateFolderName("방", folders)).toContain("2자");
    expect(validateTemplateFolderName("매장 방문", folders)).toContain("이미");
    expect(validateTemplateFolderName("  배송 안내  ", folders)).toBeNull();
  });
  it("없는 폴더에 속한 기존 템플릿을 미분류로 안전하게 이동한다", () => {
    expect(resolveTemplateFolderId("visit", folders.map((folder) => folder.id))).toBe("visit");
    expect(resolveTemplateFolderId("deleted", folders.map((folder) => folder.id))).toBe(UNCLASSIFIED_FOLDER_ID);
  });
});
