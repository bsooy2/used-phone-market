import { describe, expect, it } from "vitest";

import { AppNotification, Order, Phone } from "../constants/types";
import {
  FEE_RATE,
  buildSettleRows,
  calcRow,
  countUnread,
  notificationsForUser,
  summarize,
} from "../lib/settlement";

function makePhone(id: string, price: number): Phone {
  return {
    id,
    brand: "Apple",
    model: "iPhone 15 Pro",
    storage: "256GB",
    color: "black",
    grade: "A",
    battery: 95,
    price,
    buyPrice: price - 100000,
    image: "iphone",
    description: "테스트 매물",
    accessories: "본체",
    createdAt: "2026-01-01",
    sellerId: "seller-1",
    sellerName: "판매자",
  };
}

function makeOrder(id: string, productId: string, buyerId: string): Order {
  return {
    id,
    productId,
    productName: "iPhone 15 Pro",
    amount: 1000000,
    method: "card",
    status: "결제완료",
    buyerId,
    receiptId: "rcpt_" + id,
    createdAt: "2026-01-02",
  };
}

function makeNoti(id: string, userId: string, read: boolean): AppNotification {
  return {
    id,
    kind: "order",
    title: "알림",
    body: "내용",
    userId,
    read,
    createdAt: "2026-01-03",
  };
}

describe("정산 계산 (settlement)", () => {
  it("수수료율은 3.5%이다", () => {
    expect(FEE_RATE).toBeCloseTo(0.035, 5);
  });

  it("판매된 매물은 매출/수수료/정산액을 계산한다", () => {
    const phone = makePhone("p1", 1000000);
    const row = calcRow(phone, new Set(["p1"]));
    expect(row.sold).toBe(true);
    expect(row.gross).toBe(1000000);
    expect(row.fee).toBe(35000);
    expect(row.net).toBe(965000);
  });

  it("판매되지 않은 매물은 매출이 0이다", () => {
    const phone = makePhone("p2", 800000);
    const row = calcRow(phone, new Set());
    expect(row.sold).toBe(false);
    expect(row.gross).toBe(0);
    expect(row.fee).toBe(0);
    expect(row.net).toBe(0);
  });

  it("수수료는 반올림 처리된다", () => {
    const phone = makePhone("p3", 333333); // 333333 * 0.035 = 11666.655
    const row = calcRow(phone, new Set(["p3"]));
    expect(row.fee).toBe(11667);
  });

  it("매물 목록과 주문으로 정산 행을 빌드한다", () => {
    const listings = [makePhone("p1", 1000000), makePhone("p2", 500000)];
    const orders = [makeOrder("o1", "p1", "buyer-1")];
    const rows = buildSettleRows(listings, orders);
    expect(rows).toHaveLength(2);
    expect(rows.find((r) => r.phone.id === "p1")?.sold).toBe(true);
    expect(rows.find((r) => r.phone.id === "p2")?.sold).toBe(false);
  });

  it("요약은 판매된 매물만 합산한다", () => {
    const listings = [makePhone("p1", 1000000), makePhone("p2", 500000), makePhone("p3", 200000)];
    const orders = [makeOrder("o1", "p1", "b1"), makeOrder("o2", "p2", "b1")];
    const summary = summarize(buildSettleRows(listings, orders));
    expect(summary.listingCount).toBe(3);
    expect(summary.soldCount).toBe(2);
    expect(summary.gross).toBe(1500000);
    expect(summary.fee).toBe(52500);
    expect(summary.net).toBe(1447500);
  });

  it("판매 매물이 없으면 요약 합계가 0이다", () => {
    const summary = summarize(buildSettleRows([makePhone("p1", 100000)], []));
    expect(summary.soldCount).toBe(0);
    expect(summary.gross).toBe(0);
    expect(summary.net).toBe(0);
  });
});

describe("알림 카운트 (notifications)", () => {
  it("특정 사용자의 미읽음 알림만 센다", () => {
    const notis = [
      makeNoti("n1", "u1", false),
      makeNoti("n2", "u1", true),
      makeNoti("n3", "u1", false),
      makeNoti("n4", "u2", false),
    ];
    expect(countUnread(notis, "u1")).toBe(2);
    expect(countUnread(notis, "u2")).toBe(1);
    expect(countUnread(notis, "u3")).toBe(0);
  });

  it("특정 사용자의 알림만 필터링한다", () => {
    const notis = [makeNoti("n1", "u1", false), makeNoti("n2", "u2", false)];
    const result = notificationsForUser(notis, "u1");
    expect(result).toHaveLength(1);
    expect(result[0].userId).toBe("u1");
  });
});
