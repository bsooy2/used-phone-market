import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(__dirname, "..");

describe("Codemagic Android CI/CD configuration", () => {
  it("테스트 APK 및 Google Play AAB 워크플로를 모두 제공한다", () => {
    const config = readFileSync(resolve(root, "codemagic.yaml"), "utf8");
    expect(config).toContain("syki-android-apk:");
    expect(config).toContain("syki-android-play:");
    expect(config).toContain("app:assembleRelease app:bundleRelease");
    expect(config).toContain("app:bundleRelease");
  });

  it("Google Play 워크플로가 외부 서명 키를 참조하고 저장소에는 키를 두지 않는다", () => {
    const config = readFileSync(resolve(root, "codemagic.yaml"), "utf8");
    const signingScript = readFileSync(resolve(root, "scripts/codemagic-android-signing.mjs"), "utf8");
    expect(config).toContain("syki-google-play");
    expect(signingScript).toContain("CM_KEYSTORE_PATH");
    expect(signingScript).toContain("CM_KEYSTORE_PASSWORD");
    expect(signingScript).not.toContain("storePassword \"");
  });
});
