import { describe, expect, it } from "vitest";

import { validateBankAccount } from "../lib/bank-account";

describe("은행별 계좌번호 자릿수 검증", () => {
  it("국민은행 14자리는 통과한다", () => {
    expect(validateBankAccount("국민은행", "12345678901234")).toEqual({ valid: true, message: null });
  });

  it("국민은행 12자리는 실패한다", () => {
    const result = validateBankAccount("국민은행", "123456789012");
    expect(result.valid).toBe(false);
    expect(result.message).toContain("14자리");
  });

  it("신한은행 12자리는 통과한다", () => {
    expect(validateBankAccount("신한", "123456789012")).toEqual({ valid: true, message: null });
  });

  it("카카오뱅크 13자리는 통과한다", () => {
    expect(validateBankAccount("카카오뱅크", "1234567890123")).toEqual({ valid: true, message: null });
  });

  it("알 수 없는 은행은 10~16자리 범위만 확인한다", () => {
    expect(validateBankAccount("미래은행", "12345678901234")).toEqual({ valid: true, message: null });
    const short = validateBankAccount("미래은행", "123456");
    expect(short.valid).toBe(false);
  });

  it("빈 계좌번호는 실패한다", () => {
    expect(validateBankAccount("국민은행", "").valid).toBe(false);
  });

  it("빈 은행명은 실패한다", () => {
    expect(validateBankAccount("", "12345678901234").valid).toBe(false);
  });
});
