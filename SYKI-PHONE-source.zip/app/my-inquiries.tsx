import { useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { Image } from "expo-image";
import { useRouter } from "expo-router";

import { PhotoLightbox } from "@/components/photo-lightbox";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";
import { TradeInquiry, useInquiryStore } from "@/lib/inquiry-store";

export default function MyInquiriesScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuthStore();
  const { getInquiriesForUser, loaded } = useInquiryStore();
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const inquiries = user ? getInquiriesForUser(user.id) : [];
  const openPhotos = (inquiry: TradeInquiry, index: number) => { setSelectedPhotos(inquiry.photos ?? []); setLightboxIndex(index); };

  return <ScreenContainer className="p-5"><ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }}><View><Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>내 거래 문의</Text><Text style={{ color: colors.muted, fontSize: 13, marginTop: 5 }}>거래별 문의와 사장님 답변을 확인하세요.</Text></View>{!loaded ? <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 44 }}>문의를 불러오는 중...</Text> : inquiries.length === 0 ? <View style={{ alignItems: "center", gap: 9, paddingVertical: 58 }}><Text style={{ color: colors.muted }}>등록한 거래 문의가 없습니다.</Text><Pressable onPress={() => router.back()} style={{ paddingVertical: 8 }}><Text style={{ color: colors.primary, fontWeight: "800" }}>거래 내역으로 돌아가기</Text></Pressable></View> : inquiries.map((inquiry) => <View key={inquiry.id} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 15, gap: 9 }}><View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}><View style={{ flex: 1 }}><Text style={{ color: colors.foreground, fontWeight: "800" }}>{inquiry.transactionLabel}</Text><Text style={{ color: colors.muted, fontSize: 11, marginTop: 3 }}>{new Date(inquiry.createdAt).toLocaleDateString("ko-KR")}</Text></View><Text style={{ color: inquiry.reply ? colors.primary : colors.muted, fontSize: 11, fontWeight: "800" }}>{inquiry.reply ? "답변 완료" : "답변 대기"}</Text></View><Text style={{ color: colors.foreground, lineHeight: 20 }}>{inquiry.body}</Text>{inquiry.photos?.length ? <View style={{ gap: 5 }}><Text style={{ color: colors.muted, fontSize: 11, fontWeight: "700" }}>첨부 사진 · 탭하여 확대</Text><View style={{ flexDirection: "row", gap: 8 }}>{inquiry.photos.map((uri, index) => <Pressable key={uri} onPress={() => openPhotos(inquiry, index)}><Image source={{ uri }} style={{ width: 72, height: 72, borderRadius: 9 }} contentFit="cover" /></Pressable>)}</View></View> : null}{inquiry.reply && <View style={{ backgroundColor: colors.background, padding: 11, borderRadius: 9, borderWidth: 1, borderColor: colors.border, gap: 3 }}><Text style={{ color: colors.primary, fontSize: 11, fontWeight: "800" }}>사장님 답변</Text><Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 19 }}>{inquiry.reply}</Text></View>}</View>)}</ScrollView><PhotoLightbox photos={selectedPhotos} initialIndex={lightboxIndex ?? 0} visible={lightboxIndex !== null} onClose={() => setLightboxIndex(null)} /></ScreenContainer>;
}
