import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";
import { REVIEW_MAX_EDITS } from "@/lib/review-rules";
import { useReviewStore } from "@/lib/review-store";

export default function MyReviewsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuthStore();
  const { getReviewsForUser, loaded } = useReviewStore();
  const reviews = user ? getReviewsForUser(user.id) : [];

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }}>
        <View style={{ gap: 4 }}>
          <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>내 거래 후기</Text>
          <Text style={{ color: colors.muted, fontSize: 13 }}>사진 후기는 최초 등록 시 10,000P가 적립됩니다.</Text>
        </View>
        {!loaded ? (
          <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 36 }}>후기를 불러오는 중...</Text>
        ) : reviews.length === 0 ? (
          <View style={{ alignItems: "center", gap: 8, paddingVertical: 48 }}>
            <IconSymbol name="star.fill" size={32} color={colors.muted} />
            <Text style={{ color: colors.muted }}>작성한 거래 후기가 없습니다.</Text>
          </View>
        ) : reviews.map((review) => {
          const editable = review.editCount < REVIEW_MAX_EDITS;
          return (
            <View key={review.id} style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 15, borderWidth: 1, borderColor: colors.border, gap: 10 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }} numberOfLines={1}>{review.transactionLabel}</Text>
                  <Text style={{ color: colors.muted, fontSize: 11 }}>{review.transactionType === "purchase" ? "구매 거래" : "판매 거래"} · {new Date(review.createdAt).toLocaleDateString("ko-KR")}</Text>
                </View>
                {review.pointAwarded && <View style={{ backgroundColor: colors.foreground, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 }}><Text style={{ color: colors.background, fontSize: 10, fontWeight: "800" }}>+10,000P</Text></View>}
              </View>
              <Text style={{ color: colors.primary, fontSize: 15, letterSpacing: 1 }}>{"★".repeat(review.rating)}</Text>
              <Text style={{ color: colors.foreground, lineHeight: 20 }} numberOfLines={3}>{review.text}</Text>
              {review.photos.length > 0 && <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{review.photos.map((uri, index) => <Image key={`${uri}-${index}`} source={{ uri }} style={{ width: 72, height: 72, borderRadius: 8 }} />)}</ScrollView>}
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                <Text style={{ color: colors.muted, fontSize: 11 }}>수정 {review.editCount}/{REVIEW_MAX_EDITS}회</Text>
                {editable && <Pressable onPress={() => router.push({ pathname: "/write-review", params: { transactionId: review.transactionId, transactionType: review.transactionType, transactionLabel: review.transactionLabel, reviewId: review.id } })}><Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "800" }}>후기 수정</Text></Pressable>}
              </View>
            </View>
          );
        })}
      </ScrollView>
    </ScreenContainer>
  );
}
