import { Stack, useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useContentStore } from "@/lib/content-store";

export default function NoticesScreen() {
  const colors = useColors();
  const router = useRouter();
  const { notices } = useContentStore();
  const orderedNotices = [...notices].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.createdAt.localeCompare(a.createdAt));

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 8, gap: 8 }}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "800" }}>공지사항</Text>
      </View>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 10, paddingBottom: 40 }}>
        {orderedNotices.length === 0 ? (
          <View style={{ paddingVertical: 80, alignItems: "center", gap: 8 }}>
            <IconSymbol name="bell.fill" size={30} color={colors.muted} />
            <Text style={{ color: colors.muted }}>등록된 공지사항이 없습니다.</Text>
          </View>
        ) : orderedNotices.map((notice) => (
          <Pressable
            key={notice.id}
            onPress={() => router.push(`/notice-detail?id=${notice.id}`)}
            style={({ pressed }) => [{ backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border, gap: 6 }, pressed && { opacity: 0.7 }]}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              {notice.pinned ? <Text style={{ fontSize: 12 }}>📌</Text> : null}
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800", flex: 1 }} numberOfLines={1}>{notice.title}</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </View>
            {notice.body ? <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }} numberOfLines={2}>{notice.body}</Text> : null}
            <Text style={{ color: colors.muted, fontSize: 11 }}>{new Date(notice.createdAt).toLocaleDateString("ko-KR")}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
