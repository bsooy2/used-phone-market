import { router, useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  AppState,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";

import { ScreenContainer } from "@/components/screen-container";
import { DraggablePhotoGrid } from "@/components/draggable-photo-grid";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { GRADE_INFO } from "@/constants/phones";
import { Grade } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import {
  clearListingDraft,
  getListingDraftKey,
  hasListingDraftContent,
  loadListingDraft,
  saveListingDraft,
  type ListingDraft,
} from "@/lib/listing-draft";
import { persistListingDraftPhoto, removeListingDraftPhotos } from "@/lib/listing-draft-photos";
import { moveArrayItem } from "@/lib/photo-order";
import { trpc } from "@/lib/trpc";
import { uploadImages } from "@/lib/upload";

const GRADES: Grade[] = ["S", "A", "B", "C"];
const COLOR_SWATCHES = ["#1F2937", "#111827", "#1E293B", "#334155", "#374151", "#6D28D9", "#0F766E", "#9CA3AF"];
const MAX_PHOTOS = 6;

export default function AdminEditScreen() {
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const editId = id ? Number(id) : null;
  const isEdit = editId !== null && Number.isFinite(editId);

  const { pin, isAdmin } = useAdminStore();
  const utils = trpc.useUtils();

  const detailQuery = trpc.listings.get.useQuery(
    { id: editId as number },
    { enabled: isEdit },
  );

  const [brand, setBrand] = useState("Apple");
  const [model, setModel] = useState("");
  const [storage, setStorage] = useState("");
  const [color, setColor] = useState("");
  const [grade, setGrade] = useState<Grade>("A");
  const [battery, setBattery] = useState("100");
  const [price, setPrice] = useState("");
  const [buyPrice, setBuyPrice] = useState("");
  const [accessories, setAccessories] = useState("본체만");
  const [description, setDescription] = useState("");
  const [swatch, setSwatch] = useState(COLOR_SWATCHES[0]);
  const [sold, setSold] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [formReady, setFormReady] = useState(false);
  const [draftSavedAt, setDraftSavedAt] = useState<string | null>(null);
  const draftKey = getListingDraftKey(isEdit ? editId : null);
  const draftContentRef = useRef<Omit<ListingDraft, "version" | "savedAt"> | null>(null);

  const applyDraft = useCallback((draft: ListingDraft) => {
    setBrand(draft.brand);
    setModel(draft.model);
    setStorage(draft.storage);
    setColor(draft.color);
    setGrade(draft.grade);
    setBattery(draft.battery);
    setPrice(draft.price);
    setBuyPrice(draft.buyPrice);
    setAccessories(draft.accessories);
    setDescription(draft.description);
    setSwatch(draft.swatch);
    setSold(draft.sold);
    setPhotos(draft.photos.slice(0, MAX_PHOTOS));
    setDraftSavedAt(draft.savedAt);
  }, []);

  const resetNewForm = useCallback(() => {
    setBrand("Apple");
    setModel("");
    setStorage("");
    setColor("");
    setGrade("A");
    setBattery("100");
    setPrice("");
    setBuyPrice("");
    setAccessories("본체만");
    setDescription("");
    setSwatch(COLOR_SWATCHES[0]);
    setSold(false);
    setPhotos([]);
  }, []);

  useEffect(() => {
    if (formReady || (isEdit && !detailQuery.data)) return;
    let active = true;

    const restoreForm = async () => {
      const draft = await loadListingDraft(draftKey);
      if (!active) return;

      if (draft) {
        applyDraft(draft);
      } else if (isEdit && detailQuery.data) {
        const d = detailQuery.data;
        setBrand(d.brand);
        setModel(d.model);
        setStorage(d.storage);
        setColor(d.color);
        setGrade(d.grade);
        setBattery(String(d.battery));
        setPrice(String(d.price));
        setBuyPrice(String(d.buyPrice));
        setAccessories(d.accessories);
        setDescription(d.description ?? "");
        setSwatch(d.image);
        setSold(d.sold === 1);
        try {
          const parsed = d.photos ? JSON.parse(d.photos) : [];
          setPhotos(Array.isArray(parsed) ? parsed.slice(0, MAX_PHOTOS) : []);
        } catch {
          setPhotos([]);
        }
      }
      setFormReady(true);
    };

    void restoreForm();
    return () => {
      active = false;
    };
  }, [applyDraft, detailQuery.data, draftKey, formReady, isEdit]);

  const pickPhoto = useCallback(async () => {
    if (photos.length >= MAX_PHOTOS) {
      Alert.alert("최대 6장", "사진은 최대 6장까지 첨부할 수 있습니다.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: MAX_PHOTOS - photos.length,
      quality: 0.8,
    });
    if (!result.canceled && result.assets.length > 0) {
      const newUris = await Promise.all(
        result.assets.map((asset, index) => persistListingDraftPhoto(asset.uri, photos.length + index)),
      );
      setPhotos((prev) => [...prev, ...newUris].slice(0, MAX_PHOTOS));
    }
  }, [photos.length]);

  const takePhoto = useCallback(async () => {
    if (photos.length >= MAX_PHOTOS) {
      Alert.alert("최대 6장", "사진은 최대 6장까지 첨부할 수 있습니다.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (!result.canceled && result.assets.length > 0) {
      const savedUri = await persistListingDraftPhoto(result.assets[0].uri, photos.length);
      setPhotos((prev) => [...prev, savedUri].slice(0, MAX_PHOTOS));
    }
  }, [photos.length]);

  const removePhoto = useCallback((idx: number) => {
    setPhotos((prev) => {
      const removed = prev[idx];
      if (removed) void removeListingDraftPhotos([removed]);
      return prev.filter((_, i) => i !== idx);
    });
  }, []);

  const [draggingPhotoIndex, setDraggingPhotoIndex] = useState<number | null>(null);
  const [dropPhotoIndex, setDropPhotoIndex] = useState<number | null>(null);

  const handleDropPhoto = useCallback((fromIndex: number, toIndex: number) => {
    setPhotos((prev) => moveArrayItem(prev, fromIndex, toIndex));
  }, []);

  const createMutation = trpc.listings.create.useMutation();
  const updateMutation = trpc.listings.update.useMutation();
  const saving = createMutation.isPending || updateMutation.isPending;

  const currentDraftContent = {
    brand,
    model,
    storage,
    color,
    grade,
    battery,
    price,
    buyPrice,
    accessories,
    description,
    swatch,
    sold,
    photos,
  };
  draftContentRef.current = currentDraftContent;

  const persistDraft = useCallback(async () => {
    const content = draftContentRef.current;
    if (!formReady || saving || !content) return;

    if (!hasListingDraftContent(content)) {
      await clearListingDraft(draftKey);
      setDraftSavedAt(null);
      return;
    }

    const savedAt = new Date().toISOString();
    await saveListingDraft(draftKey, { ...content, version: 1, savedAt });
    setDraftSavedAt(savedAt);
  }, [draftKey, formReady, saving]);

  useEffect(() => {
    if (!formReady || saving) return;
    const timer = setTimeout(() => {
      void persistDraft().catch(() => {});
    }, 700);

    return () => clearTimeout(timer);
  }, [accessories, battery, brand, buyPrice, color, description, formReady, grade, model, persistDraft, photos, price, saving, sold, storage, swatch]);

  useEffect(() => {
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "inactive" || nextState === "background") {
        void persistDraft().catch(() => {});
      }
    });
    return () => subscription.remove();
  }, [persistDraft]);

  const handleDiscardDraft = () => {
    Alert.alert("임시저장 삭제", "현재 입력한 내용과 임시저장 사진을 삭제할까요?", [
      { text: "취소", style: "cancel" },
      {
        text: "삭제",
        style: "destructive",
        onPress: () => {
          void (async () => {
            await clearListingDraft(draftKey);
            await removeListingDraftPhotos(photos);
            setDraftSavedAt(null);
            if (isEdit) {
              setFormReady(false);
            } else {
              resetNewForm();
            }
          })();
        },
      },
    ]);
  };

  if (!isAdmin || !pin) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center p-6">
        <IconSymbol name="lock.fill" size={44} color={colors.muted} />
        <Text className="text-base font-bold text-foreground mt-4">관리자 인증이 필요합니다.</Text>
        <TouchableOpacity onPress={() => router.back()} style={{ marginTop: 20 }}>
          <Text style={{ color: colors.primary, fontWeight: "700" }}>돌아가기</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  if (!formReady || (isEdit && detailQuery.isLoading)) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center">
        <ActivityIndicator color={colors.foreground} />
      </ScreenContainer>
    );
  }

  const handleSubmit = async () => {
    if (!model.trim() || !storage.trim() || !price.trim()) {
      Alert.alert("입력 확인", "모델명, 용량, 판매가는 필수 입력입니다.");
      return;
    }
    const priceNum = parseInt(price.replace(/[^0-9]/g, ""), 10);
    if (!priceNum || priceNum <= 0) {
      Alert.alert("입력 확인", "올바른 판매가를 입력해 주세요.");
      return;
    }
    const buyNum = parseInt(buyPrice.replace(/[^0-9]/g, ""), 10) || 0;
    const batteryNum = Math.min(100, Math.max(0, parseInt(battery.replace(/[^0-9]/g, ""), 10) || 0));

    // 사진을 서버에 업로드 (로컬 URI → 공개 URL). 실패하면 임시저장을 유지한 채 재시도하도록 한다.
    let uploadedPhotos = photos;
    if (photos.length > 0) {
      try {
        uploadedPhotos = await uploadImages(photos);
      } catch {
        Alert.alert("사진 업로드 실패", "사진을 업로드하지 못했습니다. 네트워크를 확인한 뒤 다시 등록해 주세요.");
        return;
      }
    }

    const data = {
      brand: brand.trim() || "기타",
      model: model.trim(),
      storage: storage.trim(),
      color: color.trim() || "기본",
      grade,
      battery: batteryNum,
      price: priceNum,
      buyPrice: buyNum,
      image: swatch,
      photos: JSON.stringify(uploadedPhotos),
      description: description.trim(),
      accessories: accessories.trim() || "본체만",
      sold: sold ? 1 : 0,
    };

    try {
      if (isEdit) {
        await updateMutation.mutateAsync({ pin, id: editId as number, data });
      } else {
        await createMutation.mutateAsync({ pin, data });
      }
      await clearListingDraft(draftKey);
      await removeListingDraftPhotos(photos);
      await utils.listings.list.invalidate();
      if (isEdit) await utils.listings.get.invalidate({ id: editId as number });
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert(isEdit ? "수정 완료" : "등록 완료", isEdit ? "매물이 수정되었습니다." : "매물이 등록되었습니다.", [
        { text: "확인", onPress: () => router.back() },
      ]);
    } catch {
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("오류", "저장에 실패했습니다. PIN 또는 네트워크를 확인해 주세요.");
    }
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <View className="flex-row items-center justify-between px-5 py-3 border-b border-border">
        <TouchableOpacity onPress={() => router.back()} hitSlop={10} style={{ opacity: 0.7 }}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </TouchableOpacity>
        <Text className="text-base font-bold text-foreground">{isEdit ? "매물 수정" : "매물 등록"}</Text>
        <View style={{ width: 26 }} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
              padding: 12,
              marginBottom: 18,
              borderRadius: 12,
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "800" }}>
                {draftSavedAt ? "작성 내용이 임시저장되었습니다" : "작성 내용은 자동으로 임시저장됩니다"}
              </Text>
              <Text style={{ color: colors.muted, fontSize: 11 }}>
                사진을 포함한 입력 내용은 이 기기에 저장되며, 등록 완료 후 삭제됩니다.
              </Text>
            </View>
            {draftSavedAt ? (
              <Pressable onPress={handleDiscardDraft} style={({ pressed }) => [{ paddingVertical: 6 }, pressed && { opacity: 0.6 }]}>
                <Text style={{ color: colors.error, fontSize: 12, fontWeight: "800" }}>삭제</Text>
              </Pressable>
            ) : null}
          </View>
          <Field label="제조사">
            <View className="flex-row gap-2">
              {["Apple", "Samsung", "기타"].map((b) => {
                const active = brand === b;
                return (
                  <Pressable
                    key={b}
                    onPress={() => setBrand(b)}
                    style={({ pressed }) => [
                      { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, borderColor: active ? colors.primary : colors.border, backgroundColor: active ? colors.surface : colors.background },
                      pressed && { opacity: 0.85 },
                    ]}
                  >
                    <Text style={{ color: active ? colors.foreground : colors.muted, fontWeight: "600" }}>{b}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <Field label="모델명 *">
            <TextInput value={model} onChangeText={setModel} placeholder="예) iPhone 14 Pro" placeholderTextColor={colors.muted} style={inputStyle(colors)} />
          </Field>

          <View className="flex-row gap-3">
            <View style={{ flex: 1 }}>
              <Field label="용량 *">
                <TextInput value={storage} onChangeText={setStorage} placeholder="예) 256GB" placeholderTextColor={colors.muted} style={inputStyle(colors)} />
              </Field>
            </View>
            <View style={{ flex: 1 }}>
              <Field label="색상">
                <TextInput value={color} onChangeText={setColor} placeholder="예) 딥퍼플" placeholderTextColor={colors.muted} style={inputStyle(colors)} />
              </Field>
            </View>
          </View>

          <Field label="상태 등급">
            <View className="flex-row gap-2">
              {GRADES.map((g) => {
                const active = grade === g;
                const info = GRADE_INFO[g];
                return (
                  <Pressable
                    key={g}
                    onPress={() => setGrade(g)}
                    style={({ pressed }) => [
                      { flex: 1, alignItems: "center", paddingVertical: 12, borderRadius: 10, borderWidth: 1.5, borderColor: active ? colors.foreground : colors.border, backgroundColor: active ? colors.surface : colors.background },
                      pressed && { opacity: 0.85 },
                    ]}
                  >
                    <Text style={{ color: active ? colors.foreground : colors.muted, fontWeight: "700" }}>{info.label}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <View className="flex-row gap-3">
            <View style={{ flex: 1 }}>
              <Field label="배터리 효율(%)">
                <TextInput value={battery} onChangeText={setBattery} placeholder="예) 92" placeholderTextColor={colors.muted} keyboardType="number-pad" style={inputStyle(colors)} />
              </Field>
            </View>
            <View style={{ flex: 1 }}>
              <Field label="판매가(원) *">
                <TextInput value={price} onChangeText={setPrice} placeholder="예) 850000" placeholderTextColor={colors.muted} keyboardType="number-pad" style={inputStyle(colors)} />
              </Field>
            </View>
          </View>

          <Field label="매입가(원, 참고용)">
            <TextInput value={buyPrice} onChangeText={setBuyPrice} placeholder="예) 720000" placeholderTextColor={colors.muted} keyboardType="number-pad" style={inputStyle(colors)} />
          </Field>

          {/* 가격 자동 추천 */}
          {model.trim() && storage.trim() && grade && (() => {
            const suggestion = suggestPrice(model, storage, grade);
            if (!suggestion) return null;
            return (
              <View style={{ backgroundColor: colors.surface, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.border, gap: 4 }}>
                <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>💡 추천 판매가 (시세 기반)</Text>
                <Text style={{ color: colors.muted, fontSize: 12 }}>
                  매입 시세: {suggestion.buyback.toLocaleString()}원
                </Text>
                <View style={{ flexDirection: "row", gap: 8, marginTop: 4 }}>
                  <Pressable
                    onPress={() => setPrice(String(suggestion.min))}
                    style={{ flex: 1, backgroundColor: colors.border, borderRadius: 8, paddingVertical: 8, alignItems: "center" }}
                  >
                    <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "600" }}>최소 {suggestion.min.toLocaleString()}원</Text>
                  </Pressable>
                  <Pressable
                    onPress={() => setPrice(String(suggestion.max))}
                    style={{ flex: 1, backgroundColor: colors.foreground, borderRadius: 8, paddingVertical: 8, alignItems: "center" }}
                  >
                    <Text style={{ color: colors.background, fontSize: 13, fontWeight: "600" }}>최대 {suggestion.max.toLocaleString()}원</Text>
                  </Pressable>
                </View>
              </View>
            );
          })()}

          <Field label="구성품">
            <TextInput value={accessories} onChangeText={setAccessories} placeholder="예) 본체, 충전기, 박스" placeholderTextColor={colors.muted} style={inputStyle(colors)} />
          </Field>

          <Field label="썸네일 색상">
            <View className="flex-row flex-wrap gap-3">
              {COLOR_SWATCHES.map((c) => {
                const active = swatch === c;
                return (
                  <Pressable key={c} onPress={() => setSwatch(c)} style={({ pressed }) => [{ opacity: pressed ? 0.8 : 1 }]}>
                    <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: c, borderWidth: active ? 3 : 1, borderColor: active ? colors.foreground : colors.border }} />
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <Field label="매물 사진 (최대 6장)">
            {photos.length > 1 ? (
              <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>
                사진을 길게 눌러 원하는 위치로 끌어 놓으세요. 첫 번째 사진이 대표 썸네일로 표시됩니다.
              </Text>
            ) : null}
            {photos.length > 0 && (
              <DraggablePhotoGrid
                photos={photos}
                colors={colors}
                draggingIndex={draggingPhotoIndex}
                dropIndex={dropPhotoIndex}
                onDragStart={(index) => {
                  setDraggingPhotoIndex(index);
                  setDropPhotoIndex(index);
                }}
                onDragMove={setDropPhotoIndex}
                onDrop={handleDropPhoto}
                onDragEnd={() => {
                  setDraggingPhotoIndex(null);
                  setDropPhotoIndex(null);
                }}
                onRemove={removePhoto}
              />
            )}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable
                onPress={pickPhoto}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                    paddingVertical: 14,
                    borderRadius: 12,
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <IconSymbol name="photo.fill" size={18} color={colors.primary} />
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 14 }}>앨범</Text>
              </Pressable>
              <Pressable
                onPress={takePhoto}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                    paddingVertical: 14,
                    borderRadius: 12,
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <IconSymbol name="camera.fill" size={18} color={colors.primary} />
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 14 }}>카메라</Text>
              </Pressable>
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, textAlign: "center", marginTop: 4 }}>
              {photos.length}/{MAX_PHOTOS}장 첨부됨
            </Text>
          </Field>

          <Field label="상세 설명">
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="기기 상태, 구매 시기, 특이사항 등을 적어주세요."
              placeholderTextColor={colors.muted}
              multiline
              style={[inputStyle(colors), { height: 110, textAlignVertical: "top" }]}
            />
          </Field>

          {/* 판매완료 토글 */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              backgroundColor: colors.surface,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: colors.border,
              paddingHorizontal: 16,
              paddingVertical: 14,
              marginBottom: 18,
            }}
          >
            <View>
              <Text className="text-sm font-semibold text-foreground">판매완료 표시</Text>
              <Text className="text-xs text-muted mt-0.5">켜면 목록에 '판매완료'로 노출됩니다.</Text>
            </View>
            <Switch
              value={sold}
              onValueChange={setSold}
              trackColor={{ true: colors.foreground, false: colors.border }}
              thumbColor={colors.background}
            />
          </View>

          <TouchableOpacity
            onPress={handleSubmit}
            disabled={saving}
            activeOpacity={0.85}
            style={{ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 4, opacity: saving ? 0.7 : 1 }}
          >
            {saving ? (
              <ActivityIndicator color={colors.background} />
            ) : (
              <Text style={{ color: colors.background, fontWeight: "700", fontSize: 16 }}>{isEdit ? "수정 저장" : "매물 등록하기"}</Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 18 }}>
      <Text className="text-sm font-semibold text-foreground mb-2">{label}</Text>
      {children}
    </View>
  );
}

function inputStyle(colors: ReturnType<typeof useColors>) {
  return {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: colors.foreground,
  } as const;
}
import { suggestPrice } from "@/lib/price-suggest";
