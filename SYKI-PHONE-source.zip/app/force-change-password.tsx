import { useState } from "react";
import { Text, TextInput, View, Pressable, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";

export default function ForceChangePasswordScreen() {
  const colors = useColors();
  const router = useRouter();
  const { changePassword, clearMustChangePassword } = useAuthStore();
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (newPw.length < 4) { Alert.alert("알림", "비밀번호는 4자 이상이어야 합니다."); return; }
    if (newPw !== confirmPw) { Alert.alert("알림", "비밀번호가 일치하지 않습니다."); return; }
    setLoading(true);
    const res = await changePassword(newPw);
    setLoading(false);
    if (res.ok) {
      await clearMustChangePassword();
      Alert.alert("완료", "비밀번호가 변경되었습니다.", [{ text: "확인", onPress: () => router.replace("/(tabs)") }]);
    } else {
      Alert.alert("오류", res.error ?? "변경에 실패했습니다.");
    }
  };

  return (
    <ScreenContainer className="p-6">
      <View style={{ gap: 16, flex: 1, justifyContent: "center" }}>
        <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800", textAlign: "center" }}>비밀번호 변경 필요</Text>
        <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center" }}>임시 비밀번호로 로그인하셨습니다.{"\n"}보안을 위해 새 비밀번호를 설정해 주세요.</Text>
        <TextInput value={newPw} onChangeText={setNewPw} placeholder="새 비밀번호 (4자 이상)" placeholderTextColor={colors.muted} secureTextEntry style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
        <TextInput value={confirmPw} onChangeText={setConfirmPw} placeholder="새 비밀번호 확인" placeholderTextColor={colors.muted} secureTextEntry style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
        <Pressable onPress={handleSubmit} disabled={loading} style={{ backgroundColor: colors.foreground, paddingVertical: 14, borderRadius: 12, alignItems: "center", opacity: loading ? 0.5 : 1 }}>
          <Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>비밀번호 변경</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

