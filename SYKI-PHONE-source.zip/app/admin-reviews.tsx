import { useState } from "react";
import { Alert, Image, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import { useReviewStore } from "@/lib/review-store";

export default function AdminReviewsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAdmin } = useAdminStore();
  const { reviews, loaded, setReviewVisibility, clearReviewReports, setAdminReply } = useReviewStore();
  const [replyInputs, setReplyInputs] = useState<Record<string, string>>({});
  const sortedReviews = [...reviews].sort((a, b) => b.reportedBy.length - a.reportedBy.length || b.updatedAt.localeCompare(a.updatedAt));

  if (!isAdmin) {
    return <ScreenContainer className="items-center justify-center p-6"><Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 18 }}>관리자 전용 화면입니다.</Text><Pressable onPress={() => router.replace("/admin")} style={{ marginTop: 14, backgroundColor: colors.foreground, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10 }}><Text style={{ color: colors.background, fontWeight: "800" }}>관리자 인증하기</Text></Pressable></ScreenContainer>;
  }

  const toggleVisibility = (id: string, next: "public" | "hidden") => {
    const result = setReviewVisibility(id, next);
    if (!result.ok) Alert.alert("오류", result.error ?? "처리에 실패했습니다.");
  };
  const resolveReport = (id: string) => {
    Alert.alert("신고 처리", "신고 내역을 해제할까요? 숨김 상태는 유지됩니다.", [{ text: "취소", style: "cancel" }, { text: "신고 해제", onPress: () => clearReviewReports(id) }]);
  };
  const saveReply = (id: string) => {
    const text = replyInputs[id] ?? "";
    const result = setAdminReply(id, text);
    if (result.ok) {
      Alert.alert("완료", "사장님 답글이 저장되었습니다.");
    } else {
      Alert.alert("오류", result.error ?? "저장에 실패했습니다.");
    }
  };

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
        <View style={{ gap: 4 }}><Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>후기 관리</Text><Text style={{ color: colors.muted, fontSize: 13 }}>신고가 많은 후기부터 표시됩니다. 사장님만 공개·숨김 처리 및 답글을 남길 수 있습니다.</Text></View>
        {!loaded ? <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 40 }}>후기를 불러오는 중...</Text> : sortedReviews.length === 0 ? <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 55 }}>등록된 후기가 없습니다.</Text> : sortedReviews.map((review) => (
          <View key={review.id} style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 15, gap: 10, borderWidth: 1, borderColor: review.reportedBy.length ? colors.error : colors.border }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}><View style={{ flex: 1 }}><Text style={{ color: colors.foreground, fontWeight: "800" }}>{review.authorName} · {review.rating}점</Text><Text style={{ color: colors.muted, fontSize: 11, marginTop: 3 }}>{review.transactionLabel}</Text></View><View style={{ backgroundColor: review.visibility === "public" ? colors.foreground : colors.muted, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 }}><Text style={{ color: colors.background, fontSize: 10, fontWeight: "800" }}>{review.visibility === "public" ? "공개" : "숨김"}</Text></View></View>
            <Text style={{ color: colors.foreground, lineHeight: 20 }}>{review.text}</Text>
            {review.photos.length > 0 && <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{review.photos.map((uri, index) => <Image key={`${uri}-${index}`} source={{ uri }} style={{ width: 66, height: 66, borderRadius: 8 }} />)}</ScrollView>}
            <Text style={{ color: review.reportedBy.length ? colors.error : colors.muted, fontSize: 12, fontWeight: "700" }}>신고 {review.reportedBy.length}건</Text>
            <View style={{ gap: 6, marginTop: 4 }}>
              <TextInput
                value={replyInputs[review.id] ?? review.adminReply?.text ?? ""}
                onChangeText={(text) => setReplyInputs((prev) => ({ ...prev, [review.id]: text }))}
                placeholder="사장님 답글 입력"
                placeholderTextColor={colors.muted}
                style={{ backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, color: colors.foreground, fontSize: 13 }}
              />
              <Pressable onPress={() => saveReply(review.id)} style={({ pressed }) => [{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, paddingVertical: 8, borderRadius: 8, alignItems: "center" }, pressed && { opacity: 0.7 }]}>
                <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 12 }}>답글 저장</Text>
              </Pressable>
            </View>
            <View style={{ flexDirection: "row", gap: 8, marginTop: 4 }}><Pressable onPress={() => toggleVisibility(review.id, review.visibility === "public" ? "hidden" : "public")} style={{ flex: 1, backgroundColor: colors.foreground, paddingVertical: 10, borderRadius: 9, alignItems: "center" }}><Text style={{ color: colors.background, fontWeight: "800", fontSize: 12 }}>{review.visibility === "public" ? "후기 숨김" : "공개 복원"}</Text></Pressable>{review.reportedBy.length > 0 && <Pressable onPress={() => resolveReport(review.id)} style={{ flex: 1, borderWidth: 1, borderColor: colors.border, paddingVertical: 10, borderRadius: 9, alignItems: "center" }}><Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 12 }}>신고 처리</Text></Pressable>}</View>
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
