import { Stack, useRouter } from "expo-router";
import { useState } from "react";
import { Alert, FlatList, Modal, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import { getBannerImageSource, useContentStore, Notice, EventBanner } from "@/lib/content-store";
import { useAppStore } from "@/lib/app-store";

type Tab = "notices" | "banners";

export default function AdminContentScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAdmin } = useAdminStore();
  const { notices, banners, addNotice, updateNotice, deleteNotice, addBanner, updateBanner, deleteBanner } = useContentStore();
  const [tab, setTab] = useState<Tab>("notices");
  const { pushNotification } = useAppStore();

  // 공지 편집 모달
  const [noticeModal, setNoticeModal] = useState(false);
  const [editNotice, setEditNotice] = useState<Notice | null>(null);
  const [nTitle, setNTitle] = useState("");
  const [nBody, setNBody] = useState("");
  const [nPinned, setNPinned] = useState(false);

  // 배너 편집 모달
  const [bannerModal, setBannerModal] = useState(false);
  const [editBanner, setEditBanner] = useState<EventBanner | null>(null);
  const [bTitle, setBTitle] = useState("");
  const [bImage, setBImage] = useState("");
  const [bLink, setBLink] = useState("");
  const [bStartDate, setBStartDate] = useState("");
  const [bEndDate, setBEndDate] = useState("");

  if (!isAdmin) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]}>
        <Stack.Screen options={{ headerShown: false }} />
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 24 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>관리자 모드에서만 접근 가능합니다.</Text>
          <Pressable onPress={() => router.back()} style={{ marginTop: 16 }}>
            <Text style={{ color: colors.primary, fontWeight: "700" }}>뒤로가기</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  function openNoticeEditor(notice?: Notice) {
    setEditNotice(notice ?? null);
    setNTitle(notice?.title ?? "");
    setNBody(notice?.body ?? "");
    setNPinned(notice?.pinned ?? false);
    setNoticeModal(true);
  }

  function saveNotice() {
    if (!nTitle.trim()) { Alert.alert("오류", "제목을 입력해 주세요."); return; }
    if (editNotice) updateNotice(editNotice.id, nTitle.trim(), nBody.trim(), nPinned);
    else {
      addNotice(nTitle.trim(), nBody.trim(), nPinned);
      pushNotification({ kind: "system", title: "새 공지사항", body: `📢 ${nTitle.trim()}`, userId: "__customer__" });
    }
    setNoticeModal(false);
  }

  function confirmDeleteNotice(id: string) {
    Alert.alert("삭제", "이 공지사항을 삭제하시겠습니까?", [
      { text: "취소", style: "cancel" },
      { text: "삭제", style: "destructive", onPress: () => deleteNotice(id) },
    ]);
  }

  async function pickBannerImage() {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.8 });
    if (!result.canceled && result.assets[0]) setBImage(result.assets[0].uri);
  }

  function openBannerEditor(banner?: EventBanner) {
    setEditBanner(banner ?? null);
    setBTitle(banner?.title ?? "");
    setBImage(banner?.imageUri ?? "");
    setBLink(banner?.linkUrl ?? "");
    setBStartDate(banner?.startDate ? banner.startDate.slice(0, 10) : "");
    setBEndDate(banner?.endDate ? banner.endDate.slice(0, 10) : "");
    setBannerModal(true);
  }

  function saveBanner() {
    if (!bTitle.trim()) { Alert.alert("오류", "제목을 입력해 주세요."); return; }
    if (!bImage) { Alert.alert("오류", "이미지를 선택해 주세요."); return; }
    const isDate = (value: string) => !value || /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(new Date(`${value}T00:00:00`).getTime());
    if (!isDate(bStartDate) || !isDate(bEndDate)) { Alert.alert("날짜 형식 오류", "유효기간은 YYYY-MM-DD 형식으로 입력해 주세요."); return; }
    if (bStartDate && bEndDate && bStartDate > bEndDate) { Alert.alert("유효기간 오류", "종료일은 시작일 이후로 설정해 주세요."); return; }
    const startDate = bStartDate ? `${bStartDate}T00:00:00.000Z` : undefined;
    const endDate = bEndDate ? `${bEndDate}T23:59:59.999Z` : undefined;
    if (editBanner) updateBanner(editBanner.id, { title: bTitle.trim(), imageUri: bImage, linkUrl: bLink.trim() || undefined, startDate, endDate });
    else {
      addBanner(bTitle.trim(), bImage, bLink.trim() || undefined, startDate, endDate);
      pushNotification({ kind: "system", title: "새 이벤트", body: `🎉 ${bTitle.trim()}`, userId: "__customer__" });
    }
    setBannerModal(false);
  }

  function confirmDeleteBanner(id: string) {
    Alert.alert("삭제", "이 배너를 삭제하시겠습니까?", [
      { text: "취소", style: "cancel" },
      { text: "삭제", style: "destructive", onPress: () => deleteBanner(id) },
    ]);
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      {/* 헤더 */}
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 8, gap: 8 }}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>콘텐츠 관리</Text>
      </View>

      {/* 탭 */}
      <View style={{ flexDirection: "row", marginHorizontal: 16, marginBottom: 12, backgroundColor: colors.surface, borderRadius: 10, padding: 3 }}>
        {(["notices", "banners"] as Tab[]).map((t) => (
          <Pressable
            key={t}
            onPress={() => setTab(t)}
            style={{ flex: 1, paddingVertical: 10, borderRadius: 8, alignItems: "center", backgroundColor: tab === t ? colors.foreground : "transparent" }}
          >
            <Text style={{ color: tab === t ? colors.background : colors.muted, fontWeight: "700", fontSize: 13 }}>
              {t === "notices" ? "공지사항" : "이벤트/광고"}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* 공지사항 탭 */}
      {tab === "notices" && (
        <View style={{ flex: 1 }}>
          <Pressable
            onPress={() => openNoticeEditor()}
            style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 8, marginHorizontal: 16, marginBottom: 12, backgroundColor: colors.foreground, borderRadius: 12, padding: 14 }, pressed && { opacity: 0.85 }]}
          >
            <IconSymbol name="plus" size={18} color={colors.background} />
            <Text style={{ color: colors.background, fontWeight: "700" }}>새 공지사항 작성</Text>
          </Pressable>
          <FlatList
            data={notices}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40, gap: 10 }}
            ListEmptyComponent={<Text style={{ color: colors.muted, textAlign: "center", marginTop: 40 }}>등록된 공지사항이 없습니다.</Text>}
            renderItem={({ item }) => (
              <View style={{ backgroundColor: colors.surface, borderRadius: 12, padding: 14, borderWidth: 1, borderColor: colors.border }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  {item.pinned && <Text style={{ color: colors.error, fontSize: 11, fontWeight: "800" }}>📌</Text>}
                  <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700", flex: 1 }}>{item.title}</Text>
                </View>
                {item.body ? <Text style={{ color: colors.muted, fontSize: 13, marginTop: 4 }} numberOfLines={2}>{item.body}</Text> : null}
                <View style={{ flexDirection: "row", gap: 12, marginTop: 8 }}>
                  <Pressable onPress={() => openNoticeEditor(item)}><Text style={{ color: colors.primary, fontSize: 12, fontWeight: "600" }}>수정</Text></Pressable>
                  <Pressable onPress={() => confirmDeleteNotice(item.id)}><Text style={{ color: colors.error, fontSize: 12, fontWeight: "600" }}>삭제</Text></Pressable>
                </View>
              </View>
            )}
          />
        </View>
      )}

      {/* 이벤트/광고 탭 */}
      {tab === "banners" && (
        <View style={{ flex: 1 }}>
          <Pressable
            onPress={() => openBannerEditor()}
            style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 8, marginHorizontal: 16, marginBottom: 12, backgroundColor: colors.foreground, borderRadius: 12, padding: 14 }, pressed && { opacity: 0.85 }]}
          >
            <IconSymbol name="plus" size={18} color={colors.background} />
            <Text style={{ color: colors.background, fontWeight: "700" }}>새 이벤트/광고 등록</Text>
          </Pressable>
          <FlatList
            data={banners}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40, gap: 10 }}
            ListEmptyComponent={<Text style={{ color: colors.muted, textAlign: "center", marginTop: 40 }}>등록된 이벤트/광고가 없습니다.</Text>}
            renderItem={({ item }) => (
              <View style={{ backgroundColor: colors.surface, borderRadius: 12, overflow: "hidden", borderWidth: 1, borderColor: colors.border }}>
                {item.imageUri ? <Image source={getBannerImageSource(item.imageUri)} style={{ width: "100%", height: 120 }} contentFit="cover" /> : null}
                <View style={{ padding: 12 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: item.active ? "#22C55E" : colors.muted }} />
                    <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700", flex: 1 }}>{item.title}</Text>
                  </View>
                  <View style={{ flexDirection: "row", gap: 12, marginTop: 8 }}>
                    <Pressable onPress={() => updateBanner(item.id, { active: !item.active })}>
                      <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "600" }}>{item.active ? "비활성화" : "활성화"}</Text>
                    </Pressable>
                    <Pressable onPress={() => openBannerEditor(item)}><Text style={{ color: colors.primary, fontSize: 12, fontWeight: "600" }}>수정</Text></Pressable>
                    <Pressable onPress={() => confirmDeleteBanner(item.id)}><Text style={{ color: colors.error, fontSize: 12, fontWeight: "600" }}>삭제</Text></Pressable>
                  </View>
                </View>
              </View>
            )}
          />
        </View>
      )}

      {/* 공지 편집 모달 */}
      <Modal visible={noticeModal} animationType="slide" transparent>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, paddingBottom: 40, gap: 14 }}>
            <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800" }}>{editNotice ? "공지 수정" : "새 공지 작성"}</Text>
            <TextInput value={nTitle} onChangeText={setNTitle} placeholder="제목" placeholderTextColor={colors.muted} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, fontSize: 15, color: colors.foreground }} />
            <TextInput value={nBody} onChangeText={setNBody} placeholder="내용 (선택)" placeholderTextColor={colors.muted} multiline numberOfLines={4} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, fontSize: 14, color: colors.foreground, minHeight: 100, textAlignVertical: "top" }} />
            <Pressable onPress={() => setNPinned(!nPinned)} style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <View style={{ width: 22, height: 22, borderRadius: 4, borderWidth: 1.5, borderColor: nPinned ? colors.primary : colors.border, backgroundColor: nPinned ? colors.primary : "transparent", alignItems: "center", justifyContent: "center" }}>
                {nPinned && <IconSymbol name="checkmark" size={14} color={colors.background} />}
              </View>
              <Text style={{ color: colors.foreground, fontSize: 14 }}>상단 고정</Text>
            </Pressable>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable onPress={() => setNoticeModal(false)} style={{ flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: colors.foreground, fontWeight: "700" }}>취소</Text>
              </Pressable>
              <Pressable onPress={saveNotice} style={{ flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center", backgroundColor: colors.foreground }}>
                <Text style={{ color: colors.background, fontWeight: "700" }}>저장</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* 배너 편집 모달 */}
      <Modal visible={bannerModal} animationType="slide" transparent>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, paddingBottom: 40, gap: 14 }}>
            <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800" }}>{editBanner ? "배너 수정" : "새 이벤트/광고"}</Text>
            <TextInput value={bTitle} onChangeText={setBTitle} placeholder="제목" placeholderTextColor={colors.muted} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, fontSize: 15, color: colors.foreground }} />
            <Pressable onPress={pickBannerImage} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, alignItems: "center" }}>
              <Text style={{ color: colors.primary, fontWeight: "700" }}>{bImage ? "이미지 변경" : "이미지 선택"}</Text>
            </Pressable>
            {bImage ? <Image source={{ uri: bImage }} style={{ width: "100%", height: 100, borderRadius: 10 }} contentFit="cover" /> : null}
            <TextInput value={bLink} onChangeText={setBLink} placeholder="링크 URL (선택)" placeholderTextColor={colors.muted} autoCapitalize="none" style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, fontSize: 14, color: colors.foreground }} />
            <View style={{ flexDirection: "row", gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 4 }}>시작일 (선택)</Text>
                <TextInput value={bStartDate} onChangeText={setBStartDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.muted} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 10, fontSize: 13, color: colors.foreground }} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 4 }}>종료일 (선택)</Text>
                <TextInput value={bEndDate} onChangeText={setBEndDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.muted} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 10, fontSize: 13, color: colors.foreground }} />
              </View>
            </View>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable onPress={() => setBannerModal(false)} style={{ flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: colors.foreground, fontWeight: "700" }}>취소</Text>
              </Pressable>
              <Pressable onPress={saveBanner} style={{ flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center", backgroundColor: colors.foreground }}>
                <Text style={{ color: colors.background, fontWeight: "700" }}>저장</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
