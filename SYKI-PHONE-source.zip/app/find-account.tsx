import { useState } from "react";
import { ActivityIndicator, Text, TextInput, View, Pressable, Alert, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";
import { trpc } from "@/lib/trpc";

export default function FindAccountScreen() {
  const colors = useColors();
  const router = useRouter();
  const { findId, findIdByEmail, requestPasswordResetCode, verifyAndResetPassword } = useAuthStore();
  const requestSmsMutation = trpc.sms.requestPasswordReset.useMutation();
  const verifySmsMutation = trpc.sms.verifyPasswordReset.useMutation();

  const [tab, setTab] = useState<"id" | "pw">("id");

  // 아이디 찾기
  const [idName, setIdName] = useState("");
  const [idBirth, setIdBirth] = useState("");
  const [idEmail, setIdEmail] = useState("");
  const [idMethod, setIdMethod] = useState<"name" | "email">("name");
  const [foundPhone, setFoundPhone] = useState<string | null>(null);

  // 비밀번호 찾기 (인증번호 발송 → 본인확인 → 새 비밀번호 설정)
  const [pwPhone, setPwPhone] = useState("");
  const [pwName, setPwName] = useState("");
  const [pwStep, setPwStep] = useState<"request" | "verify" | "newpw">("request");
  const [resetToken, setResetToken] = useState<string | null>(null);
  const [inputCode, setInputCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [resetError, setResetError] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  const handleFindId = async () => {
    setFoundPhone(null);
    const res = idMethod === "name"
      ? await findId(idName, idBirth)
      : await findIdByEmail(idEmail);
    if (res.ok) setFoundPhone(res.phone ?? "");
    else Alert.alert("알림", res.error ?? "조회에 실패했습니다.");
  };

  const handleRequestCode = async () => {
    if (isResetting) return;
    setResetError(null);
    setIsResetting(true);
    try {
      const res = await requestPasswordResetCode(pwPhone, pwName);
      if (res.ok) {
        const sms = await requestSmsMutation.mutateAsync({ phone: pwPhone });
        if (!sms.ok) {
          setResetError(sms.error ?? "인증번호 발송에 실패했습니다.");
          return;
        }
        setPwStep("verify");
        Alert.alert("인증번호 발송", "입력하신 번호로 본인인증번호가 발송되었습니다. 3분 내 입력해 주세요.");
      } else {
        setResetError(res.error ?? "회원 정보를 확인할 수 없습니다.");
      }
    } catch {
      setResetError("인증번호 발송 중 오류가 발생했습니다.");
    } finally {
      setIsResetting(false);
    }
  };

  const handleVerifyCode = async () => {
    setResetError(null);
    if (!inputCode.trim()) {
      setResetError("인증번호를 입력해 주세요.");
      return;
    }
    setIsResetting(true);
    try {
      const result = await verifySmsMutation.mutateAsync({ phone: pwPhone, code: inputCode.trim() });
      if (!result.ok) {
        setResetError(result.error ?? "인증번호가 일치하지 않습니다.");
        return;
      }
      setResetToken(result.resetToken);
      setPwStep("newpw");
    } catch {
      setResetError("인증번호 확인 중 오류가 발생했습니다.");
    } finally {
      setIsResetting(false);
    }
  };

  const handleSaveNewPassword = async () => {
    setResetError(null);
    if (newPassword.length < 4) {
      setResetError("새 비밀번호는 4자 이상이어야 합니다.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setResetError("새 비밀번호가 일치하지 않습니다.");
      return;
    }
    if (!resetToken) {
      setResetError("본인인증을 먼저 완료해 주세요.");
      return;
    }
    setIsResetting(true);
    try {
      const res = await verifyAndResetPassword(pwPhone, newPassword);
      if (res.ok) {
        Alert.alert("설정 완료", "새 비밀번호가 성공적으로 설정되었습니다. 로그인 화면으로 이동합니다.", [
          { text: "확인", onPress: () => router.back() },
        ]);
      } else {
        setResetError(res.error ?? "비밀번호 변경에 실패했습니다.");
      }
    } catch {
      setResetError("비밀번호 변경 중 오류가 발생했습니다.");
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1, gap: 20 }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
        {/* 탭 */}
        <View style={{ flexDirection: "row", borderRadius: 12, overflow: "hidden", borderWidth: 1, borderColor: colors.border }}>
          <Pressable onPress={() => { setTab("id"); setFoundPhone(null); }} style={{ flex: 1, paddingVertical: 12, alignItems: "center", backgroundColor: tab === "id" ? colors.foreground : colors.surface }}>
            <Text style={{ color: tab === "id" ? colors.background : colors.foreground, fontWeight: "700", fontSize: 14 }}>아이디 찾기</Text>
          </Pressable>
          <Pressable onPress={() => { setTab("pw"); setPwStep("request"); setResetToken(null); setInputCode(""); setNewPassword(""); setConfirmPassword(""); setResetError(null); }} style={{ flex: 1, paddingVertical: 12, alignItems: "center", backgroundColor: tab === "pw" ? colors.foreground : colors.surface }}>
            <Text style={{ color: tab === "pw" ? colors.background : colors.foreground, fontWeight: "700", fontSize: 14 }}>비밀번호 찾기</Text>
          </Pressable>
        </View>

        {tab === "id" ? (
          <View style={{ gap: 14 }}>
            {/* 방법 선택 */}
            <View style={{ flexDirection: "row", gap: 8 }}>
              <Pressable onPress={() => setIdMethod("name")} style={{ flex: 1, paddingVertical: 10, borderRadius: 8, alignItems: "center", backgroundColor: idMethod === "name" ? colors.foreground : colors.surface, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: idMethod === "name" ? colors.background : colors.foreground, fontSize: 13, fontWeight: "700" }}>이름+생년월일</Text>
              </Pressable>
              <Pressable onPress={() => setIdMethod("email")} style={{ flex: 1, paddingVertical: 10, borderRadius: 8, alignItems: "center", backgroundColor: idMethod === "email" ? colors.foreground : colors.surface, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: idMethod === "email" ? colors.background : colors.foreground, fontSize: 13, fontWeight: "700" }}>이메일</Text>
              </Pressable>
            </View>

            {idMethod === "name" ? (
              <>
                <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>가입 시 입력한 이름과 생년월일을 입력해 주세요.</Text>
                <TextInput value={idName} onChangeText={setIdName} placeholder="이름" placeholderTextColor={colors.muted} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
                <TextInput value={idBirth} onChangeText={setIdBirth} placeholder="생년월일 (예: 19900101)" placeholderTextColor={colors.muted} keyboardType="number-pad" maxLength={8} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
              </>
            ) : (
              <>
                <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>가입 시 입력한 이메일을 입력해 주세요.</Text>
                <TextInput value={idEmail} onChangeText={setIdEmail} placeholder="이메일 주소" placeholderTextColor={colors.muted} keyboardType="email-address" autoCapitalize="none" style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
              </>
            )}
            <Pressable onPress={handleFindId} style={{ backgroundColor: colors.foreground, paddingVertical: 14, borderRadius: 12, alignItems: "center" }}>
              <Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>아이디 찾기</Text>
            </Pressable>
            {foundPhone && (
              <View style={{ backgroundColor: colors.surface, borderRadius: 12, padding: 16, gap: 6 }}>
                <Text style={{ color: colors.muted, fontSize: 13 }}>가입된 휴대폰 번호 (일부 마스킹)</Text>
                <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800", letterSpacing: 1 }}>{foundPhone}</Text>
              </View>
            )}
          </View>
        ) : (
          <View style={{ gap: 14 }}>
            {pwStep === "request" && (
              <>
                <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>가입 시 등록한 휴대폰 번호와 이름(또는 닉네임)을 입력 후 본인인증을 진행하세요.</Text>
                <TextInput value={pwPhone} onChangeText={setPwPhone} placeholder="휴대폰 번호 (아이디)" placeholderTextColor={colors.muted} keyboardType="phone-pad" returnKeyType="next" style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
                <TextInput value={pwName} onChangeText={setPwName} placeholder="이름 또는 닉네임" placeholderTextColor={colors.muted} returnKeyType="done" onSubmitEditing={handleRequestCode} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
                {resetError && <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.error + "55" }}><Text style={{ color: colors.error, fontSize: 13, lineHeight: 19 }}>{resetError}</Text></View>}
                <Pressable disabled={isResetting} onPress={handleRequestCode} style={({ pressed }) => [{ backgroundColor: colors.foreground, paddingVertical: 14, borderRadius: 12, alignItems: "center", opacity: isResetting ? 0.6 : 1 }, pressed && !isResetting && { transform: [{ scale: 0.98 }], opacity: 0.86 }]}>
                  {isResetting ? <ActivityIndicator color={colors.background} /> : <Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>인증번호 발송</Text>}
                </Pressable>
              </>
            )}

            {pwStep === "verify" && (
              <>
                <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>문자로 발송된 본인인증번호 6자리를 입력해 주세요.</Text>
                <TextInput value={inputCode} onChangeText={setInputCode} placeholder="인증번호 6자리" placeholderTextColor={colors.muted} keyboardType="number-pad" maxLength={6} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground, letterSpacing: 3 }} />
                {resetError && <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.error + "55" }}><Text style={{ color: colors.error, fontSize: 13, lineHeight: 19 }}>{resetError}</Text></View>}
                <Pressable disabled={isResetting} onPress={handleVerifyCode} style={({ pressed }) => [{ backgroundColor: colors.foreground, paddingVertical: 14, borderRadius: 12, alignItems: "center", opacity: isResetting ? 0.6 : 1 }, pressed && !isResetting && { transform: [{ scale: 0.98 }], opacity: 0.86 }]}>
                  {isResetting ? <ActivityIndicator color={colors.background} /> : <Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>본인인증 확인</Text>}
                </Pressable>
                <Pressable onPress={() => setPwStep("request")} style={{ alignItems: "center", paddingVertical: 6 }}>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>휴대폰 번호 다시 입력하기</Text>
                </Pressable>
              </>
            )}

            {pwStep === "newpw" && (
              <>
                <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>본인인증이 완료되었습니다. 새로운 비밀번호를 두 번 입력해 주세요.</Text>
                <TextInput value={newPassword} onChangeText={setNewPassword} placeholder="새 비밀번호 (4자 이상)" placeholderTextColor={colors.muted} secureTextEntry returnKeyType="next" style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
                <TextInput value={confirmPassword} onChangeText={setConfirmPassword} placeholder="새 비밀번호 확인" placeholderTextColor={colors.muted} secureTextEntry returnKeyType="done" onSubmitEditing={handleSaveNewPassword} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
                {resetError && <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.error + "55" }}><Text style={{ color: colors.error, fontSize: 13, lineHeight: 19 }}>{resetError}</Text></View>}
                <Pressable disabled={isResetting} onPress={handleSaveNewPassword} style={({ pressed }) => [{ backgroundColor: colors.foreground, paddingVertical: 14, borderRadius: 12, alignItems: "center", opacity: isResetting ? 0.6 : 1 }, pressed && !isResetting && { transform: [{ scale: 0.98 }], opacity: 0.86 }]}>
                  {isResetting ? <ActivityIndicator color={colors.background} /> : <Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>비밀번호 설정 완료</Text>}
                </Pressable>
              </>
            )}
          </View>
        )}

        {/* 로그인으로 돌아가기 */}
        <Pressable onPress={() => router.back()} style={{ alignItems: "center", paddingVertical: 10 }}>
          <Text style={{ color: colors.muted, fontSize: 14 }}>로그인으로 돌아가기</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
