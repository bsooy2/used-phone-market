import { Stack, useRouter } from "expo-router";
import { useMemo } from "react";
import { FlatList, Pressable, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { GRADE_INFO } from "@/constants/phones";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useAuthStore } from "@/lib/auth-store";
import { formatKRW } from "@/lib/payment";
import { FEE_RATE, SettleRow, buildSettleRows, summarize } from "@/lib/settlement";

export default function SettlementScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, isSeller } = useAuthStore();
  const { userListings, orders } = useAppStore();

  const myListings = useMemo(
    () => (user ? userListings.filter((p) => p.sellerId === user.id) : []),
    [userListings, user],
  );

  const rows: SettleRow[] = useMemo(
    () => buildSettleRows(myListings, orders),
    [myListings, orders],
  );

  const summary = useMemo(() => summarize(rows), [rows]);

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 8, gap: 4 }}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>정산 내역</Text>
      </View>

      {!isSeller ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 32 }}>
          <IconSymbol name="chart.bar.fill" size={48} color={colors.muted} />
          <Text style={{ color: colors.muted, marginTop: 12, textAlign: "center" }}>
            판매자 회원만 정산 내역을 확인할 수 있습니다.
          </Text>
        </View>
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(r) => r.phone.id}
          contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 32 }}
          ListHeaderComponent={
            <View style={{ gap: 12, marginBottom: 4 }}>
              {/* 정산 요약 카드 */}
              <View style={{ backgroundColor: colors.primary, borderRadius: 18, padding: 18 }}>
                <Text style={{ color: colors.background, opacity: 0.8, fontSize: 13 }}>정산 예정 금액 (수수료 차감 후)</Text>
                <Text style={{ color: colors.background, fontSize: 30, fontWeight: "900", marginTop: 4 }}>
                  {formatKRW(summary.net)}
                </Text>
                <View style={{ flexDirection: "row", marginTop: 14, gap: 10 }}>
                  <SummaryStat label="판매 완료" value={`${summary.soldCount}건`} colors={colors} />
                  <SummaryStat label="총 판매액" value={formatKRW(summary.gross)} colors={colors} />
                  <SummaryStat label="수수료" value={formatKRW(summary.fee)} colors={colors} />
                </View>
              </View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 2 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>
                  플랫폼 수수료 {(FEE_RATE * 100).toFixed(1)}% 기준 · 등록 매물 {summary.listingCount}건
                </Text>
              </View>
            </View>
          }
          ListEmptyComponent={
            <View style={{ alignItems: "center", paddingVertical: 48 }}>
              <IconSymbol name="tag.fill" size={44} color={colors.muted} />
              <Text style={{ color: colors.muted, marginTop: 12 }}>등록한 매물이 없습니다.</Text>
            </View>
          }
          renderItem={({ item }) => {
            const g = GRADE_INFO[item.phone.grade];
            return (
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 14,
                  padding: 14,
                  borderWidth: 1,
                  borderColor: colors.border,
                  gap: 10,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 15, flex: 1 }}>
                    {item.phone.model} {item.phone.storage}
                  </Text>
                  <View
                    style={{
                      backgroundColor: item.sold ? colors.foreground : colors.border,
                      borderRadius: 8,
                      paddingHorizontal: 8,
                      paddingVertical: 3,
                    }}
                  >
                    <Text
                      style={{
                        color: item.sold ? colors.background : colors.muted,
                        fontSize: 11,
                        fontWeight: "700",
                      }}
                    >
                      {item.sold ? "판매완료" : "판매중"}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>판매가</Text>
                  <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "600" }}>
                    {formatKRW(item.phone.price)}
                  </Text>
                </View>
                {item.sold && (
                  <>
                    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                      <Text style={{ color: colors.muted, fontSize: 13 }}>수수료 ({(FEE_RATE * 100).toFixed(1)}%)</Text>
                      <Text style={{ color: colors.muted, fontSize: 13 }}>- {formatKRW(item.fee)}</Text>
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        borderTopWidth: 1,
                        borderTopColor: colors.border,
                        paddingTop: 8,
                      }}
                    >
                      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>정산액</Text>
                      <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>
                        {formatKRW(item.net)}
                      </Text>
                    </View>
                  </>
                )}
              </View>
            );
          }}
        />
      )}
    </ScreenContainer>
  );
}

function SummaryStat({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ flex: 1 }}>
      <Text style={{ color: colors.background, opacity: 0.7, fontSize: 11 }}>{label}</Text>
      <Text style={{ color: colors.background, fontSize: 13, fontWeight: "700", marginTop: 2 }}>{value}</Text>
    </View>
  );
}
