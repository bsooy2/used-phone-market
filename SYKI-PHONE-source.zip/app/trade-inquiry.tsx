import { useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { useLocalSearchParams, useRouter } from "expo-router";

import { PhotoLightbox } from "@/components/photo-lightbox";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";
import { InquiryTransactionType, useInquiryStore } from "@/lib/inquiry-store";
import { uploadImages } from "@/lib/upload";

export default function TradeInquiryScreen() {
  const colors = useColors();
  const router = useRouter();
  const { transactionId, transactionType, transactionLabel } = useLocalSearchParams<{ transactionId: string; transactionType: InquiryTransactionType; transactionLabel: string }>();
  const { user } = useAuthStore();
  const { createInquiry } = useInquiryStore();
  const [body, setBody] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const pickPhotos = async () => {
    const remaining = 3 - photos.length;
    if (remaining <= 0) {
      Alert.alert("사진은 최대 3장", "더 추가하려면 기존 사진을 삭제해 주세요.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: remaining,
      quality: 0.75,
    });
    if (!result.canceled) setPhotos((current) => [...current, ...result.assets.slice(0, remaining).map((asset) => asset.uri)]);
  };

  const submit = async () => {
    if (!user) {
      Alert.alert("로그인 필요", "거래 문의는 로그인 후 이용할 수 있습니다.", [{ text: "확인", onPress: () => router.replace("/auth") }]);
      return;
    }
    setIsSubmitting(true);
    let uploadedPhotos: string[];
    try {
      uploadedPhotos = await uploadImages(photos);
    } catch {
      setIsSubmitting(false);
      Alert.alert("사진 업로드 실패", "사진을 업로드하지 못했습니다. 네트워크를 확인한 뒤 다시 시도해 주세요.");
      return;
    }
    const result = createInquiry({ userId: user.id, authorName: user.nickname, transactionId, transactionType, transactionLabel, body, photos: uploadedPhotos });
    setIsSubmitting(false);
    if (!result.ok) {
      Alert.alert("입력 확인", result.error ?? "문의 등록에 실패했습니다.");
      return;
    }
    Alert.alert("문의 등록 완료", "사장님이 확인 후 답변을 남겨 드립니다.", [{ text: "확인", onPress: () => router.replace("/my-inquiries") }]);
  };

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 16, paddingBottom: 36 }} keyboardShouldPersistTaps="handled">
        <View><Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>거래 1:1 문의</Text><Text style={{ color: colors.muted, marginTop: 5, fontSize: 13 }}>거래와 관련된 궁금한 점을 남겨 주세요.</Text></View>
        <View style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 14, gap: 4 }}><Text style={{ color: colors.muted, fontSize: 11 }}>{transactionType === "order" ? "구매 거래" : "판매 신청"}</Text><Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>{transactionLabel}</Text></View>
        <TextInput value={body} onChangeText={setBody} placeholder="예: 배송 일정이나 검수 진행 상황을 문의합니다." placeholderTextColor={colors.muted} multiline numberOfLines={7} textAlignVertical="top" maxLength={500} style={{ minHeight: 150, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 14, color: colors.foreground, fontSize: 14, lineHeight: 21 }} />
        <Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>{body.length}/500</Text>
        <View style={{ gap: 8 }}><View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}><Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "800" }}>문의 사진 <Text style={{ color: colors.muted, fontWeight: "500" }}>(선택, 최대 3장)</Text></Text><Pressable onPress={pickPhotos} style={({ pressed }) => [{ borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: 8, paddingHorizontal: 11, paddingVertical: 7 }, pressed && { opacity: 0.7 }]}><Text style={{ color: colors.primary, fontSize: 12, fontWeight: "800" }}>사진 추가</Text></Pressable></View>{photos.length > 0 && <View style={{ flexDirection: "row", gap: 8 }}>{photos.map((uri, index) => <View key={uri} style={{ width: 76, height: 76 }}><Pressable onPress={() => setLightboxIndex(index)}><Image source={{ uri }} style={{ width: 76, height: 76, borderRadius: 9 }} contentFit="cover" /></Pressable><Pressable onPress={() => setPhotos((current) => current.filter((_, itemIndex) => itemIndex !== index))} style={{ position: "absolute", top: -6, right: -6, backgroundColor: colors.foreground, borderRadius: 12, width: 22, height: 22, alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.background, fontSize: 13, fontWeight: "900" }}>×</Text></Pressable></View>)}</View>}</View>
        <Pressable disabled={isSubmitting} onPress={submit} style={({ pressed }) => [{ backgroundColor: colors.foreground, paddingVertical: 15, borderRadius: 12, alignItems: "center", opacity: isSubmitting ? 0.55 : 1 }, pressed && !isSubmitting && { opacity: 0.82, transform: [{ scale: 0.98 }] }]}><Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>{isSubmitting ? "사진 업로드 중..." : "문의 등록"}</Text></Pressable>
      </ScrollView>
      <PhotoLightbox photos={photos} initialIndex={lightboxIndex ?? 0} visible={lightboxIndex !== null} onClose={() => setLightboxIndex(null)} />
    </ScreenContainer>
  );
}
