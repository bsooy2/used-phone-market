import { Stack, useRouter } from "expo-router";
import { FlatList, Pressable, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { AppNotification } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { ADMIN_USER_ID, useAppStore } from "@/lib/app-store";
import { useAdminStore } from "@/lib/admin-store";
import { useAuthStore } from "@/lib/auth-store";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "방금 전";
  if (m < 60) return `${m}분 전`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}시간 전`;
  const d = Math.floor(h / 24);
  return `${d}일 전`;
}

const KIND_ICON: Record<AppNotification["kind"], any> = {
  order: "bag.fill",
  sell: "tag.fill",
  system: "bell.fill",
};

export default function NotificationsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuthStore();
  const { isAdmin } = useAdminStore();
  const { notificationsFor, markNotificationRead, markAllNotificationsRead } = useAppStore();

  // 일반 사용자 알림 + 고객 공통 알림 + (관리자 모드일 때) 관리자 알림을 합쳐 최신순 정렬
  const items = (() => {
    const userItems = user ? notificationsFor(user.id) : [];
    const customerItems = user ? notificationsFor("__customer__") : [];
    const adminItems = isAdmin ? notificationsFor(ADMIN_USER_ID) : [];
    return [...userItems, ...customerItems, ...adminItems].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  })();

  const canView = !!user || isAdmin;

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>알림</Text>
        {items.length > 0 && (
          <Pressable
            onPress={() => {
              if (user) markAllNotificationsRead(user.id);
              if (isAdmin) markAllNotificationsRead(ADMIN_USER_ID);
            }}
            style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}
          >
            <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "600" }}>모두 읽음</Text>
          </Pressable>
        )}
      </View>

      {!canView ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 32 }}>
          <IconSymbol name="bell.fill" size={48} color={colors.muted} />
          <Text style={{ color: colors.muted, marginTop: 12 }}>로그인 후 이용할 수 있습니다.</Text>
        </View>
      ) : items.length === 0 ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 32 }}>
          <IconSymbol name="bell.fill" size={48} color={colors.muted} />
          <Text style={{ color: colors.muted, marginTop: 12 }}>받은 알림이 없습니다.</Text>
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(n) => n.id}
          contentContainerStyle={{ padding: 16, gap: 10 }}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => markNotificationRead(item.id)}
              style={({ pressed }) => [
                {
                  flexDirection: "row",
                  gap: 12,
                  padding: 14,
                  borderRadius: 14,
                  backgroundColor: item.read ? colors.surface : colors.primary + "10",
                  borderWidth: 1,
                  borderColor: item.read ? colors.border : colors.primary + "40",
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <View
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 19,
                  backgroundColor: colors.primary,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <IconSymbol name={KIND_ICON[item.kind]} size={18} color={colors.background} />
              </View>
              <View style={{ flex: 1 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 14, flex: 1 }}>
                    {item.title}
                  </Text>
                  {!item.read && (
                    <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary }} />
                  )}
                </View>
                <Text style={{ color: colors.muted, fontSize: 13, marginTop: 4, lineHeight: 18 }}>{item.body}</Text>
                <Text style={{ color: colors.muted, fontSize: 11, marginTop: 6 }}>{timeAgo(item.createdAt)}</Text>
              </View>
            </Pressable>
          )}
        />
      )}
    </ScreenContainer>
  );
}
