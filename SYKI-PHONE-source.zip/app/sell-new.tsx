import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { GRADE_INFO } from "@/constants/phones";
import { Grade, Phone } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useAuthStore } from "@/lib/auth-store";

const GRADES: Grade[] = ["S", "A", "B", "C"];
const COLOR_SWATCHES = ["#1F2937", "#2563EB", "#7C3AED", "#374151", "#9CA3AF", "#1D4ED8"];

export default function SellNewScreen() {
  const colors = useColors();
  const { user, isSeller } = useAuthStore();
  const { addListing } = useAppStore();

  const [brand, setBrand] = useState("Apple");
  const [model, setModel] = useState("");
  const [storage, setStorage] = useState("");
  const [color, setColor] = useState("");
  const [grade, setGrade] = useState<Grade>("A");
  const [battery, setBattery] = useState("");
  const [price, setPrice] = useState("");
  const [accessories, setAccessories] = useState("본체");
  const [description, setDescription] = useState("");
  const [swatch, setSwatch] = useState(COLOR_SWATCHES[0]);

  // 권한 없는 경우 차단 (안전장치)
  if (!user || !isSeller) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="p-6 items-center justify-center">
        <IconSymbol name="lock.fill" size={48} color={colors.muted} />
        <Text className="text-lg font-bold text-foreground mt-4">판매자 전용 기능입니다</Text>
        <Text className="text-sm text-muted mt-2 text-center">
          매물 등록은 판매자 회원만 이용할 수 있습니다.
        </Text>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginTop: 24, backgroundColor: colors.primary, paddingHorizontal: 28, paddingVertical: 14, borderRadius: 12 }}
        >
          <Text style={{ color: colors.background, fontWeight: "700" }}>돌아가기</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const handleSubmit = () => {
    if (!model.trim() || !storage.trim() || !price.trim()) {
      Alert.alert("입력 확인", "모델명, 용량, 판매가는 필수 입력입니다.");
      return;
    }
    const priceNum = parseInt(price.replace(/[^0-9]/g, ""), 10);
    if (!priceNum || priceNum <= 0) {
      Alert.alert("입력 확인", "올바른 판매가를 입력해 주세요.");
      return;
    }
    const batteryNum = parseInt(battery.replace(/[^0-9]/g, ""), 10) || 0;

    const newPhone: Phone = {
      id: `user_${Date.now()}`,
      brand: brand.trim() || "기타",
      model: model.trim(),
      storage: storage.trim(),
      color: color.trim() || "기본",
      grade,
      battery: batteryNum,
      price: priceNum,
      buyPrice: Math.round(priceNum * 0.85),
      image: swatch,
      description: description.trim() || "판매자가 등록한 매물입니다.",
      accessories: accessories.trim() || "본체",
      createdAt: new Date().toISOString().slice(0, 10),
      sellerId: user.id,
      sellerName: user.nickname,
    };
    addListing(newPhone);
    Alert.alert("등록 완료", "매물이 등록되었습니다.", [
      { text: "확인", onPress: () => router.back() },
    ]);
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      {/* 헤더 */}
      <View className="flex-row items-center justify-between px-5 py-3 border-b border-border">
        <TouchableOpacity onPress={() => router.back()} hitSlop={10} style={{ opacity: 0.7 }}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </TouchableOpacity>
        <Text className="text-base font-bold text-foreground">매물 등록</Text>
        <View style={{ width: 26 }} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
          {/* 제조사 */}
          <Field label="제조사">
            <View className="flex-row gap-2">
              {["Apple", "Samsung", "기타"].map((b) => {
                const active = brand === b;
                return (
                  <Pressable
                    key={b}
                    onPress={() => setBrand(b)}
                    style={({ pressed }) => [
                      { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, borderColor: active ? colors.primary : colors.border, backgroundColor: active ? colors.primary + "12" : colors.surface },
                      pressed && { opacity: 0.85 },
                    ]}
                  >
                    <Text style={{ color: active ? colors.primary : colors.foreground, fontWeight: "600" }}>{b}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <Field label="모델명 *">
            <TextInput value={model} onChangeText={setModel} placeholder="예) iPhone 14 Pro" placeholderTextColor={colors.muted} style={input(colors)} />
          </Field>

          <View className="flex-row gap-3">
            <View style={{ flex: 1 }}>
              <Field label="용량 *">
                <TextInput value={storage} onChangeText={setStorage} placeholder="예) 256GB" placeholderTextColor={colors.muted} style={input(colors)} />
              </Field>
            </View>
            <View style={{ flex: 1 }}>
              <Field label="색상">
                <TextInput value={color} onChangeText={setColor} placeholder="예) 딥퍼플" placeholderTextColor={colors.muted} style={input(colors)} />
              </Field>
            </View>
          </View>

          {/* 상태 등급 */}
          <Field label="상태 등급">
            <View className="flex-row gap-2">
              {GRADES.map((g) => {
                const active = grade === g;
                const info = GRADE_INFO[g];
                return (
                  <Pressable
                    key={g}
                    onPress={() => setGrade(g)}
                    style={({ pressed }) => [
                      { flex: 1, alignItems: "center", paddingVertical: 12, borderRadius: 10, borderWidth: 1.5, borderColor: active ? info.color : colors.border, backgroundColor: active ? info.color + "1A" : colors.surface },
                      pressed && { opacity: 0.85 },
                    ]}
                  >
                    <Text style={{ color: active ? info.color : colors.foreground, fontWeight: "700" }}>{info.label}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <View className="flex-row gap-3">
            <View style={{ flex: 1 }}>
              <Field label="배터리 효율(%)">
                <TextInput value={battery} onChangeText={setBattery} placeholder="예) 92" placeholderTextColor={colors.muted} keyboardType="number-pad" style={input(colors)} />
              </Field>
            </View>
            <View style={{ flex: 1 }}>
              <Field label="판매가(원) *">
                <TextInput value={price} onChangeText={setPrice} placeholder="예) 850000" placeholderTextColor={colors.muted} keyboardType="number-pad" style={input(colors)} />
              </Field>
            </View>
          </View>

          <Field label="구성품">
            <TextInput value={accessories} onChangeText={setAccessories} placeholder="예) 본체, 충전기, 박스" placeholderTextColor={colors.muted} style={input(colors)} />
          </Field>

          {/* 썸네일 색상 */}
          <Field label="썸네일 색상">
            <View className="flex-row gap-3">
              {COLOR_SWATCHES.map((c) => {
                const active = swatch === c;
                return (
                  <Pressable key={c} onPress={() => setSwatch(c)} style={({ pressed }) => [{ opacity: pressed ? 0.8 : 1 }]}>
                    <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: c, borderWidth: active ? 3 : 0, borderColor: colors.primary }} />
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <Field label="상세 설명">
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="기기 상태, 구매 시기, 특이사항 등을 적어주세요."
              placeholderTextColor={colors.muted}
              multiline
              style={[input(colors), { height: 110, textAlignVertical: "top" }]}
            />
          </Field>

          <TouchableOpacity
            onPress={handleSubmit}
            activeOpacity={0.85}
            style={{ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 12 }}
          >
            <Text style={{ color: colors.background, fontWeight: "700", fontSize: 16 }}>매물 등록하기</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 18 }}>
      <Text className="text-sm font-semibold text-foreground mb-2">{label}</Text>
      {children}
    </View>
  );
}

function input(colors: ReturnType<typeof useColors>) {
  return {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: colors.foreground,
  } as const;
}
