import { useState } from "react";
import { Text, View, TextInput, Pressable, Alert, ScrollView } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useRouter } from "expo-router";

export default function AdminBroadcastScreen() {
  const colors = useColors();
  const router = useRouter();
  const { pushNotification } = useAppStore();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [sent, setSent] = useState(false);

  const handleSend = () => {
    if (!title.trim()) {
      Alert.alert("입력 오류", "알림 제목을 입력해 주세요.");
      return;
    }
    Alert.alert("알림 발송", `"${title}" 알림을 모든 고객에게 발송하시겠습니까?`, [
      { text: "취소", style: "cancel" },
      {
        text: "발송",
        onPress: () => {
          pushNotification({
            kind: "system",
            title: title.trim(),
            body: body.trim() || title.trim(),
            userId: "__customer__",
          });
          setSent(true);
          Alert.alert("발송 완료", "모든 고객에게 알림이 발송되었습니다.", [
            { text: "확인", onPress: () => router.back() },
          ]);
        },
      },
    ]);
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ gap: 16, paddingBottom: 40 }}>
        <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>일괄 알림 발송</Text>
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 18 }}>
          모든 고객에게 동시에 알림을 보냅니다.{"\n"}공지사항, 이벤트 안내, 긴급 공지 등에 활용하세요.
        </Text>

        <View style={{ gap: 8 }}>
          <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }}>알림 제목 *</Text>
          <TextInput
            value={title}
            onChangeText={setTitle}
            placeholder="예: 여름 특가 이벤트 안내"
            placeholderTextColor={colors.muted}
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }}
          />
        </View>

        <View style={{ gap: 8 }}>
          <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }}>알림 내용 (선택)</Text>
          <TextInput
            value={body}
            onChangeText={setBody}
            placeholder="상세 내용을 입력하세요"
            placeholderTextColor={colors.muted}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground, minHeight: 100 }}
          />
        </View>

        <Pressable
          onPress={handleSend}
          disabled={sent}
          style={{ backgroundColor: colors.foreground, paddingVertical: 16, borderRadius: 14, alignItems: "center", opacity: sent ? 0.5 : 1 }}
        >
          <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>
            {sent ? "발송 완료" : "전체 고객에게 발송"}
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
