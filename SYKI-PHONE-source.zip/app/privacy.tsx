import { Stack, useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

const EFFECTIVE_DATE = "2025년 7월 29일";
const COMPANY_NAME = "SYKI PHONE (시끼폰)";
const CONTACT_PHONE = "010-2394-1420";
const LOCATION = "제주특별자치도 서귀포시";

export default function PrivacyScreen() {
  const colors = useColors();
  const router = useRouter();

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      {/* 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
          borderBottomWidth: 0.5,
          borderBottomColor: colors.border,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>개인정보처리방침</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60, gap: 24 }}>
        <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>개인정보처리방침</Text>
        <Text style={{ color: colors.muted, fontSize: 13 }}>시행일: {EFFECTIVE_DATE}</Text>

        <Section title="1. 개인정보의 처리 목적" colors={colors}>
          {`${COMPANY_NAME}(이하 "회사")은 다음의 목적을 위하여 개인정보를 처리합니다. 처리하고 있는 개인정보는 다음의 목적 이외의 용도로는 이용되지 않으며, 이용 목적이 변경되는 경우에는 별도의 동의를 받는 등 필요한 조치를 이행할 예정입니다.

• 중고폰 매입 견적 서비스 제공
• 중고폰 매물 등록 및 거래 중개
• 회원 가입 및 관리
• 결제 및 정산 처리
• 서비스 이용 관련 문의 응대`}
        </Section>

        <Section title="2. 수집하는 개인정보 항목" colors={colors}>
          {`회사는 서비스 제공을 위해 아래와 같은 개인정보를 수집합니다.

[필수 항목]
• 이름, 연락처(휴대폰 번호)
• 이메일 주소
• 배송지 주소(우편번호 포함)

[선택 항목]
• 생년월일, 성별
• 판매정산 및 환불시 입금 계좌 정보(은행명, 계좌번호, 예금주)
• 기기 사진(견적 신청 시 첨부)

[자동 수집 항목]
• 앱 이용 기록, 접속 로그, 기기 정보(OS 버전, 기기 모델)`}
        </Section>

        <Section title="3. 개인정보의 처리 및 보유 기간" colors={colors}>
          {`회사는 법령에 따른 개인정보 보유·이용 기간 또는 정보주체로부터 개인정보를 수집 시에 동의받은 개인정보 보유·이용 기간 내에서 개인정보를 처리·보유합니다.

• 회원 정보: 회원 탈퇴 시까지 (탈퇴 후 즉시 파기)
• 거래 기록: 전자상거래법에 따라 5년 보관
• 결제 기록: 전자상거래법에 따라 5년 보관
• 접속 로그: 통신비밀보호법에 따라 3개월 보관`}
        </Section>

        <Section title="4. 개인정보의 제3자 제공" colors={colors}>
          {`회사는 정보주체의 개인정보를 제1조에서 명시한 범위 내에서만 처리하며, 정보주체의 동의, 법률의 특별한 규정 등 개인정보보호법 제17조에 해당하는 경우에만 개인정보를 제3자에게 제공합니다.

현재 개인정보를 제3자에게 제공하고 있지 않습니다.`}
        </Section>

        <Section title="5. 개인정보의 파기 절차 및 방법" colors={colors}>
          {`회사는 개인정보 보유 기간의 경과, 처리 목적 달성 등 개인정보가 불필요하게 되었을 때에는 지체 없이 해당 개인정보를 파기합니다.

• 전자적 파일: 복구 불가능한 방법으로 영구 삭제
• 종이 문서: 분쇄기로 분쇄하거나 소각`}
        </Section>

        <Section title="6. 정보주체의 권리·의무 및 행사 방법" colors={colors}>
          {`정보주체는 회사에 대해 언제든지 다음 각 호의 개인정보 보호 관련 권리를 행사할 수 있습니다.

• 개인정보 열람 요구
• 오류 등이 있을 경우 정정 요구
• 삭제 요구
• 처리 정지 요구

위 권리 행사는 앱 내 마이페이지 또는 전화(${CONTACT_PHONE})를 통해 하실 수 있습니다.`}
        </Section>

        <Section title="7. 개인정보의 안전성 확보 조치" colors={colors}>
          {`회사는 개인정보의 안전성 확보를 위해 다음과 같은 조치를 취하고 있습니다.

• 개인정보의 암호화 (전송 시 SSL/TLS 적용)
• 접근 권한 관리 및 제한
• 개인정보 접근 기록의 보관 및 위·변조 방지
• 비인가자에 대한 출입 통제`}
        </Section>

        <Section title="8. 개인정보 보호책임자" colors={colors}>
          {`회사는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만 처리 및 피해 구제를 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.

• 상호: ${COMPANY_NAME}
• 연락처: ${CONTACT_PHONE}
• 소재지: ${LOCATION}`}
        </Section>

        <Section title="9. 개인정보 처리방침 변경" colors={colors}>
          {`이 개인정보처리방침은 ${EFFECTIVE_DATE}부터 적용됩니다. 이전의 개인정보처리방침은 아래에서 확인하실 수 있습니다.

변경 사항이 있을 경우 시행 7일 전부터 앱 내 공지사항을 통해 알려드리겠습니다.`}
        </Section>

        <View style={{ borderTopWidth: 0.5, borderTopColor: colors.border, paddingTop: 16 }}>
          <Text style={{ color: colors.muted, fontSize: 12, textAlign: "center" }}>
            {COMPANY_NAME} | {CONTACT_PHONE} | {LOCATION}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function Section({
  title,
  children,
  colors,
}: {
  title: string;
  children: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>{title}</Text>
      <Text style={{ color: colors.foreground, fontSize: 14, lineHeight: 22 }}>{children}</Text>
    </View>
  );
}
