import { useState } from "react";
import { Alert, Image, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { PhotoLightbox } from "@/components/photo-lightbox";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";
import { REVIEW_RATING_FILTERS, type ReviewRatingFilter } from "@/lib/review-filters";
import { useReviewStore } from "@/lib/review-store";

const QUICK_SEARCH_KEYWORDS = ["아이폰", "갤럭시", "만족", "친절", "배송"];

function maskedName(name: string): string {
  if (name.length <= 1) return "고객";
  return `${name[0]}${"*".repeat(Math.max(1, name.length - 1))}`;
}

function RatingStars({ rating }: { rating: number }) {
  const colors = useColors();
  return <Text style={{ color: colors.primary, fontSize: 17, letterSpacing: 1 }}>{"★".repeat(rating)}<Text style={{ color: colors.border }}>{"★".repeat(5 - rating)}</Text></Text>;
}

export default function ReviewsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuthStore();
  const { getPublicReviews, loaded, reportReview } = useReviewStore();
  const [query, setQuery] = useState("");
  const [ratingFilter, setRatingFilter] = useState<ReviewRatingFilter>("all");
  const [lightboxPhotos, setLightboxPhotos] = useState<string[] | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const allReviews = getPublicReviews();
  const reviews = getPublicReviews(query, ratingFilter);
  const average = allReviews.length ? allReviews.reduce((sum, review) => sum + review.rating, 0) / allReviews.length : 0;
  const hasActiveFilter = Boolean(query.trim()) || ratingFilter !== "all";
  const clearFilters = () => {
    setQuery("");
    setRatingFilter("all");
  };

  const report = (id: string) => {
    if (!user) {
      Alert.alert("로그인 필요", "후기 신고는 로그인 후 이용할 수 있습니다.", [{ text: "취소", style: "cancel" }, { text: "로그인", onPress: () => router.push("/auth") }]);
      return;
    }
    Alert.alert("후기 신고", "부적절한 후기인가요? 신고 내용은 관리자에게 전달됩니다.", [
      { text: "취소", style: "cancel" },
      { text: "신고", style: "destructive", onPress: () => {
        const result = reportReview(id, user.id);
        Alert.alert(result.ok ? "신고 완료" : "신고 불가", result.ok ? "관리자가 확인 후 처리합니다." : result.error ?? "신고에 실패했습니다.");
      } },
    ]);
  };

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
        <View style={{ gap: 5 }}>
          <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>고객 후기</Text>
          <Text style={{ color: colors.muted, fontSize: 13 }}>거래를 완료한 고객이 남긴 후기입니다.</Text>
        </View>
        {allReviews.length > 0 && <View style={{ backgroundColor: colors.foreground, borderRadius: 14, padding: 16, flexDirection: "row", alignItems: "center", gap: 12 }}><Text style={{ color: colors.background, fontSize: 28, fontWeight: "900" }}>{average.toFixed(1)}</Text><View><Text style={{ color: colors.background, fontSize: 18, letterSpacing: 1 }}>{"★".repeat(Math.round(average))}</Text><Text style={{ color: colors.background, opacity: 0.7, fontSize: 12 }}>{allReviews.length}개의 공개 후기</Text></View></View>}
        {loaded && allReviews.length > 0 && <View style={{ gap: 10 }}>
          <View style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, flexDirection: "row", alignItems: "center" }}>
            <TextInput value={query} onChangeText={setQuery} placeholder="후기 내용, 거래 모델, 작성자 검색" placeholderTextColor={colors.muted} returnKeyType="search" style={{ flex: 1, color: colors.foreground, fontSize: 14, paddingVertical: 13 }} />
            {query.length > 0 && <Pressable onPress={() => setQuery("")} style={{ padding: 4 }}><IconSymbol name="xmark" size={16} color={colors.muted} /></Pressable>}
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6, paddingRight: 2 }}>
            {QUICK_SEARCH_KEYWORDS.map((kw) => {
              const active = query.trim() === kw;
              return <Pressable key={kw} onPress={() => setQuery(active ? "" : kw)} style={({ pressed }) => [{ borderRadius: 14, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: active ? colors.foreground : colors.surface, borderWidth: 1, borderColor: active ? colors.foreground : colors.border }, pressed && { opacity: 0.72 }]}><Text style={{ color: active ? colors.background : colors.muted, fontSize: 11, fontWeight: "700" }}>#{kw}</Text></Pressable>;
            })}
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7, paddingRight: 2 }}>
            {REVIEW_RATING_FILTERS.map((filter) => {
              const active = ratingFilter === filter.value;
              return <Pressable key={filter.label} onPress={() => setRatingFilter(filter.value)} style={({ pressed }) => [{ borderRadius: 18, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: active ? colors.foreground : colors.surface, borderWidth: 1, borderColor: active ? colors.foreground : colors.border }, pressed && { opacity: 0.72 }]}><Text style={{ color: active ? colors.background : colors.foreground, fontWeight: "800", fontSize: 12 }}>{filter.value === "all" ? filter.label : `★ ${filter.label}`}</Text></Pressable>;
            })}
          </ScrollView>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.muted, fontSize: 12 }}>{hasActiveFilter ? `조건에 맞는 후기 ${reviews.length}개` : `전체 후기 ${reviews.length}개`}</Text>{hasActiveFilter && <Pressable onPress={clearFilters} style={({ pressed }) => [{ paddingVertical: 3 }, pressed && { opacity: 0.6 }]}><Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "800" }}>필터 초기화</Text></Pressable>}</View>
        </View>}
        {!loaded ? <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 40 }}>후기를 불러오는 중...</Text> : allReviews.length === 0 ? <View style={{ alignItems: "center", gap: 8, paddingVertical: 60 }}><Text style={{ color: colors.muted, fontSize: 15 }}>아직 공개된 후기가 없습니다.</Text><Text style={{ color: colors.muted, fontSize: 12 }}>거래 완료 후 사진 후기를 남겨 주세요.</Text></View> : reviews.length === 0 ? <View style={{ alignItems: "center", gap: 8, paddingVertical: 60 }}><Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>조건에 맞는 후기가 없습니다.</Text><Text style={{ color: colors.muted, fontSize: 12, textAlign: "center" }}>다른 검색어 또는 별점을 선택해 보세요.</Text><Pressable onPress={clearFilters} style={({ pressed }) => [{ marginTop: 6, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 13, paddingVertical: 9, borderRadius: 9 }, pressed && { opacity: 0.65 }]}><Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 12 }}>검색 조건 초기화</Text></Pressable></View> : reviews.map((review) => (
          <View key={review.id} style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 15, gap: 10, borderWidth: 1, borderColor: colors.border }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><View style={{ gap: 3 }}><Text style={{ color: colors.foreground, fontWeight: "800" }}>{maskedName(review.authorName)} 고객</Text><Text style={{ color: colors.muted, fontSize: 11 }}>{review.transactionType === "purchase" ? "구매 거래" : "판매 거래"} · {new Date(review.createdAt).toLocaleDateString("ko-KR")}</Text></View><RatingStars rating={review.rating} /></View>
            <Text style={{ color: colors.foreground, fontSize: 14, lineHeight: 21 }}>{review.text}</Text>
            {review.photos.length > 0 && <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{review.photos.map((uri, index) => <Pressable key={`${uri}-${index}`} onPress={() => { setLightboxPhotos(review.photos); setLightboxIndex(index); }}><Image source={{ uri }} style={{ width: 82, height: 82, borderRadius: 8 }} /></Pressable>)}</ScrollView>}
            {review.adminReply && <View style={{ backgroundColor: colors.background, borderRadius: 10, padding: 10, borderWidth: 1, borderColor: colors.border, gap: 3, marginTop: 4 }}><Text style={{ color: colors.primary, fontSize: 11, fontWeight: "800" }}>사장님 답글</Text><Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 18 }}>{review.adminReply.text}</Text></View>}
            <Pressable onPress={() => report(review.id)} style={({ pressed }) => [{ alignSelf: "flex-end", paddingVertical: 3 }, pressed && { opacity: 0.6 }]}><Text style={{ color: colors.muted, fontSize: 11 }}>후기 신고</Text></Pressable>
          </View>
        ))}
      </ScrollView>
      <PhotoLightbox photos={lightboxPhotos ?? []} initialIndex={lightboxIndex} visible={Boolean(lightboxPhotos)} onClose={() => setLightboxPhotos(null)} />
    </ScreenContainer>
  );
}
