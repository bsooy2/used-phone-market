import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { kakaoPayApprove } from "@/lib/payment";

export default function KakaoPaySuccessScreen() {
  const colors = useColors();
  const router = useRouter();
  const { pg_token } = useLocalSearchParams<{ pg_token?: string }>();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    async function approve() {
      if (!pg_token) {
        setStatus("error");
        setErrorMsg("결제 토큰이 없습니다.");
        return;
      }
      try {
        await kakaoPayApprove(pg_token);
        setStatus("success");
      } catch (e: any) {
        setStatus("error");
        setErrorMsg(e?.message || "결제 승인에 실패했습니다.");
      }
    }
    approve();
  }, [pg_token]);

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center p-6">
      {status === "loading" && (
        <View style={{ alignItems: "center", gap: 16 }}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "600" }}>
            결제 승인 처리 중...
          </Text>
        </View>
      )}
      {status === "success" && (
        <View style={{ alignItems: "center", gap: 16 }}>
          <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: "#22C55E20", alignItems: "center", justifyContent: "center" }}>
            <IconSymbol name="checkmark.circle.fill" size={40} color="#22C55E" />
          </View>
          <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>
            결제가 완료되었습니다
          </Text>
          <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center" }}>
            카카오페이 결제가 정상적으로 처리되었습니다.{"\n"}주문 내역에서 확인하실 수 있습니다.
          </Text>
        </View>
      )}
      {status === "error" && (
        <View style={{ alignItems: "center", gap: 16 }}>
          <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: "#EF444420", alignItems: "center", justifyContent: "center" }}>
            <IconSymbol name="xmark.circle.fill" size={40} color="#EF4444" />
          </View>
          <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>
            결제 승인 실패
          </Text>
          <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center" }}>
            {errorMsg}
          </Text>
        </View>
      )}
    </ScreenContainer>
  );
}
