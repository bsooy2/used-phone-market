import { useRouter } from "expo-router";
import { Pressable, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function KakaoPayCancelScreen() {
  const colors = useColors();
  const router = useRouter();

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center p-6">
      <View style={{ alignItems: "center", gap: 16 }}>
        <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center" }}>
          <IconSymbol name="xmark.circle.fill" size={40} color={colors.muted} />
        </View>
        <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>
          결제가 취소되었습니다
        </Text>
        <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center" }}>
          카카오페이 결제를 취소하셨습니다.{"\n"}다시 시도하시려면 아래 버튼을 눌러주세요.
        </Text>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [
            {
              marginTop: 12,
              backgroundColor: colors.primary,
              paddingHorizontal: 32,
              paddingVertical: 14,
              borderRadius: 12,
            },
            pressed && { opacity: 0.85 },
          ]}
        >
          <Text style={{ color: colors.background, fontWeight: "700", fontSize: 15 }}>돌아가기</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
