import { useRouter } from "expo-router";
import { Pressable, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function KakaoPayFailScreen() {
  const colors = useColors();
  const router = useRouter();

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center p-6">
      <View style={{ alignItems: "center", gap: 16 }}>
        <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: "#EF444420", alignItems: "center", justifyContent: "center" }}>
          <IconSymbol name="xmark.circle.fill" size={40} color="#EF4444" />
        </View>
        <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>
          결제에 실패했습니다
        </Text>
        <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center" }}>
          결제 처리 중 오류가 발생했습니다.{"\n"}잠시 후 다시 시도해 주세요.
        </Text>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [
            {
              marginTop: 12,
              backgroundColor: colors.primary,
              paddingHorizontal: 32,
              paddingVertical: 14,
              borderRadius: 12,
            },
            pressed && { opacity: 0.85 },
          ]}
        >
          <Text style={{ color: colors.background, fontWeight: "700", fontSize: 15 }}>돌아가기</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
