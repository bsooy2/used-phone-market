import * as ImagePicker from "expo-image-picker";
import { useEffect, useState } from "react";
import { Alert, Image, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";
import { persistReviewPhoto } from "@/lib/review-photos";
import { PHOTO_REVIEW_REWARD_POINTS, REVIEW_MAX_EDITS, REVIEW_MAX_PHOTOS } from "@/lib/review-rules";
import { ReviewTransactionType, useReviewStore } from "@/lib/review-store";

export default function WriteReviewScreen() {
  const colors = useColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ transactionId: string; transactionType: ReviewTransactionType; transactionLabel?: string; reviewId?: string }>();
  const { user } = useAuthStore();
  const { reviews, loaded, createReview, updateReview } = useReviewStore();
  const existing = reviews.find((review) => review.id === params.reviewId && review.userId === user?.id);
  const [text, setText] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [rating, setRating] = useState(5);

  useEffect(() => {
    if (existing) {
      setText(existing.text);
      setPhotos(existing.photos);
      setRating(existing.rating);
    }
  }, [existing?.id]);

  const isEdit = Boolean(existing);
  const canEdit = !existing || existing.editCount < REVIEW_MAX_EDITS;

  const addPhoto = async () => {
    if (!canEdit || photos.length >= REVIEW_MAX_PHOTOS) {
      Alert.alert("안내", `사진은 최대 ${REVIEW_MAX_PHOTOS}장까지 첨부 가능합니다.`);
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.8 });
    if (result.canceled || !result.assets[0]) return;
    const savedUri = await persistReviewPhoto(result.assets[0].uri, photos.length);
    setPhotos((current) => [...current, savedUri]);
  };

  const completeReview = () => {
    if (!user || !params.transactionId || !params.transactionType) {
      Alert.alert("오류", "로그인 또는 거래 정보를 확인해 주세요.");
      return;
    }
    if (isEdit) {
      const result = updateReview(existing!.id, user.id, text, photos, rating);
      if (!result.ok) {
        Alert.alert("수정 불가", result.error ?? "후기 수정에 실패했습니다.");
        return;
      }
      Alert.alert("수정 완료", `후기가 수정되었습니다. (${existing!.editCount + 1}/${REVIEW_MAX_EDITS}회)`, [{ text: "확인", onPress: () => router.back() }]);
      return;
    }

    const submit = (awardPhotoReward: boolean) => {
      const result = createReview({
        userId: user.id,
        transactionId: params.transactionId,
        transactionType: params.transactionType,
        transactionLabel: params.transactionLabel ?? "거래 후기",
        authorName: user.nickname,
        text,
        photos,
        rating,
      }, awardPhotoReward);
      if (!result.ok) {
        Alert.alert("작성 불가", result.error);
        return;
      }
      const message = result.pointsAwarded > 0
        ? `후기가 등록되어 ${result.pointsAwarded.toLocaleString()}P가 적립되었습니다.`
        : "후기가 등록되었습니다. 사진을 첨부하면 10,000P를 적립받을 수 있습니다.";
      Alert.alert("후기 작성 완료", message, [{ text: "확인", onPress: () => router.back() }]);
    };

    if (photos.length > 0) {
      Alert.alert("사진 후기 보상", `후기 작성 완료 시 ${PHOTO_REVIEW_REWARD_POINTS.toLocaleString()}P가 즉시 적립됩니다.`, [
        { text: "취소", style: "cancel" },
        { text: "후기 작성 완료", onPress: () => submit(true) },
      ]);
    } else {
      submit(false);
    }
  };

  if (!loaded) {
    return <ScreenContainer className="items-center justify-center"><Text style={{ color: colors.muted }}>후기 정보를 불러오는 중...</Text></ScreenContainer>;
  }

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 16, paddingBottom: 36 }} keyboardShouldPersistTaps="handled">
        <View style={{ gap: 4 }}>
          <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>{isEdit ? "후기 수정" : "거래 후기 작성"}</Text>
          <Text style={{ color: colors.muted, fontSize: 13 }}>{params.transactionLabel ?? "완료된 거래"}</Text>
          {!isEdit && <Text style={{ color: colors.primary, fontSize: 13, fontWeight: "800" }}>사진을 1장 이상 첨부하면 10,000P가 적립됩니다.</Text>}
          {isEdit && <Text style={{ color: colors.muted, fontSize: 12 }}>수정 가능 횟수: {existing!.editCount}/{REVIEW_MAX_EDITS}회</Text>}
        </View>

        <View style={{ gap: 8 }}>
          <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "800" }}>별점</Text>
          <View style={{ flexDirection: "row", gap: 5 }}>
            {[1, 2, 3, 4, 5].map((value) => <Pressable key={value} onPress={() => canEdit && setRating(value)} hitSlop={5}><Text style={{ color: value <= rating ? colors.primary : colors.border, fontSize: 32, lineHeight: 36 }}>★</Text></Pressable>)}
          </View>
          <Text style={{ color: colors.muted, fontSize: 12 }}>{rating}점 · 작성 완료 후 고객 후기 목록에 공개됩니다.</Text>
        </View>

        <View style={{ gap: 8 }}>
          <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "800" }}>후기 사진 (최대 {REVIEW_MAX_PHOTOS}장)</Text>
          <View style={{ flexDirection: "row", gap: 10, flexWrap: "wrap" }}>
            {photos.map((uri, index) => (
              <View key={`${uri}-${index}`} style={{ position: "relative" }}>
                <Image source={{ uri }} style={{ width: 88, height: 88, borderRadius: 10, backgroundColor: colors.surface }} />
                {canEdit && <Pressable onPress={() => setPhotos((current) => current.filter((_, itemIndex) => itemIndex !== index))} style={{ position: "absolute", top: -7, right: -7, width: 24, height: 24, borderRadius: 12, backgroundColor: colors.foreground, alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.background, fontWeight: "900" }}>×</Text></Pressable>}
              </View>
            ))}
            {canEdit && photos.length < REVIEW_MAX_PHOTOS && <Pressable onPress={addPhoto} style={{ width: 88, height: 88, borderRadius: 10, borderWidth: 1.5, borderStyle: "dashed", borderColor: colors.border, alignItems: "center", justifyContent: "center", gap: 4 }}><IconSymbol name="camera.fill" size={22} color={colors.muted} /><Text style={{ color: colors.muted, fontSize: 11 }}>사진 추가</Text></Pressable>}
          </View>
        </View>

        <View style={{ gap: 8 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between" }}><Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "800" }}>후기 내용</Text><Text style={{ color: text.length > 1000 ? colors.error : colors.muted, fontSize: 12 }}>{text.length}/1,000</Text></View>
          <TextInput value={text} onChangeText={(value) => setText(value.slice(0, 1000))} placeholder="거래 경험을 10자 이상 작성해 주세요." placeholderTextColor={colors.muted} multiline editable={canEdit} textAlignVertical="top" style={{ minHeight: 160, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, padding: 14, color: colors.foreground, fontSize: 15 }} />
        </View>

        {canEdit && <Pressable onPress={completeReview} style={({ pressed }) => [{ backgroundColor: colors.foreground, borderRadius: 14, paddingVertical: 16, alignItems: "center" }, pressed && { opacity: 0.82 }]}><Text style={{ color: colors.background, fontSize: 16, fontWeight: "900" }}>{isEdit ? "후기 수정 완료" : "후기 작성 완료"}</Text></Pressable>}
      </ScrollView>
    </ScreenContainer>
  );
}
