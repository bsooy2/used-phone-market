import { Stack, useRouter } from "expo-router";
import { useRef, useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import type { TextInput as TextInputType } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { AddressSearchModal } from "@/components/address-search-modal";
import { useColors } from "@/hooks/use-colors";
import { BuyerProfile, EMPTY_BUYER_PROFILE, Gender, useAuthStore } from "@/lib/auth-store";
import { validateBankAccount } from "@/lib/bank-account";
import { BANK_LIST } from "@/constants/banks";

const GENDERS: { key: Gender; label: string }[] = [
  { key: "male", label: "남성" },
  { key: "female", label: "여성" },
];

export default function BuyerInfoScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, updateBuyerProfile, verifyPassword } = useAuthStore();

  const [profile, setProfile] = useState<BuyerProfile>(user?.buyerProfile ?? EMPTY_BUYER_PROFILE);
  const [saving, setSaving] = useState(false);
  const [addressModal, setAddressModal] = useState(false);
  const addressDetailRef = useRef<TextInputType>(null);
  const [passwordConfirmed, setPasswordConfirmed] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState("");
  const [confirmError, setConfirmError] = useState<string | null>(null);

  async function handlePasswordConfirm() {
    if (!confirmPassword) {
      setConfirmError("비밀번호를 입력해 주세요.");
      return;
    }
    const ok = await verifyPassword(confirmPassword);
    if (ok) {
      setPasswordConfirmed(true);
      setConfirmError(null);
    } else {
      setConfirmError("비밀번호가 일치하지 않습니다.");
    }
  }

  function set<K extends keyof BuyerProfile>(key: K, value: BuyerProfile[K]) {
    setProfile((p) => ({ ...p, [key]: value }));
  }

  async function onSave() {
    setSaving(true);
    const res = await updateBuyerProfile(profile);
    setSaving(false);
    if (!res.ok) {
      Alert.alert("입력 확인", res.error ?? "정보를 확인해 주세요.");
      return;
    }
    Alert.alert("저장 완료", "구매자 정보가 저장되었습니다.", [{ text: "확인", onPress: () => router.back() }]);
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 8, gap: 8 }}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>구매자 정보</Text>
      </View>

      {!passwordConfirmed ? (
        <View style={{ flex: 1, justifyContent: "center", padding: 24, gap: 16 }}>
          <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800", textAlign: "center" }}>본인 확인</Text>
          <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center" }}>정보 수정을 위해 비밀번호를 입력해 주세요.</Text>
          <TextInput
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            placeholder="비밀번호 입력"
            placeholderTextColor={colors.muted}
            secureTextEntry
            returnKeyType="done"
            onSubmitEditing={handlePasswordConfirm}
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14, fontSize: 16, color: colors.foreground, textAlign: "center" }}
          />
          {confirmError && <Text style={{ color: colors.error, fontSize: 13, textAlign: "center" }}>{confirmError}</Text>}
          <Pressable
            onPress={handlePasswordConfirm}
            style={({ pressed }) => [
              { backgroundColor: colors.foreground, borderRadius: 14, paddingVertical: 16, alignItems: "center" },
              pressed && { opacity: 0.85 },
            ]}
          >
            <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>확인</Text>
          </Pressable>
        </View>
      ) : (
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 24, gap: 16 }}>
          <Field label="이름" colors={colors}>
            <TextInput
              value={profile.name}
              onChangeText={(t) => set("name", t)}
              placeholder="실명을 입력하세요"
              placeholderTextColor={colors.muted}
              style={inputStyle(colors)}
            />
          </Field>

          <Field label="생년월일" colors={colors}>
            <TextInput
              value={profile.birth}
              onChangeText={(t) => set("birth", t)}
              placeholder="예: 1995-03-21"
              placeholderTextColor={colors.muted}
              keyboardType="numbers-and-punctuation"
              style={inputStyle(colors)}
            />
          </Field>

          <Field label="성별" colors={colors}>
            <View style={{ flexDirection: "row", gap: 10 }}>
              {GENDERS.map((g) => {
                const active = profile.gender === g.key;
                return (
                  <Pressable
                    key={g.key}
                    onPress={() => set("gender", g.key)}
                    style={({ pressed }) => [
                      {
                        flex: 1,
                        paddingVertical: 13,
                        borderRadius: 12,
                        alignItems: "center",
                        borderWidth: 1.5,
                        borderColor: active ? colors.primary : colors.border,
                        backgroundColor: active ? colors.primary + "12" : colors.surface,
                      },
                      pressed && { opacity: 0.85 },
                    ]}
                  >
                    <Text style={{ color: colors.foreground, fontWeight: "700" }}>{g.label}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Field>

          <Field label="이메일" colors={colors}>
            <TextInput
              value={profile.email}
              onChangeText={(t) => set("email", t)}
              placeholder="example@email.com"
              placeholderTextColor={colors.muted}
              keyboardType="email-address"
              autoCapitalize="none"
              style={inputStyle(colors)}
            />
          </Field>

          <Field label="주소" colors={colors}>
            <View style={{ flexDirection: "row", gap: 8 }}>
              <View
                style={[
                  inputStyle(colors),
                  { flex: 1, justifyContent: "center", paddingVertical: 12 },
                ]}
              >
                <Text style={{ color: profile.zipcode ? colors.foreground : colors.muted, fontSize: 15 }}>
                  {profile.zipcode || "우편번호"}
                </Text>
              </View>
              <Pressable
                onPress={() => setAddressModal(true)}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.primary,
                    borderRadius: 12,
                    paddingHorizontal: 18,
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "row",
                    gap: 6,
                  },
                  pressed && { opacity: 0.85 },
                ]}
              >
                <IconSymbol name="magnifyingglass" size={18} color={colors.background} />
                <Text style={{ color: colors.background, fontWeight: "700" }}>주소 검색</Text>
              </Pressable>
            </View>
            <View style={[inputStyle(colors), { marginTop: 8, justifyContent: "center", minHeight: 46 }]}>
              <Text style={{ color: profile.address ? colors.foreground : colors.muted, fontSize: 15 }}>
                {profile.address || "주소 검색을 눌러 주소를 선택하세요"}
              </Text>
            </View>
            <TextInput
              ref={addressDetailRef}
              value={profile.addressDetail}
              onChangeText={(t) => set("addressDetail", t)}
              placeholder="상세 주소 (동/호 등)"
              placeholderTextColor={colors.muted}
              style={[inputStyle(colors), { marginTop: 8 }]}
            />
          </Field>

          <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800", marginTop: 4 }}>판매정산 및 환불시 입금 계좌</Text>
          <Text style={{ color: colors.error, fontSize: 12, fontWeight: "600", marginTop: 4, marginBottom: 2 }}>⚠️ 정확한 계좌 정보를 입력해 주세요. 잘못된 계좌 입력 시 입금이 불가하며, 이로 인한 불이익은 본인에게 있습니다.</Text>
          <Field label="은행 선택" colors={colors}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }}>
              <View style={{ flexDirection: "row", gap: 6, paddingVertical: 4 }}>
                {BANK_LIST.map((bank) => (
                  <Pressable
                    key={bank}
                    onPress={() => set("refundBank", bank)}
                    style={({ pressed }) => [
                      {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 8,
                        borderWidth: 1,
                        borderColor: profile.refundBank === bank ? colors.primary : colors.border,
                        backgroundColor: profile.refundBank === bank ? colors.primary + "15" : colors.surface,
                      },
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <Text style={{ color: profile.refundBank === bank ? colors.primary : colors.foreground, fontSize: 13, fontWeight: profile.refundBank === bank ? "700" : "500" }}>{bank}</Text>
                  </Pressable>
                ))}
              </View>
            </ScrollView>
            {profile.refundBank ? <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "600" }}>선택: {profile.refundBank}</Text> : null}
          </Field>
          <Field label="계좌번호" colors={colors}>
            <TextInput
              value={profile.refundAccount}
              onChangeText={(t) => set("refundAccount", t)}
              placeholder="'-' 없이 숫자만 입력"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              style={inputStyle(colors)}
            />
            {profile.refundBank && profile.refundAccount ? (() => {
              const result = validateBankAccount(profile.refundBank, profile.refundAccount);
              if (!result.valid && result.message) return <Text style={{ color: colors.error, fontSize: 11, marginTop: 4 }}>{result.message}</Text>;
              if (result.valid) return <Text style={{ color: "#22C55E", fontSize: 11, marginTop: 4 }}>✓ 자릿수 확인 완료</Text>;
              return null;
            })() : null}
          </Field>
          <Field label="예금주" colors={colors}>
            <TextInput
              value={profile.refundHolder}
              onChangeText={(t) => set("refundHolder", t)}
              placeholder="예금주명"
              placeholderTextColor={colors.muted}
              returnKeyType="done"
              style={inputStyle(colors)}
            />
          </Field>
        </ScrollView>
      </KeyboardAvoidingView>
      )}

      <AddressSearchModal
        visible={addressModal}
        onClose={() => setAddressModal(false)}
        onSelect={(item) => {
          set("zipcode", item.zipcode);
          set("address", item.road);
          // 주소 선택 후 상세 주소 입력란으로 자동 포커스
          setTimeout(() => addressDetailRef.current?.focus(), 350);
        }}
      />

      <View style={{ padding: 16, paddingBottom: 24, borderTopWidth: 0.5, borderTopColor: colors.border }}>
        <Pressable
          onPress={onSave}
          disabled={saving}
          style={({ pressed }) => [
            { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: "center", opacity: saving ? 0.7 : 1 },
            pressed && { transform: [{ scale: 0.99 }] },
          ]}
        >
          <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>{saving ? "저장 중..." : "저장하기"}</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

function Field({ label, children, colors }: { label: string; children: React.ReactNode; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={{ gap: 6 }}>
      <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "600" }}>{label}</Text>
      {children}
    </View>
  );
}

function inputStyle(colors: ReturnType<typeof useColors>) {
  return {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: colors.foreground,
  } as const;
}
