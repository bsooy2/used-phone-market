import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import { trpc } from "@/lib/trpc";

function formatWon(value: number) {
  return `${value.toLocaleString("ko-KR")}원`;
}

export default function AdminSmsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAdmin, pin } = useAdminStore();
  const dashboard = trpc.sms.dashboard.useQuery({ pin: pin ?? "", days: 30 }, { enabled: isAdmin && Boolean(pin) });

  if (!isAdmin) {
    return <ScreenContainer className="items-center justify-center p-6"><Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800" }}>관리자 전용 화면입니다.</Text><Pressable onPress={() => router.replace("/admin")} style={{ marginTop: 16, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10, backgroundColor: colors.foreground }}><Text style={{ color: colors.background, fontWeight: "800" }}>관리자 인증하기</Text></Pressable></ScreenContainer>;
  }

  return <ScreenContainer className="p-5"><ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }}><View><Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>인증 문자 발송 현황</Text><Text style={{ color: colors.muted, fontSize: 13, marginTop: 4 }}>최근 30일 SOLAPI 실제 발송·차감 이력입니다.</Text></View>{dashboard.isLoading ? <ActivityIndicator color={colors.foreground} style={{ marginTop: 40 }} /> : dashboard.isError || !dashboard.data ? <View style={{ padding: 18, borderWidth: 1, borderColor: colors.border, borderRadius: 14, gap: 10 }}><Text style={{ color: colors.error, fontWeight: "800" }}>발송 이력을 불러오지 못했습니다.</Text><Pressable onPress={() => dashboard.refetch()} style={{ alignSelf: "flex-start", paddingVertical: 9, paddingHorizontal: 13, borderRadius: 8, backgroundColor: colors.foreground }}><Text style={{ color: colors.background, fontWeight: "800" }}>다시 시도</Text></Pressable></View> : <><View style={{ padding: 14, borderRadius: 13, borderWidth: 1, borderColor: dashboard.data.limit.status === "safe" ? colors.border : dashboard.data.limit.status === "warning" ? colors.warning : colors.error, backgroundColor: colors.surface, gap: 5 }}><Text style={{ color: dashboard.data.limit.status === "safe" ? colors.foreground : dashboard.data.limit.status === "warning" ? colors.warning : colors.error, fontWeight: "900" }}>{dashboard.data.limit.status === "safe" ? "문자 발송 상태 정상" : dashboard.data.limit.status === "warning" ? "문자 발송 한도 경고" : "문자 발송 차단"}</Text><Text style={{ color: colors.muted, fontSize: 12 }}>{dashboard.data.limit.message}</Text><Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "700" }}>충전 잔액 {formatWon(dashboard.data.balance)} · 오늘 {dashboard.data.dailySentCount}/{dashboard.data.dailyLimit}건 · 남은 한도 {dashboard.data.limit.remainingQuota}건</Text></View><View style={{ flexDirection: "row", gap: 10 }}><Metric label="인증 문자" value={`${dashboard.data.sentCount}건`} /><Metric label="정상 처리" value={`${dashboard.data.deliveredCount}건`} /><Metric label="실제 차감" value={formatWon(dashboard.data.totalCost)} /></View><View style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 14, overflow: "hidden" }}><View style={{ backgroundColor: colors.surface, padding: 14 }}><Text style={{ color: colors.foreground, fontWeight: "900" }}>최근 인증 문자</Text><Text style={{ color: colors.muted, fontSize: 11, marginTop: 3 }}>수신 번호는 개인정보 보호를 위해 마스킹됩니다.</Text></View>{dashboard.data.messages.length === 0 ? <Text style={{ color: colors.muted, textAlign: "center", padding: 28 }}>최근 발송 이력이 없습니다.</Text> : dashboard.data.messages.map((message, index) => <View key={message.id} style={{ padding: 14, borderTopWidth: index === 0 ? 0 : 1, borderColor: colors.border, gap: 3 }}><View style={{ flexDirection: "row", justifyContent: "space-between", gap: 10 }}><Text style={{ color: colors.foreground, fontWeight: "800" }}>{message.recipient}</Text><Text style={{ color: message.statusCode === "4000" ? colors.primary : colors.error, fontSize: 12, fontWeight: "800" }}>{message.statusCode === "4000" ? "정상 처리" : message.status}</Text></View><Text style={{ color: colors.muted, fontSize: 11 }}>{new Date(message.createdAt).toLocaleString("ko-KR")}{message.reason ? ` · ${message.reason}` : ""}</Text></View>)}</View></>}</ScrollView></ScreenContainer>;
}

function Metric({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return <View style={{ flex: 1, padding: 12, backgroundColor: colors.surface, borderRadius: 12, borderWidth: 1, borderColor: colors.border, gap: 4 }}><Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "900" }} numberOfLines={1}>{value}</Text><Text style={{ color: colors.muted, fontSize: 11 }}>{label}</Text></View>;
}
