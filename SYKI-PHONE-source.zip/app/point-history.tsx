import { Text, View, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { usePointStore, PointEntry } from "@/lib/point-store";

export default function PointHistoryScreen() {
  const colors = useColors();
  const { balance, history } = usePointStore();

  const renderItem = ({ item }: { item: PointEntry }) => (
    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 14, borderBottomWidth: 0.5, borderBottomColor: colors.border }}>
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "600" }}>{item.label}</Text>
        <Text style={{ color: colors.muted, fontSize: 12 }}>{new Date(item.createdAt).toLocaleDateString("ko-KR")} {new Date(item.createdAt).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })}</Text>
      </View>
      <Text style={{ color: item.amount > 0 ? "#22C55E" : "#EF4444", fontSize: 16, fontWeight: "800" }}>
        {item.amount > 0 ? "+" : ""}{item.amount.toLocaleString()}P
      </Text>
    </View>
  );

  return (
    <ScreenContainer className="p-6">
      <View style={{ gap: 16, flex: 1 }}>
        {/* 잔액 헤더 */}
        <View style={{ backgroundColor: colors.foreground, borderRadius: 16, padding: 24, alignItems: "center", gap: 4 }}>
          <Text style={{ color: colors.background, fontSize: 13 }}>보유 포인트</Text>
          <Text style={{ color: colors.background, fontSize: 32, fontWeight: "900" }}>{balance.toLocaleString()}P</Text>
          <Text style={{ color: colors.background, fontSize: 11, opacity: 0.7 }}>1,000원 단위로 사용 가능</Text>
        </View>

        {/* 내역 */}
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>적립/사용 내역</Text>
        <FlatList
          data={history}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          ListEmptyComponent={
            <View style={{ alignItems: "center", paddingVertical: 40 }}>
              <Text style={{ color: colors.muted, fontSize: 14 }}>포인트 내역이 없습니다.</Text>
            </View>
          }
        />
      </View>
    </ScreenContainer>
  );
}
