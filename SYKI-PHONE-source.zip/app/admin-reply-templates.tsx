import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import {
  InquiryReplyTemplate,
  InquiryTemplateFolder,
  UNCLASSIFIED_FOLDER_ID,
  useInquiryTemplateStore,
} from "@/lib/inquiry-template-store";
import { filterReplyTemplatesByKeyword, sortReplyTemplatesByFavorite } from "@/lib/template-search";

export default function AdminReplyTemplatesScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAdmin } = useAdminStore();
  const {
    templates,
    folders,
    loaded,
    createTemplate,
    updateTemplate,
    deleteTemplate,
    toggleTemplateFavorite,
    moveTemplate,
    createFolder,
    updateFolder,
    deleteFolder,
  } = useInquiryTemplateStore();

  const [editing, setEditing] = useState<InquiryReplyTemplate | null>(null);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [templateFolderId, setTemplateFolderId] = useState(UNCLASSIFIED_FOLDER_ID);
  const [selectedFolderId, setSelectedFolderId] = useState<string | "all">("all");
  const [editingFolder, setEditingFolder] = useState<InquiryTemplateFolder | null>(null);
  const [folderName, setFolderName] = useState("");
  const [keyword, setKeyword] = useState("");

  const folderById = useMemo(() => new Map(folders.map((folder) => [folder.id, folder])), [folders]);
  const favoriteTemplates = useMemo(
    () => sortReplyTemplatesByFavorite(templates.filter((template) => template.isFavorite)),
    [templates],
  );
  const folderFilteredTemplates = selectedFolderId === "all"
    ? templates
    : templates.filter((template) => (template.folderId ?? UNCLASSIFIED_FOLDER_ID) === selectedFolderId);
  const visibleTemplates = useMemo(
    () => sortReplyTemplatesByFavorite(filterReplyTemplatesByKeyword(folderFilteredTemplates, folders, keyword)),
    [folderFilteredTemplates, folders, keyword],
  );

  const beginNew = () => {
    setEditing(null);
    setTitle("");
    setBody("");
    setTemplateFolderId(selectedFolderId === "all" ? UNCLASSIFIED_FOLDER_ID : selectedFolderId);
  };

  const beginEdit = (template: InquiryReplyTemplate) => {
    setEditing(template);
    setTitle(template.title);
    setBody(template.body);
    setTemplateFolderId(template.folderId ?? UNCLASSIFIED_FOLDER_ID);
  };

  const saveTemplate = () => {
    const result = editing
      ? updateTemplate(editing.id, title, body, templateFolderId)
      : createTemplate(title, body, templateFolderId);
    if (!result.ok) {
      Alert.alert("입력 확인", result.error ?? "저장할 수 없습니다.");
      return;
    }
    Alert.alert("저장 완료", "답변 템플릿을 저장했습니다.");
    beginNew();
  };

  const saveFolder = () => {
    const result = editingFolder
      ? updateFolder(editingFolder.id, folderName)
      : createFolder(folderName);
    if (!result.ok) {
      Alert.alert("폴더 확인", result.error ?? "저장할 수 없습니다.");
      return;
    }
    setEditingFolder(null);
    setFolderName("");
  };

  if (!isAdmin) {
    return (
      <ScreenContainer className="items-center justify-center p-6">
        <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800" }}>관리자 전용 화면입니다.</Text>
        <Pressable onPress={() => router.replace("/admin")} style={{ marginTop: 16, backgroundColor: colors.foreground, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10 }}>
          <Text style={{ color: colors.background, fontWeight: "800" }}>관리자 인증하기</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }} keyboardShouldPersistTaps="handled">
        <View>
          <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>문의 답변 템플릿</Text>
          <Text style={{ color: colors.muted, fontSize: 13, marginTop: 4 }}>폴더·검색·즐겨찾기로 답변 문구를 빠르게 관리합니다.</Text>
        </View>

        {favoriteTemplates.length > 0 ? (
          <View style={{ borderWidth: 1, borderColor: colors.foreground, borderRadius: 14, padding: 13, gap: 8 }}>
            <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "900" }}>즐겨찾기 템플릿 · 상단 고정</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>
              {favoriteTemplates.map((template) => (
                <Pressable key={template.id} onPress={() => beginEdit(template)} style={{ paddingHorizontal: 10, paddingVertical: 8, borderRadius: 8, backgroundColor: colors.foreground }}>
                  <Text style={{ color: colors.background, fontSize: 11, fontWeight: "800" }}>{template.title}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        ) : null}

        <View style={{ padding: 15, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: 14, gap: 10 }}>
          <Text style={{ color: colors.foreground, fontWeight: "900" }}>{editingFolder ? "폴더 이름 수정" : "새 폴더"}</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <TextInput value={folderName} onChangeText={setFolderName} placeholder="예: 매장 방문 · 배송 · 가격 안내" placeholderTextColor={colors.muted} style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 9, padding: 11, color: colors.foreground, backgroundColor: colors.background }} />
            <Pressable onPress={saveFolder} style={{ justifyContent: "center", paddingHorizontal: 14, borderRadius: 9, backgroundColor: colors.foreground }}>
              <Text style={{ color: colors.background, fontWeight: "800" }}>{editingFolder ? "수정" : "추가"}</Text>
            </Pressable>
          </View>
          {editingFolder ? <Pressable onPress={() => { setEditingFolder(null); setFolderName(""); }}><Text style={{ color: colors.muted, fontSize: 12, textAlign: "right" }}>폴더 수정 취소</Text></Pressable> : null}
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>
          <FolderChip active={selectedFolderId === "all"} label={`전체 ${templates.length}`} onPress={() => setSelectedFolderId("all")} colors={colors} />
          {folders.map((folder) => (
            <View key={folder.id} style={{ flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: selectedFolderId === folder.id ? colors.foreground : colors.border, backgroundColor: selectedFolderId === folder.id ? colors.foreground : colors.background, borderRadius: 8, overflow: "hidden" }}>
              <Pressable onPress={() => setSelectedFolderId(folder.id)} style={{ paddingLeft: 10, paddingRight: 7, paddingVertical: 8 }}>
                <Text style={{ color: selectedFolderId === folder.id ? colors.background : colors.foreground, fontSize: 12, fontWeight: "800" }}>{folder.name} {templates.filter((template) => (template.folderId ?? UNCLASSIFIED_FOLDER_ID) === folder.id).length}</Text>
              </Pressable>
              {!folder.isSystem ? <Pressable onPress={() => { setEditingFolder(folder); setFolderName(folder.name); }} style={{ paddingRight: 8, paddingVertical: 8 }}><Text style={{ color: selectedFolderId === folder.id ? colors.background : colors.muted, fontSize: 12 }}>편집</Text></Pressable> : null}
            </View>
          ))}
        </ScrollView>

        <View style={{ flexDirection: "row", gap: 8, alignItems: "center", borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 11, backgroundColor: colors.background }}>
          <TextInput value={keyword} onChangeText={setKeyword} placeholder="제목·내용·폴더명으로 검색" placeholderTextColor={colors.muted} returnKeyType="search" style={{ flex: 1, paddingVertical: 11, color: colors.foreground }} />
          {keyword ? <Pressable onPress={() => setKeyword("")}><Text style={{ color: colors.muted, fontSize: 12, fontWeight: "800" }}>초기화</Text></Pressable> : null}
        </View>
        <Text style={{ color: colors.muted, fontSize: 12 }}>{keyword.trim() ? `“${keyword.trim()}” 검색 결과 ${visibleTemplates.length}개` : `현재 폴더 템플릿 ${visibleTemplates.length}개`}</Text>

        <View style={{ padding: 15, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: 14, gap: 10 }}>
          <Text style={{ color: colors.foreground, fontWeight: "900" }}>{editing ? "템플릿 수정" : "새 템플릿"}</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder="예: 매장 방문 안내" placeholderTextColor={colors.muted} style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 9, padding: 11, color: colors.foreground, backgroundColor: colors.background }} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>
            {folders.map((folder) => <FolderChip key={folder.id} active={templateFolderId === folder.id} label={folder.name} onPress={() => setTemplateFolderId(folder.id)} colors={colors} />)}
          </ScrollView>
          <TextInput value={body} onChangeText={setBody} placeholder="고객에게 보낼 답변 내용을 입력하세요." placeholderTextColor={colors.muted} multiline style={{ minHeight: 100, borderWidth: 1, borderColor: colors.border, borderRadius: 9, padding: 11, color: colors.foreground, backgroundColor: colors.background, textAlignVertical: "top" }} />
          <View style={{ flexDirection: "row", gap: 8 }}>
            <Pressable onPress={saveTemplate} style={{ flex: 1, alignItems: "center", borderRadius: 9, paddingVertical: 11, backgroundColor: colors.foreground }}><Text style={{ color: colors.background, fontWeight: "800" }}>저장</Text></Pressable>
            {editing ? <Pressable onPress={beginNew} style={{ paddingHorizontal: 16, alignItems: "center", justifyContent: "center", borderRadius: 9, borderWidth: 1, borderColor: colors.border }}><Text style={{ color: colors.foreground, fontWeight: "800" }}>취소</Text></Pressable> : null}
          </View>
        </View>

        {!loaded ? <Text style={{ color: colors.muted, textAlign: "center", padding: 20 }}>템플릿을 불러오는 중...</Text> : null}
        {loaded && visibleTemplates.length === 0 ? <Text style={{ color: colors.muted, textAlign: "center", padding: 30 }}>{keyword.trim() ? "검색 결과가 없습니다. 다른 키워드를 입력해 보세요." : "이 폴더에 등록된 템플릿이 없습니다."}</Text> : null}
        {visibleTemplates.map((template) => (
          <View key={template.id} style={{ borderWidth: 1, borderColor: template.isFavorite ? colors.foreground : colors.border, borderRadius: 14, padding: 14, gap: 8 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
              <Text style={{ color: colors.foreground, fontWeight: "900", flex: 1 }}>{template.title}</Text>
              <Text style={{ color: colors.muted, fontSize: 11 }}>{folderById.get(template.folderId ?? UNCLASSIFIED_FOLDER_ID)?.name ?? "미분류"}{template.isFavorite ? " · 즐겨찾기" : ""}</Text>
            </View>
            <Text style={{ color: colors.muted, lineHeight: 19 }}>{template.body}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>
              <Pressable onPress={() => toggleTemplateFavorite(template.id)} style={{ paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, backgroundColor: template.isFavorite ? colors.foreground : colors.background, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: template.isFavorite ? colors.background : colors.foreground, fontSize: 11, fontWeight: "800" }}>{template.isFavorite ? "즐겨찾기 해제" : "즐겨찾기"}</Text>
              </Pressable>
              <Text style={{ color: colors.muted, alignSelf: "center", fontSize: 11 }}>이동</Text>
              {folders.map((folder) => <FolderChip key={folder.id} active={(template.folderId ?? UNCLASSIFIED_FOLDER_ID) === folder.id} label={folder.name} onPress={() => moveTemplate(template.id, folder.id)} colors={colors} />)}
            </ScrollView>
            <View style={{ flexDirection: "row", gap: 8 }}>
              <Pressable onPress={() => beginEdit(template)} style={{ paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: colors.surface }}><Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 12 }}>수정</Text></Pressable>
              <Pressable onPress={() => Alert.alert("템플릿 삭제", `“${template.title}” 템플릿을 삭제할까요?`, [{ text: "취소", style: "cancel" }, { text: "삭제", style: "destructive", onPress: () => deleteTemplate(template.id) }])} style={{ paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: colors.surface }}><Text style={{ color: colors.error, fontWeight: "800", fontSize: 12 }}>삭제</Text></Pressable>
            </View>
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}

function FolderChip({ active, label, onPress, colors }: { active: boolean; label: string; onPress: () => void; colors: ReturnType<typeof useColors> }) {
  return <Pressable onPress={onPress} style={{ paddingHorizontal: 10, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: active ? colors.foreground : colors.border, backgroundColor: active ? colors.foreground : colors.background }}><Text style={{ color: active ? colors.background : colors.foreground, fontSize: 11, fontWeight: "800" }}>{label}</Text></Pressable>;
}
