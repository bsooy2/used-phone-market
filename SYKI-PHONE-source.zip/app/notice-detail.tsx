import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useContentStore } from "@/lib/content-store";

export default function NoticeDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { notices } = useContentStore();
  const notice = notices.find((n) => n.id === id);

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 8, gap: 8 }}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>공지사항</Text>
      </View>

      {!notice ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <Text style={{ color: colors.muted }}>공지사항을 찾을 수 없습니다.</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40, gap: 16 }}>
          <View style={{ gap: 6 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              {notice.pinned && <Text style={{ fontSize: 12 }}>📌</Text>}
              <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800", flex: 1 }}>{notice.title}</Text>
            </View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>
              {new Date(notice.createdAt).toLocaleDateString("ko-KR", { year: "numeric", month: "long", day: "numeric" })}
            </Text>
          </View>
          <View style={{ height: 1, backgroundColor: colors.border }} />
          <Text style={{ color: colors.foreground, fontSize: 15, lineHeight: 24 }}>
            {notice.body || "내용이 없습니다."}
          </Text>
        </ScrollView>
      )}
    </ScreenContainer>
  );
}
