import { Image } from "expo-image";
import { router } from "expo-router";
import { useRef, useState } from "react";
import type { TextInput as TextInputType } from "react-native";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { AddressSearchModal } from "@/components/address-search-modal";
import { PRIVACY_CONSENT } from "@/constants/legal";
import { STORE_INFO } from "@/constants/store-info";
import { useColors } from "@/hooks/use-colors";
import {
  BuyerProfile,
  EMPTY_BUYER_PROFILE,
  Gender,
  UserRole,
  useAuthStore,
} from "@/lib/auth-store";
import { validateBankAccount } from "@/lib/bank-account";

type Mode = "signin" | "signup";

const LOGO = require("@/assets/images/syki-logo.png");

export default function AuthScreen() {
  const colors = useColors();
  const { signIn, signUp, mustChangePassword, captchaRequired, captchaQuestion, verifyCaptcha, loginLocked, lockRemainingSeconds, autoLogin, setAutoLogin } = useAuthStore();

  const [captchaAnswer, setCaptchaAnswer] = useState("");

  const [mode, setMode] = useState<Mode>("signin");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  // 비밀번호 강도 표시 (회원가입 시)
  const [nickname, setNickname] = useState("");
  const [role, setRole] = useState<UserRole>("buyer");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 동의
  const [agreePrivacy, setAgreePrivacy] = useState(false);
  const [agreeMarketing, setAgreeMarketing] = useState(false);
  const [termsModal, setTermsModal] = useState<null | "required" | "marketing">(null);

  // 구매자 상세정보
  const [buyer, setBuyer] = useState<BuyerProfile>(EMPTY_BUYER_PROFILE);
  const [addressModal, setAddressModal] = useState(false);
  const addressDetailRef = useRef<TextInputType>(null);
  const setBuyerField = (key: keyof BuyerProfile, value: string) =>
    setBuyer((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async () => {
    setError(null);

    // 회원가입 시 필수 동의 미체크면 팝업으로 안내하고 중단
    if (mode === "signup" && !agreePrivacy) {
      Alert.alert(
        "약관 동의 필요",
        "필수 개인정보 수집·이용에 동의해야 회원가입이 가능합니다.",
        [{ text: "확인" }],
      );
      return;
    }

    setLoading(true);
    try {
      const res =
        mode === "signin"
          ? await signIn({ phone, password })
          : await signUp({
              phone,
              password,
              nickname,
              role,
              agreedPrivacy: agreePrivacy,
              agreedMarketing: agreeMarketing,
              buyerProfile: role === "buyer" ? buyer : undefined,
            });
    if (res.ok) {
      if (mustChangePassword) {
        router.replace("/force-change-password");
      } else {
        router.back();
      }
    } else {
        setError(res.error ?? "오류가 발생했습니다.");
      }
    } finally {
      setLoading(false);
    }
  };

  const activeTerms =
    termsModal === "required"
      ? PRIVACY_CONSENT.required
      : termsModal === "marketing"
        ? PRIVACY_CONSENT.marketing
        : null;

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, padding: 24 }}
          keyboardShouldPersistTaps="handled"
        >
          {/* 닫기 */}
          <View className="flex-row justify-end">
            <TouchableOpacity onPress={() => router.back()} hitSlop={10} style={{ opacity: 0.7 }}>
              <IconSymbol name="xmark" size={26} color={colors.muted} />
            </TouchableOpacity>
          </View>

          {/* 로고 */}
          <View className="items-center mt-2 mb-6">
            <Image source={LOGO} style={{ width: 88, height: 88, borderRadius: 20 }} contentFit="cover" />
            <Text className="text-2xl font-bold text-foreground mt-3">{STORE_INFO.name}</Text>
            <Text className="text-sm text-muted mt-1">{STORE_INFO.tagline}</Text>
          </View>

          {/* 모드 토글 */}
          <View className="flex-row bg-surface rounded-xl p-1 mb-6 border border-border">
            {(["signin", "signup"] as Mode[]).map((m) => {
              const active = mode === m;
              return (
                <Pressable
                  key={m}
                  onPress={() => {
                    setMode(m);
                    setError(null);
                  }}
                  style={({ pressed }) => [
                    { flex: 1, paddingVertical: 12, borderRadius: 10, alignItems: "center" },
                    active && { backgroundColor: colors.primary },
                    pressed && { opacity: 0.85 },
                  ]}
                >
                  <Text style={{ color: active ? colors.background : colors.muted, fontWeight: "700" }}>
                    {m === "signin" ? "로그인" : "회원가입"}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* 회원가입: 역할 선택 */}
          {mode === "signup" && (
            <View className="mb-5">
              <Text className="text-sm font-semibold text-foreground mb-2">가입 유형</Text>
              <View className="flex-row gap-3">
                {(
                  [
                    { key: "buyer", label: "구매자", desc: "매물 구경·구매", icon: "cart.fill" },
                    { key: "seller", label: "판매자", desc: "매물 등록·판매", icon: "tag.fill" },
                  ] as { key: UserRole; label: string; desc: string; icon: any }[]
                ).map((opt) => {
                  const active = role === opt.key;
                  return (
                    <Pressable
                      key={opt.key}
                      onPress={() => setRole(opt.key)}
                      style={({ pressed }) => [
                        {
                          flex: 1,
                          borderRadius: 14,
                          padding: 16,
                          borderWidth: 1.5,
                          borderColor: active ? colors.primary : colors.border,
                          backgroundColor: active ? colors.primary + "12" : colors.surface,
                        },
                        pressed && { opacity: 0.85 },
                      ]}
                    >
                      <IconSymbol name={opt.icon} size={24} color={active ? colors.primary : colors.muted} />
                      <Text
                        style={{
                          color: active ? colors.primary : colors.foreground,
                          fontWeight: "700",
                          fontSize: 16,
                          marginTop: 8,
                        }}
                      >
                        {opt.label}
                      </Text>
                      <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>{opt.desc}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          )}

          {/* 공통 입력 필드 */}
          <View className="gap-4">
            <Field label="휴대폰 번호">
              <TextInput
                value={phone}
                onChangeText={setPhone}
                placeholder="01012345678"
                placeholderTextColor={colors.muted}
                keyboardType="phone-pad"
                style={inputStyle(colors)}
              />
            </Field>

            {mode === "signup" && (
              <Field label="닉네임">
                <TextInput
                  value={nickname}
                  onChangeText={setNickname}
                  placeholder="사용할 닉네임"
                  placeholderTextColor={colors.muted}
                  style={inputStyle(colors)}
                />
              </Field>
            )}

            <Field label="비밀번호">
              <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="비밀번호 (4자 이상)"
                placeholderTextColor={colors.muted}
                secureTextEntry
                returnKeyType={mode === "signin" ? "done" : "next"}
                onSubmitEditing={mode === "signin" ? handleSubmit : undefined}
                style={inputStyle(colors)}
              />
            </Field>
          </View>

          {/* 회원가입 + 구매자: 상세 정보 */}
          {mode === "signup" && role === "buyer" && (
            <View className="mt-6">
              <View className="flex-row items-center gap-2 mb-1">
                <IconSymbol name="person.fill" size={18} color={colors.primary} />
                <Text className="text-base font-bold text-foreground">구매자 정보</Text>
              </View>
              <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 14 }}>
                결제 및 환불 처리를 위해 정확하게 입력해 주세요.
              </Text>

              <View className="gap-4">
                <Field label="이름">
                  <TextInput
                    value={buyer.name}
                    onChangeText={(v) => setBuyerField("name", v)}
                    placeholder="실명"
                    placeholderTextColor={colors.muted}
                    style={inputStyle(colors)}
                  />
                </Field>

                <Field label="생년월일">
                  <TextInput
                    value={buyer.birth}
                    onChangeText={(v) => setBuyerField("birth", v)}
                    placeholder="예: 1995-03-21"
                    placeholderTextColor={colors.muted}
                    keyboardType="numbers-and-punctuation"
                    style={inputStyle(colors)}
                  />
                </Field>

                <Field label="성별">
                  <View className="flex-row gap-2">
                    {(
                      [
                        { key: "male", label: "남성" },
                        { key: "female", label: "여성" },
                        { key: "none", label: "선택 안 함" },
                      ] as { key: Gender; label: string }[]
                    ).map((g) => {
                      const active = buyer.gender === g.key;
                      return (
                        <Pressable
                          key={g.key}
                          onPress={() => setBuyerField("gender", g.key)}
                          style={({ pressed }) => [
                            {
                              flex: 1,
                              paddingVertical: 12,
                              borderRadius: 12,
                              alignItems: "center",
                              borderWidth: 1.5,
                              borderColor: active ? colors.primary : colors.border,
                              backgroundColor: active ? colors.primary + "12" : colors.surface,
                            },
                            pressed && { opacity: 0.85 },
                          ]}
                        >
                          <Text
                            style={{
                              color: active ? colors.primary : colors.foreground,
                              fontWeight: active ? "700" : "500",
                              fontSize: 14,
                            }}
                          >
                            {g.label}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                </Field>

                <Field label="이메일">
                  <TextInput
                    value={buyer.email}
                    onChangeText={(v) => setBuyerField("email", v)}
                    placeholder="example@email.com"
                    placeholderTextColor={colors.muted}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    style={inputStyle(colors)}
                  />
                </Field>

                <Field label="주소">
                  <View style={{ flexDirection: "row", gap: 8 }}>
                    <View style={[inputStyle(colors), { flex: 1, justifyContent: "center", paddingVertical: 12 }]}>
                      <Text style={{ color: buyer.zipcode ? colors.foreground : colors.muted, fontSize: 15 }}>
                        {buyer.zipcode || "우편번호"}
                      </Text>
                    </View>
                    <Pressable
                      onPress={() => setAddressModal(true)}
                      style={({ pressed }) => [
                        {
                          backgroundColor: colors.primary,
                          borderRadius: 12,
                          paddingHorizontal: 18,
                          alignItems: "center",
                          justifyContent: "center",
                          flexDirection: "row",
                          gap: 6,
                        },
                        pressed && { opacity: 0.85 },
                      ]}
                    >
                      <IconSymbol name="magnifyingglass" size={18} color={colors.background} />
                      <Text style={{ color: colors.background, fontWeight: "700" }}>주소 검색</Text>
                    </Pressable>
                  </View>
                  <View style={[inputStyle(colors), { marginTop: 8, justifyContent: "center", minHeight: 46 }]}>
                    <Text style={{ color: buyer.address ? colors.foreground : colors.muted, fontSize: 15 }}>
                      {buyer.address || "주소 검색을 눌러 주소를 선택하세요"}
                    </Text>
                  </View>
                  <TextInput
                    ref={addressDetailRef}
                    value={buyer.addressDetail}
                    onChangeText={(v) => setBuyerField("addressDetail", v)}
                    placeholder="상세 주소 (동/호 등)"
                    placeholderTextColor={colors.muted}
                    style={[inputStyle(colors), { marginTop: 8 }]}
                  />
                </Field>

                <Field label="판매정산 및 환불시 입금 계좌">
                  <View className="gap-2">
                    <Text style={{ color: colors.error, fontSize: 12, fontWeight: "600" }}>⚠️ 정확한 계좌 정보를 입력해 주세요. 잘못된 계좌 입력 시 입금이 불가하며, 이로 인한 불이익은 본인에게 있습니다.</Text>
                    <View className="flex-row gap-2">
                      <TextInput
                        value={buyer.refundBank}
                        onChangeText={(v) => setBuyerField("refundBank", v)}
                        placeholder="은행"
                        placeholderTextColor={colors.muted}
                        style={[inputStyle(colors), { flex: 1 }]}
                      />
                      <TextInput
                        value={buyer.refundHolder}
                        onChangeText={(v) => setBuyerField("refundHolder", v)}
                        placeholder="예금주"
                        placeholderTextColor={colors.muted}
                        style={[inputStyle(colors), { flex: 1 }]}
                      />
                    </View>
                    <TextInput
                      value={buyer.refundAccount}
                      onChangeText={(v) => setBuyerField("refundAccount", v)}
                      placeholder="계좌번호 (- 없이 숫자)"
                      placeholderTextColor={colors.muted}
                      keyboardType="number-pad"
                      style={inputStyle(colors)}
                    />
                    {buyer.refundBank && buyer.refundAccount ? (() => {
                      const result = validateBankAccount(buyer.refundBank, buyer.refundAccount);
                      if (!result.valid && result.message) return <Text style={{ color: colors.error, fontSize: 11, marginTop: 4 }}>{result.message}</Text>;
                      if (result.valid) return <Text style={{ color: "#22C55E", fontSize: 11, marginTop: 4 }}>✓ 자릿수 확인 완료</Text>;
                      return null;
                    })() : null}
                  </View>
                </Field>
              </View>
            </View>
          )}

          {/* 회원가입: 약관 동의 */}
          {mode === "signup" && (
            <View className="mt-6 gap-3">
              <ConsentRow
                checked={agreePrivacy}
                onToggle={() => setAgreePrivacy((v) => !v)}
                onView={() => setTermsModal("required")}
                title={PRIVACY_CONSENT.required.title}
              />
              <ConsentRow
                checked={agreeMarketing}
                onToggle={() => setAgreeMarketing((v) => !v)}
                onView={() => setTermsModal("marketing")}
                title={PRIVACY_CONSENT.marketing.title}
              />
            </View>
          )}

          {error && <Text style={{ color: colors.error, marginTop: 14, fontSize: 13 }}>{error}</Text>}

          {/* 로그인 버튼 */}
          {mode === "signin" && (
            <Pressable onPress={() => setAutoLogin(!autoLogin)} style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <View style={{ width: 20, height: 20, borderRadius: 4, borderWidth: 1.5, borderColor: autoLogin ? colors.foreground : colors.border, backgroundColor: autoLogin ? colors.foreground : "transparent", alignItems: "center", justifyContent: "center" }}>
                {autoLogin && <Text style={{ color: colors.background, fontSize: 12, fontWeight: "800" }}>✓</Text>}
              </View>
              <Text style={{ color: colors.muted, fontSize: 13 }}>자동 로그인</Text>
            </Pressable>
          )}
          <TouchableOpacity
            onPress={handleSubmit}
            disabled={loading}
            activeOpacity={0.85}
            style={{
              backgroundColor: colors.primary,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              marginTop: 24,
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? (
              <ActivityIndicator color={colors.background} />
            ) : (
              <Text style={{ color: colors.background, fontWeight: "700", fontSize: 16 }}>
                {mode === "signin" ? "로그인" : "가입하고 시작하기"}
              </Text>
            )}
          </TouchableOpacity>

         <Text style={{ color: colors.muted, fontSize: 12, textAlign: "center", marginTop: 16 }}>
            가입 정보는 이 기기에만 저장됩니다.
          </Text>

          {mode === "signin" && (
            <Pressable onPress={() => router.push("/find-account")} style={{ alignItems: "center", marginTop: 12, paddingVertical: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 13, textDecorationLine: "underline" }}>아이디 · 비밀번호 찾기</Text>
            </Pressable>
          )}
        </ScrollView>
      </KeyboardAvoidingView>

      {/* 약관 모달 */}
      <Modal visible={!!activeTerms} animationType="slide" transparent onRequestClose={() => setTermsModal(null)}>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View
            style={{
              backgroundColor: colors.background,
              borderTopLeftRadius: 20,
              borderTopRightRadius: 20,
              maxHeight: "80%",
              paddingTop: 16,
            }}
          >
            <View className="flex-row items-center justify-between px-5 pb-3">
              <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "800", flex: 1 }}>
                {activeTerms?.title}
              </Text>
              <TouchableOpacity onPress={() => setTermsModal(null)} hitSlop={10}>
                <IconSymbol name="xmark" size={24} color={colors.muted} />
              </TouchableOpacity>
            </View>
            <ScrollView style={{ paddingHorizontal: 20 }} contentContainerStyle={{ paddingBottom: 24 }}>
              <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 22 }}>{activeTerms?.body}</Text>
            </ScrollView>
            <View style={{ padding: 16, paddingBottom: 28, borderTopWidth: 0.5, borderTopColor: colors.border }}>
              <TouchableOpacity
                onPress={() => {
                  if (termsModal === "required") setAgreePrivacy(true);
                  if (termsModal === "marketing") setAgreeMarketing(true);
                  setTermsModal(null);
                }}
                activeOpacity={0.85}
                style={{ backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 15, alignItems: "center" }}
              >
                <Text style={{ color: colors.background, fontWeight: "700", fontSize: 15 }}>
                  동의하고 닫기
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <AddressSearchModal
        visible={addressModal}
        onClose={() => setAddressModal(false)}
        onSelect={(item) => {
          setBuyerField("zipcode", item.zipcode);
          setBuyerField("address", item.road);
          // 주소 선택 후 상세 주소 입력란으로 자동 포커스
          setTimeout(() => addressDetailRef.current?.focus(), 350);
        }}
      />
    </ScreenContainer>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View>
      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "600", marginBottom: 8 }}>
        {label}
      </Text>
      {children}
    </View>
  );
}

function ConsentRow({
  checked,
  onToggle,
  onView,
  title,
}: {
  checked: boolean;
  onToggle: () => void;
  onView: () => void;
  title: string;
}) {
  const colors = useColors();
  return (
    <View className="flex-row items-center">
      <Pressable
        onPress={onToggle}
        hitSlop={6}
        style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", flex: 1, gap: 10 }, pressed && { opacity: 0.7 }]}
      >
        <View
          style={{
            width: 22,
            height: 22,
            borderRadius: 6,
            borderWidth: 1.5,
            borderColor: checked ? colors.primary : colors.border,
            backgroundColor: checked ? colors.primary : "transparent",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {checked && <IconSymbol name="checkmark" size={15} color={colors.background} />}
        </View>
        <Text style={{ color: colors.foreground, fontSize: 14, flex: 1 }}>{title}</Text>
      </Pressable>
      <TouchableOpacity onPress={onView} hitSlop={8}>
        <Text style={{ color: colors.muted, fontSize: 13, textDecorationLine: "underline" }}>보기</Text>
      </TouchableOpacity>
    </View>
  );
}

function inputStyle(colors: ReturnType<typeof useColors>) {
  return {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: colors.foreground,
  } as const;
}
import { PasswordStrengthBar } from "@/components/password-strength";
