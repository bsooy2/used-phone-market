import { Stack, useRouter } from "expo-router";
import { useState } from "react";
import { Alert, Platform, Pressable, Text, TextInput, View } from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import { trpc } from "@/lib/trpc";

export default function AdminSettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { pin, enableAdmin } = useAdminStore();

  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [loading, setLoading] = useState(false);

  const changePin = trpc.listings.changePin.useMutation();

  async function handleChangePin() {
    if (!currentPin || !newPin || !confirmPin) {
      Alert.alert("입력 확인", "모든 항목을 입력해 주세요.");
      return;
    }
    if (newPin.length < 4) {
      Alert.alert("입력 확인", "새 PIN은 4자리 이상이어야 합니다.");
      return;
    }
    if (newPin !== confirmPin) {
      Alert.alert("입력 확인", "새 PIN과 확인 PIN이 일치하지 않습니다.");
      return;
    }
    if (currentPin !== pin) {
      Alert.alert("인증 실패", "현재 PIN이 올바르지 않습니다.");
      return;
    }

    setLoading(true);
    try {
      const res = await changePin.mutateAsync({ currentPin, newPin });
      if (res.ok) {
        await enableAdmin(newPin);
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert("변경 완료", "관리자 PIN이 변경되었습니다.", [{ text: "확인", onPress: () => router.back() }]);
      } else {
        Alert.alert("오류", "PIN 변경에 실패했습니다. 현재 PIN을 확인해 주세요.");
      }
    } catch {
      Alert.alert("오류", "서버 연결에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      {/* 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
          borderBottomWidth: 0.5,
          borderBottomColor: colors.border,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>관리자 설정</Text>
      </View>

      <View style={{ padding: 20, gap: 20 }}>
        {/* PIN 변경 섹션 */}
        <View style={{ gap: 4 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>관리자 PIN 변경</Text>
          <Text style={{ color: colors.muted, fontSize: 13 }}>
            매물 등록/수정/삭제 및 관리자 모드 진입에 사용되는 PIN을 변경합니다.
          </Text>
        </View>

        <View style={{ gap: 12 }}>
          <View style={{ gap: 4 }}>
            <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "600" }}>현재 PIN</Text>
            <TextInput
              value={currentPin}
              onChangeText={(t) => setCurrentPin(t.replace(/[^0-9]/g, ""))}
              placeholder="현재 PIN 입력"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={10}
              style={{
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 14,
                fontSize: 16,
                color: colors.foreground,
              }}
            />
          </View>

          <View style={{ gap: 4 }}>
            <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "600" }}>새 PIN</Text>
            <TextInput
              value={newPin}
              onChangeText={(t) => setNewPin(t.replace(/[^0-9]/g, ""))}
              placeholder="새 PIN 입력 (4자리 이상)"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={10}
              style={{
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 14,
                fontSize: 16,
                color: colors.foreground,
              }}
            />
          </View>

          <View style={{ gap: 4 }}>
            <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "600" }}>새 PIN 확인</Text>
            <TextInput
              value={confirmPin}
              onChangeText={(t) => setConfirmPin(t.replace(/[^0-9]/g, ""))}
              placeholder="새 PIN 다시 입력"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={10}
              returnKeyType="done"
              onSubmitEditing={handleChangePin}
              style={{
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 14,
                fontSize: 16,
                color: colors.foreground,
              }}
            />
          </View>
        </View>

        <Pressable
          onPress={handleChangePin}
          disabled={loading}
          style={({ pressed }) => [
            {
              backgroundColor: colors.primary,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              opacity: loading ? 0.7 : 1,
            },
            pressed && { transform: [{ scale: 0.98 }] },
          ]}
        >
          <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>
            {loading ? "변경 중..." : "PIN 변경하기"}
          </Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
