import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { useState } from "react";

import { PhotoLightbox } from "@/components/photo-lightbox";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import { TradeInquiry, useInquiryStore } from "@/lib/inquiry-store";
import { UNCLASSIFIED_FOLDER_ID, useInquiryTemplateStore } from "@/lib/inquiry-template-store";
import { filterReplyTemplatesByKeyword, sortReplyTemplatesByFavorite } from "@/lib/template-search";
import { trpc } from "@/lib/trpc";

export default function AdminInquiriesScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAdmin, pin } = useAdminStore();
  const { inquiries, loaded, replyToInquiry } = useInquiryStore();
  const { templates, folders } = useInquiryTemplateStore();
  const sendReplyPush = trpc.push.sendInquiryReply.useMutation();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [templateFolderId, setTemplateFolderId] = useState<string | "all">("all");
  const [templateKeyword, setTemplateKeyword] = useState("");

  const sortedInquiries = [...inquiries].sort((a, b) => Number(Boolean(a.reply)) - Number(Boolean(b.reply)) || b.createdAt.localeCompare(a.createdAt));
  const folderFilteredTemplates = templateFolderId === "all" ? templates : templates.filter((template) => (template.folderId ?? UNCLASSIFIED_FOLDER_ID) === templateFolderId);
  const visibleTemplates = filterReplyTemplatesByKeyword(folderFilteredTemplates, folders, templateKeyword);
  const favoriteTemplates = sortReplyTemplatesByFavorite(templates.filter((template) => template.isFavorite));

  const openPhotos = (inquiry: TradeInquiry, index: number) => {
    setSelectedPhotos(inquiry.photos ?? []);
    setLightboxIndex(index);
  };
  const applyTemplate = (inquiryId: string, body: string) => setDrafts((previous) => ({ ...previous, [inquiryId]: body }));
  const save = async (id: string) => {
    const inquiry = inquiries.find((item) => item.id === id);
    const result = replyToInquiry(id, drafts[id] ?? "");
    if (!result.ok || !inquiry) {
      Alert.alert("입력 확인", result.error ?? "저장에 실패했습니다.");
      return;
    }
    try {
      await sendReplyPush.mutateAsync({ pin: pin ?? "", userId: inquiry.userId, inquiryId: inquiry.id, transactionLabel: inquiry.transactionLabel });
      Alert.alert("완료", "문의 답변을 저장하고 고객에게 푸시 알림을 보냈습니다.");
    } catch {
      Alert.alert("답변 저장 완료", "앱 알림함에는 등록됐지만 원격 푸시는 발송하지 못했습니다.");
    }
  };

  if (!isAdmin) {
    return <ScreenContainer className="items-center justify-center p-6"><Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 18 }}>관리자 전용 화면입니다.</Text><Pressable onPress={() => router.replace("/admin")} style={{ marginTop: 14, backgroundColor: colors.foreground, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10 }}><Text style={{ color: colors.background, fontWeight: "800" }}>관리자 인증하기</Text></Pressable></ScreenContainer>;
  }

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 36 }} keyboardShouldPersistTaps="handled">
        <View>
          <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>거래 문의 관리</Text>
          <Text style={{ color: colors.muted, fontSize: 13, marginTop: 5 }}>답변 대기 문의부터 표시됩니다.</Text>
          <Pressable onPress={() => router.push("/admin-reply-templates")} style={{ alignSelf: "flex-start", marginTop: 10, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 8, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}><Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "800" }}>답변 템플릿 관리</Text></Pressable>
        </View>

        {favoriteTemplates.length > 0 ? (
          <View style={{ gap: 7, borderWidth: 1, borderColor: colors.foreground, borderRadius: 12, padding: 11 }}>
            <Text style={{ color: colors.foreground, fontSize: 11, fontWeight: "900" }}>즐겨찾기 템플릿 · 아래 문의에 즉시 적용</Text>
            <Text style={{ color: colors.muted, fontSize: 11 }}>각 문의 카드 안의 즐겨찾기 문구를 눌러 답변 초안에 넣을 수 있습니다.</Text>
          </View>
        ) : null}

        <View style={{ gap: 7 }}>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800" }}>템플릿 폴더 선택</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>
            <TemplateChip active={templateFolderId === "all"} label="전체" onPress={() => setTemplateFolderId("all")} colors={colors} />
            {folders.map((folder) => <TemplateChip key={folder.id} active={templateFolderId === folder.id} label={folder.name} onPress={() => setTemplateFolderId(folder.id)} colors={colors} />)}
          </ScrollView>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderColor: colors.border, borderRadius: 9, paddingHorizontal: 10, backgroundColor: colors.background }}>
            <TextInput value={templateKeyword} onChangeText={setTemplateKeyword} placeholder="답변 템플릿 검색" placeholderTextColor={colors.muted} returnKeyType="search" style={{ flex: 1, paddingVertical: 9, color: colors.foreground, fontSize: 12 }} />
            {templateKeyword ? <Pressable onPress={() => setTemplateKeyword("")}><Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800" }}>초기화</Text></Pressable> : null}
          </View>
        </View>

        {!loaded ? <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 44 }}>문의를 불러오는 중...</Text> : null}
        {loaded && sortedInquiries.length === 0 ? <Text style={{ color: colors.muted, textAlign: "center", paddingVertical: 58 }}>등록된 거래 문의가 없습니다.</Text> : null}
        {sortedInquiries.map((inquiry) => (
          <View key={inquiry.id} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: inquiry.reply ? colors.border : colors.primary, borderRadius: 14, padding: 15, gap: 9 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
              <View style={{ flex: 1 }}><Text style={{ color: colors.foreground, fontWeight: "800" }}>{inquiry.transactionLabel}</Text><Text style={{ color: colors.muted, fontSize: 11, marginTop: 3 }}>{inquiry.authorName} · {inquiry.transactionType === "order" ? "구매 거래" : "판매 신청"}</Text></View>
              <Text style={{ color: inquiry.reply ? colors.primary : colors.error, fontSize: 11, fontWeight: "800" }}>{inquiry.reply ? "답변 완료" : "답변 대기"}</Text>
            </View>
            <Text style={{ color: colors.foreground, lineHeight: 20 }}>{inquiry.body}</Text>
            {inquiry.photos?.length ? <View style={{ gap: 5 }}><Text style={{ color: colors.muted, fontSize: 11, fontWeight: "700" }}>첨부 사진 · 탭하여 확대</Text><View style={{ flexDirection: "row", gap: 8 }}>{inquiry.photos.map((uri, index) => <Pressable key={uri} onPress={() => openPhotos(inquiry, index)}><Image source={{ uri }} style={{ width: 72, height: 72, borderRadius: 9 }} contentFit="cover" /></Pressable>)}</View></View> : null}
            {favoriteTemplates.length > 0 ? <View style={{ gap: 5 }}><Text style={{ color: colors.foreground, fontSize: 11, fontWeight: "900" }}>즐겨찾기 빠른 적용</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>{favoriteTemplates.map((template) => <Pressable key={template.id} onPress={() => applyTemplate(inquiry.id, template.body)} style={{ paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, backgroundColor: colors.foreground }}><Text style={{ color: colors.background, fontSize: 11, fontWeight: "800" }}>{template.title}</Text></Pressable>)}</ScrollView></View> : null}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 7 }}>
              {visibleTemplates.length === 0 ? <Text style={{ color: colors.muted, fontSize: 11, paddingVertical: 6 }}>{templateKeyword.trim() ? "검색 결과가 없습니다." : "선택한 폴더에 템플릿이 없습니다."}</Text> : visibleTemplates.map((template) => <Pressable key={template.id} onPress={() => applyTemplate(inquiry.id, template.body)} style={{ paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.background }}><Text style={{ color: colors.foreground, fontSize: 11, fontWeight: "800" }}>{template.title}</Text></Pressable>)}
            </ScrollView>
            <TextInput value={drafts[inquiry.id] ?? inquiry.reply ?? ""} onChangeText={(text) => setDrafts((previous) => ({ ...previous, [inquiry.id]: text }))} placeholder="사장님 답변 입력" placeholderTextColor={colors.muted} multiline style={{ minHeight: 70, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 9, padding: 11, color: colors.foreground, textAlignVertical: "top" }} />
            <Pressable onPress={() => save(inquiry.id)} style={({ pressed }) => [{ backgroundColor: colors.foreground, borderRadius: 9, paddingVertical: 10, alignItems: "center" }, pressed && { opacity: 0.7 }]}><Text style={{ color: colors.background, fontSize: 12, fontWeight: "800" }}>답변 저장</Text></Pressable>
          </View>
        ))}
      </ScrollView>
      <PhotoLightbox photos={selectedPhotos} initialIndex={lightboxIndex ?? 0} visible={lightboxIndex !== null} onClose={() => setLightboxIndex(null)} />
    </ScreenContainer>
  );
}

function TemplateChip({ active, label, onPress, colors }: { active: boolean; label: string; onPress: () => void; colors: ReturnType<typeof useColors> }) {
  return <Pressable onPress={onPress} style={{ paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, backgroundColor: active ? colors.foreground : colors.background, borderWidth: 1, borderColor: active ? colors.foreground : colors.border }}><Text style={{ color: active ? colors.background : colors.foreground, fontSize: 11, fontWeight: "800" }}>{label}</Text></Pressable>;
}
