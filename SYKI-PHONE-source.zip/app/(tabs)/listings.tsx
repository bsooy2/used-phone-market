import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { FlatList, Pressable, Text, TextInput, View } from "react-native";

import { PhoneCard } from "@/components/phone-ui";
import { ScreenContainer } from "@/components/screen-container";
import { ServerConnectionBanner } from "@/components/server-connection-notice";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { BRANDS } from "@/constants/phones";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { isPriceInRange, PRICE_RANGES } from "@/lib/price-filter";

type SortKey = "latest" | "low" | "high";

export default function ListingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { allPhones } = useAppStore();
  const [query, setQuery] = useState("");
  const [brand, setBrand] = useState<string | null>(null);
  const [sort, setSort] = useState<SortKey>("latest");
  const [priceRangeId, setPriceRangeId] = useState("all");
  const selectedPriceRange = PRICE_RANGES.find((range) => range.id === priceRangeId) ?? PRICE_RANGES[0];

  const filtered = useMemo(() => {
    let list = allPhones.filter((p) => {
      const matchQuery =
        query.trim() === "" ||
        `${p.brand} ${p.model} ${p.color}`.toLowerCase().includes(query.toLowerCase());
      const matchBrand = !brand || p.brand === brand;
      const matchPrice = isPriceInRange(p.price, selectedPriceRange);
      return matchQuery && matchBrand && matchPrice;
    });
    if (sort === "low") list = [...list].sort((a, b) => a.price - b.price);
    else if (sort === "high") list = [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [allPhones, query, brand, selectedPriceRange, sort]);

  return (
    <ScreenContainer>
      <View style={{ padding: 20, paddingBottom: 8, gap: 14 }}>
        <Text style={{ color: colors.foreground, fontSize: 24, fontWeight: "800" }}>매물</Text>

        {/* 검색바 */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            backgroundColor: colors.surface,
            borderRadius: 12,
            paddingHorizontal: 12,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="모델명, 색상 검색"
            placeholderTextColor={colors.muted}
            returnKeyType="search"
            style={{ flex: 1, paddingVertical: 12, color: colors.foreground, fontSize: 15 }}
          />
        </View>

        {/* 브랜드 필터 */}
        <View style={{ flexDirection: "row", gap: 8 }}>
          <FilterChip label="전체" active={!brand} onPress={() => setBrand(null)} />
          {BRANDS.map((b) => (
            <FilterChip key={b} label={b} active={brand === b} onPress={() => setBrand(b)} />
          ))}
        </View>

        {/* 정렬 */}
        <View style={{ flexDirection: "row", gap: 8 }}>
          <SortChip label="최신순" active={sort === "latest"} onPress={() => setSort("latest")} />
          <SortChip label="낮은가격" active={sort === "low"} onPress={() => setSort("low")} />
          <SortChip label="높은가격" active={sort === "high"} onPress={() => setSort("high")} />
        </View>

        {/* 가격대 필터 */}
        <View style={{ gap: 8 }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>가격대</Text>
            {priceRangeId !== "all" && (
              <Pressable onPress={() => setPriceRangeId("all")} hitSlop={8}>
                <Text style={{ color: colors.muted, fontSize: 12, fontWeight: "600" }}>가격 필터 초기화</Text>
              </Pressable>
            )}
          </View>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {PRICE_RANGES.map((range) => (
              <FilterChip
                key={range.id}
                label={range.label}
                active={priceRangeId === range.id}
                onPress={() => setPriceRangeId(range.id)}
              />
            ))}
          </View>
        </View>

        <Text style={{ color: colors.muted, fontSize: 12 }}>조건에 맞는 매물 {filtered.length}건</Text>
      </View>

      <ServerConnectionBanner />

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 12 }}
        renderItem={({ item }) => (
          <PhoneCard phone={item} onPress={() => router.push(`/product/${item.id}`)} />
        )}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingVertical: 40 }}>
            <Text style={{ color: colors.muted }}>조건에 맞는 매물이 없습니다.</Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

function FilterChip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          paddingHorizontal: 16,
          paddingVertical: 8,
          borderRadius: 20,
          backgroundColor: active ? colors.primary : colors.surface,
          borderWidth: 1,
          borderColor: active ? colors.primary : colors.border,
        },
        pressed && { opacity: 0.7 },
      ]}
    >
      <Text style={{ color: active ? colors.background : colors.foreground, fontWeight: "600", fontSize: 13 }}>
        {label}
      </Text>
    </Pressable>
  );
}

function SortChip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
      <Text
        style={{
          color: active ? colors.primary : colors.muted,
          fontWeight: active ? "800" : "500",
          fontSize: 13,
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}
