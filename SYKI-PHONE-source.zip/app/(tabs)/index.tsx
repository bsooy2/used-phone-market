import { useEffect, useRef, useState } from "react";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { Dimensions, Linking, Platform, Pressable, ScrollView, Text, View } from "react-native";

import { PhoneCard, PhoneThumb, SectionHeader } from "@/components/phone-ui";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { POPULAR_MODELS, formatPrice } from "@/constants/phones";
import { STORE_INFO } from "@/constants/store-info";
import { useColors } from "@/hooks/use-colors";
import { ADMIN_USER_ID, useAppStore } from "@/lib/app-store";
import { useAdminStore } from "@/lib/admin-store";
import { useAuthStore } from "@/lib/auth-store";
import { getBannerImageSource, useContentStore } from "@/lib/content-store";
import { useReviewStore } from "@/lib/review-store";

const LOGO = require("@/assets/images/syki-logo.png");

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { allPhones, unreadCount } = useAppStore();
  const { user } = useAuthStore();
  const { isAdmin } = useAdminStore();
  const { notices, activeBanners, recordBannerClick, recordBannerConversion } = useContentStore();
  const { getPublicReviews } = useReviewStore();
  const activeNotices = notices.filter((n) => n.pinned).slice(0, 3).concat(notices.filter((n) => !n.pinned).slice(0, 2));
  const publicReviewPreview = getPublicReviews().slice(0, 3);
  const bannerWidth = Dimensions.get("window").width - 40;
  const bannerHeight = Math.min(Math.round(bannerWidth * 1.24), 420);
  const bannerScrollRef = useRef<ScrollView>(null);
  const [bannerPage, setBannerPage] = useState(0);
  const latest = allPhones.slice(0, 3);
  const unread = (user ? unreadCount(user.id) + unreadCount("__customer__") : 0) + (isAdmin ? unreadCount(ADMIN_USER_ID) : 0);

  const callStore = () => {
    const url = `tel:${STORE_INFO.phone.replace(/-/g, "")}`;
    if (Platform.OS !== "web") Linking.openURL(url).catch(() => {});
  };

  useEffect(() => {
    if (activeBanners.length < 2) return;
    const timer = setInterval(() => {
      setBannerPage((current) => {
        const next = (current + 1) % activeBanners.length;
        bannerScrollRef.current?.scrollTo({ x: next * bannerWidth, animated: true });
        return next;
      });
    }, 4500);
    return () => clearInterval(timer);
  }, [activeBanners.length, bannerWidth]);

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 32, gap: 24 }}>
        {/* 브랜드 헤더 */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Image source={LOGO} style={{ width: 52, height: 52, borderRadius: 14 }} contentFit="cover" />
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>
              {STORE_INFO.nameKo}
            </Text>
            <Text style={{ color: colors.muted, fontSize: 13 }}>{STORE_INFO.tagline}</Text>
          </View>
          <Pressable onPress={callStore} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 }, pressed && { opacity: 0.7 }]}>
            <IconSymbol name="phone.down.fill" size={16} color={colors.primary} />
            <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "700" }}>전화</Text>
          </Pressable>
          <Pressable
            onPress={() => router.push(user ? "/notifications" : "/auth")}
            style={({ pressed }) => [{ width: 40, height: 40, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10 }, pressed && { opacity: 0.7 }]}
          >
            <IconSymbol name="bell.fill" size={18} color={colors.foreground} />
            {unread > 0 && (
              <View style={{ position: "absolute", top: 4, right: 4, minWidth: 16, height: 16, borderRadius: 8, backgroundColor: colors.error, alignItems: "center", justifyContent: "center", paddingHorizontal: 3 }}>
                <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>{unread > 9 ? "9+" : unread}</Text>
              </View>
            )}
          </Pressable>
        </View>

        {/* 히어로 배너 */}
        <View
          style={{
            backgroundColor: colors.primary,
            borderRadius: 20,
            padding: 20,
            overflow: "hidden",
          }}
        >
          <Text style={{ color: colors.background, fontSize: 20, fontWeight: "800" }}>
            내 폰, 최고가에 팔아보세요
          </Text>
          <Text style={{ color: colors.background, opacity: 0.8, fontSize: 14, marginTop: 6 }}>
            간단한 정보 입력으로 예상 매입가를 즉시 확인하세요.
          </Text>
          <Pressable
            onPress={() => router.push("/(tabs)/sell")}
            style={({ pressed }) => [
              {
                marginTop: 16,
                backgroundColor: colors.background,
                borderRadius: 12,
                paddingVertical: 12,
                alignItems: "center",
                flexDirection: "row",
                justifyContent: "center",
                gap: 6,
              },
              pressed && { transform: [{ scale: 0.98 }], opacity: 0.9 },
            ]}
          >
            <Text style={{ color: colors.primary, fontWeight: "800", fontSize: 15 }}>
              지금 시세 조회하기
            </Text>
            <IconSymbol name="arrow.right" size={18} color={colors.primary} />
          </Pressable>
        </View>

        {/* 빠른 액션 */}
        {/* 공지사항 */}
        {activeNotices.length > 0 && (
          <View style={{ gap: 8 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>공지사항</Text>
              <Pressable onPress={() => router.push("/notices")} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 2, padding: 4 }, pressed && { opacity: 0.6 }]}>
                <Text style={{ color: colors.muted, fontSize: 12, fontWeight: "700" }}>전체보기</Text>
                <IconSymbol name="chevron.right" size={14} color={colors.muted} />
              </Pressable>
            </View>
           {activeNotices.map((n) => (
              <Pressable key={n.id} onPress={() => router.push(`/notice-detail?id=${n.id}`)} style={({ pressed }) => [{ backgroundColor: colors.surface, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: colors.border }, pressed && { opacity: 0.7 }]}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  {n.pinned && <Text style={{ fontSize: 11 }}>📌</Text>}
                  <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700", flex: 1 }}>{n.title}</Text>
                </View>
                {n.body ? <Text style={{ color: colors.muted, fontSize: 12, marginTop: 4 }} numberOfLines={2}>{n.body}</Text> : null}
              </Pressable>
            ))}
          </View>
        )}

        {/* 이벤트/광고 배너 */}
        {activeBanners.length > 0 && (
          <View style={{ gap: 10 }}>
            <ScrollView
              ref={bannerScrollRef}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              onMomentumScrollEnd={(event) => setBannerPage(Math.round(event.nativeEvent.contentOffset.x / bannerWidth))}
            >
              {activeBanners.map((b) => (
                <View key={b.id} style={{ width: bannerWidth, paddingRight: 1 }}>
                  <Pressable
                    onPress={async () => {
                      recordBannerClick(b.id);
                      if (!b.linkUrl) return;
                      try {
                        await Linking.openURL(b.linkUrl);
                        recordBannerConversion(b.id);
                      } catch {}
                    }}
                    style={({ pressed }) => [{ borderRadius: 14, overflow: "hidden", borderWidth: 1, borderColor: colors.border }, pressed && b.linkUrl ? { opacity: 0.85 } : {}]}
                  >
                    <Image source={getBannerImageSource(b.imageUri)} style={{ width: "100%", height: bannerHeight, backgroundColor: "#12131D" }} contentFit="contain" />
                    <View style={{ padding: 10, backgroundColor: colors.surface }}>
                      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>{b.title}</Text>
                    </View>
                  </Pressable>
                </View>
              ))}
            </ScrollView>
            {activeBanners.length > 1 ? <View style={{ flexDirection: "row", justifyContent: "center", gap: 5 }}>{activeBanners.map((b, index) => <View key={b.id} style={{ width: index === bannerPage ? 16 : 6, height: 6, borderRadius: 3, backgroundColor: index === bannerPage ? colors.primary : colors.border }} />)}</View> : null}
          </View>
        )}

        {publicReviewPreview.length > 0 && (
          <View style={{ gap: 10 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>고객 후기</Text>
              <Pressable onPress={() => router.push("/reviews")} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 2, padding: 4 }, pressed && { opacity: 0.6 }]}><Text style={{ color: colors.muted, fontSize: 12, fontWeight: "700" }}>전체보기</Text><IconSymbol name="chevron.right" size={14} color={colors.muted} /></Pressable>
            </View>
            {publicReviewPreview.map((review) => (
              <Pressable key={review.id} onPress={() => router.push("/reviews")} style={({ pressed }) => [{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 12, gap: 5 }, pressed && { opacity: 0.72 }]}>
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "800" }}>{review.authorName.slice(0, 1)}* 고객</Text><Text style={{ color: colors.primary, fontSize: 14, letterSpacing: 1 }}>{"★".repeat(review.rating)}</Text></View>
                <Text style={{ color: colors.muted, fontSize: 12, lineHeight: 17 }} numberOfLines={2}>{review.text}</Text>
              </Pressable>
            ))}
          </View>
        )}

        <View style={{ flexDirection: "row", gap: 12 }}>
          <QuickAction
            icon="tag.fill"
            label="중고폰 팔기"
            desc="시세 조회 & 신청"
            onPress={() => router.push("/(tabs)/sell")}
          />
          <QuickAction
            icon="bag.fill"
            label="매물 둘러보기"
            desc="검증된 중고폰"
            onPress={() => router.push("/(tabs)/listings")}
          />
        </View>

        {/* 매장 정보 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: colors.border, gap: 10 }}>
          <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 8 }}>
            <IconSymbol name="clock.fill" size={18} color={colors.primary} />
            <View style={{ flex: 1, gap: 3 }}>
              <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }}>
                {STORE_INFO.hours.weekday}
              </Text>
              <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }}>
                {STORE_INFO.hours.weekend}
              </Text>
              <Text style={{ color: colors.error, fontSize: 12, fontWeight: "700", marginTop: 1 }}>
                {STORE_INFO.hours.closed}
              </Text>
            </View>
          </View>
          <Pressable onPress={callStore} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 8 }, pressed && { opacity: 0.6 }]}>
            <IconSymbol name="phone.down.fill" size={18} color={colors.primary} />
            <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }}>{STORE_INFO.phone}</Text>
          </Pressable>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 2 }}>
            {STORE_INFO.services.map((s) => (
              <View key={s} style={{ backgroundColor: colors.background, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderColor: colors.border }}>
                <Text style={{ color: colors.muted, fontSize: 11 }}>{s}</Text>
              </View>
            ))}
          </View>
          <Text style={{ color: colors.muted, fontSize: 12, lineHeight: 18 }}>{STORE_INFO.notice}</Text>
        </View>

        {/* 인기 모델 매입 시세 */}
        <View>
          <SectionHeader title="인기 모델 매입가" />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 12 }}
          >
            {POPULAR_MODELS.map((m) => (
              <View
                key={m.model}
                style={{
                  width: 140,
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  padding: 12,
                  borderWidth: 1,
                  borderColor: colors.border,
                  gap: 8,
                }}
              >
                <PhoneThumb color={m.image} size={56} />
                <Text style={{ color: colors.muted, fontSize: 11 }}>{m.brand}</Text>
                <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }} numberOfLines={1}>
                  {m.model}
                </Text>
                <Text style={{ color: colors.muted, fontSize: 11 }}>최대 매입가</Text>
                <Text style={{ color: colors.primary, fontSize: 15, fontWeight: "800" }}>
                  {formatPrice(m.maxBuy)}
                </Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* 최신 매물 */}
        <View>
          <SectionHeader
            title="최신 매물"
            actionLabel="전체보기"
            onAction={() => router.push("/(tabs)/listings")}
          />
          <View style={{ gap: 12 }}>
            {latest.map((p) => (
              <PhoneCard key={p.id} phone={p} onPress={() => router.push(`/product/${p.id}`)} />
            ))}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function QuickAction({
  icon,
  label,
  desc,
  onPress,
}: {
  icon: "tag.fill" | "bag.fill";
  label: string;
  desc: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          flex: 1,
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 16,
          gap: 8,
          borderWidth: 1,
          borderColor: colors.border,
        },
        pressed && { opacity: 0.7, transform: [{ scale: 0.98 }] },
      ]}
    >
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: 12,
          backgroundColor: colors.primary,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <IconSymbol name={icon} size={24} color={colors.background} />
      </View>
      <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>{label}</Text>
      <Text style={{ color: colors.muted, fontSize: 12 }}>{desc}</Text>
    </Pressable>
  );
}
