import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, Image, Linking, Platform, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import * as ImagePicker from "expo-image-picker";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { SellRequest } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useAuthStore } from "@/lib/auth-store";
import { validateImei, LOST_PHONE_CHECK_LINKS, type ImeiValidation } from "@/lib/imei";
import {
  BUYBACK_MODELS,
  BuybackGrade,
  CONDITION_OPTIONS,
  ConditionKey,
  GRADE_LABELS,
  availableGrades,
  calculateQuote,
  formatManwon,
  getModelByKey,
  manwonToWon,
} from "@/lib/buyback";

const BRANDS: { key: "Apple" | "Samsung"; label: string }[] = [
  { key: "Apple", label: "애플" },
  { key: "Samsung", label: "삼성" },
];

const GRADE_HINTS: Record<BuybackGrade, string> = {
  A: "액정·테두리 무기스, 무잔상",
  Aminus: "액정 무기스, 테두리 약기스",
  Bplus: "액정 실기스, 테두리 찍힘 1~2방",
  B: "액정 잔기스 가능 (칼기스 불가)",
  liquid: "액파특가 / 바디 B급",
  used: "최저 중고 등급",
};

export default function SellScreen() {
  const colors = useColors();
  const router = useRouter();
  const { addSellRequest } = useAppStore();
  const { user, isSeller } = useAuthStore();

  const [brand, setBrand] = useState<"Apple" | "Samsung" | null>(null);
  const [modelKey, setModelKey] = useState<string | null>(null);
  const [storage, setStorage] = useState<string | null>(null);
  const [grade, setGrade] = useState<BuybackGrade | null>(null);
  const [conditions, setConditions] = useState<ConditionKey[]>([]);
  const [images, setImages] = useState<string[]>([]);
  const [imei, setImei] = useState("");
  const [imeiValidation, setImeiValidation] = useState<ImeiValidation | null>(null);
  const [privacyAgreed, setPrivacyAgreed] = useState(false);
  const [tradeTermsAgreed, setTradeTermsAgreed] = useState(false);
  const [notStolenConfirmed, setNotStolenConfirmed] = useState(false);

  const MAX_IMAGES = 4;

  const models = useMemo(
    () => (brand ? BUYBACK_MODELS.filter((m) => m.brand === brand) : []),
    [brand],
  );
  const selectedModel = useMemo(
    () => (modelKey ? getModelByKey(modelKey) : undefined),
    [modelKey],
  );
  const storages = useMemo(
    () => selectedModel?.variants.map((v) => v.storage) ?? [],
    [selectedModel],
  );
  const grades = useMemo(
    () => (selectedModel && storage ? availableGrades(selectedModel, storage) : []),
    [selectedModel, storage],
  );

  const quote = useMemo(() => {
    if (!modelKey || !storage || !grade) return null;
    return calculateQuote({ modelKey, storage, grade, conditions });
  }, [modelKey, storage, grade, conditions]);

  const canSubmit = !!(quote && quote.ok && privacyAgreed && tradeTermsAgreed && notStolenConfirmed);

  function handleImeiChange(text: string) {
    const cleaned = text.replace(/[^0-9]/g, "").slice(0, 15);
    setImei(cleaned);
    if (cleaned.length === 15) {
      setImeiValidation(validateImei(cleaned));
    } else {
      setImeiValidation(null);
    }
  }

  function reset() {
    setBrand(null);
    setModelKey(null);
    setStorage(null);
    setGrade(null);
    setConditions([]);
    setImages([]);
    setImei("");
    setImeiValidation(null);
    setPrivacyAgreed(false);
    setTradeTermsAgreed(false);
    setNotStolenConfirmed(false);
  }

  async function pickFromGallery() {
    if (images.length >= MAX_IMAGES) {
      Alert.alert("최대 4장", "사진은 최대 4장까지 첨부할 수 있습니다.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: MAX_IMAGES - images.length,
      quality: 0.7,
    });
    if (!result.canceled && result.assets.length > 0) {
      const uris = result.assets.map((a) => a.uri).slice(0, MAX_IMAGES - images.length);
      setImages((prev) => [...prev, ...uris].slice(0, MAX_IMAGES));
    }
  }

  async function pickFromCamera() {
    if (images.length >= MAX_IMAGES) {
      Alert.alert("최대 4장", "사진은 최대 4장까지 첨부할 수 있습니다.");
      return;
    }
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("카메라 권한", "카메라 사용을 허용해 주세요.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      quality: 0.7,
    });
    if (!result.canceled && result.assets.length > 0) {
      setImages((prev) => [...prev, result.assets[0].uri].slice(0, MAX_IMAGES));
    }
  }

  function removeImage(index: number) {
    setImages((prev) => prev.filter((_, i) => i !== index));
  }

  function toggleCondition(key: ConditionKey) {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setConditions((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
  }

  function submit() {
    if (!canSubmit || !quote || !selectedModel) return;
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    const conditionLabels = conditions
      .map((c) => CONDITION_OPTIONS.find((o) => o.key === c)?.label)
      .filter((l): l is string => !!l);
    const req: SellRequest = {
      id: `s${Date.now()}`,
      brand: selectedModel.brand === "Apple" ? "애플" : "삼성",
      model: quote.modelName,
      storage: quote.storage,
      gradeLabel: quote.gradeLabel,
      conditionLabels,
      imei: imei.length === 15 ? imei : undefined,
      imeiDeviceInfo: imeiValidation?.deviceInfo ? { brand: imeiValidation.deviceInfo.brand, model: imeiValidation.deviceInfo.model } : undefined,
      images: images.length > 0 ? images : undefined,
      agreements: {
        privacy: privacyAgreed,
        tradeTerms: tradeTermsAgreed,
        notStolen: notStolenConfirmed,
        agreedAt: new Date().toISOString(),
      },
      estimatedPrice: manwonToWon(quote.finalPrice),
      status: "접수",
      createdAt: new Date().toISOString().slice(0, 10),
    };
    addSellRequest(req);
    reset();
    router.push("/(tabs)/my");
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 48, gap: 24 }}>
        <View style={{ gap: 4 }}>
          <Text style={{ color: colors.foreground, fontSize: 24, fontWeight: "800" }}>내 폰 팔기</Text>
          <Text style={{ color: colors.muted, fontSize: 14 }}>
            기종·등급·상태를 선택하면 예상 매입가를 바로 알려드려요.
          </Text>
        </View>

        {/* 판매자 전용: 매물 등록 진입 / 그 외 안내 */}
        {isSeller ? (
          <Pressable
            onPress={() => router.push("/sell-new")}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                backgroundColor: colors.primary,
                borderRadius: 16,
                padding: 18,
              },
              pressed && { opacity: 0.9 },
            ]}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <IconSymbol name="plus.circle.fill" size={26} color={colors.background} />
              <View>
                <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>매물 등록하기</Text>
                <Text style={{ color: colors.background, opacity: 0.7, fontSize: 12, marginTop: 2 }}>
                  판매자 전용 · 판매할 중고폰을 올려보세요
                </Text>
              </View>
            </View>
            <IconSymbol name="arrow.right" size={20} color={colors.background} />
          </Pressable>
        ) : (
          <Pressable
            onPress={() => router.push("/auth")}
            style={({ pressed }) => [
              {
                backgroundColor: colors.surface,
                borderRadius: 16,
                padding: 18,
                borderWidth: 1,
                borderColor: colors.border,
                gap: 6,
              },
              pressed && { opacity: 0.85 },
            ]}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <IconSymbol name="tag.fill" size={18} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 15 }}>
                직접 매물을 등록하고 싶으세요?
              </Text>
            </View>
            <Text style={{ color: colors.muted, fontSize: 13 }}>
              {user
                ? "매물 등록은 판매자 회원만 가능합니다. 판매자로 가입해 주세요."
                : "판매자로 가입하면 중고폰 매물을 직접 등록할 수 있어요."}
            </Text>
          </Pressable>
        )}

        {/* 1. 제조사 */}
        <StepBlock step={1} title="제조사 선택">
          <View style={{ flexDirection: "row", gap: 10 }}>
            {BRANDS.map((b) => (
              <OptionChip
                key={b.key}
                label={b.label}
                active={brand === b.key}
                onPress={() => {
                  setBrand(b.key);
                  setModelKey(null);
                  setStorage(null);
                  setGrade(null);
                }}
              />
            ))}
          </View>
        </StepBlock>

        {/* 2. 모델 */}
        {brand && (
          <StepBlock step={2} title="모델 선택">
            <View style={{ gap: 10 }}>
              {models.map((m) => (
                <OptionRow
                  key={m.key}
                  label={m.model}
                  active={modelKey === m.key}
                  onPress={() => {
                    setModelKey(m.key);
                    setStorage(null);
                    setGrade(null);
                  }}
                />
              ))}
            </View>
          </StepBlock>
        )}

        {/* 3. 용량 */}
        {selectedModel && (
          <StepBlock step={3} title="용량 선택">
            <View style={{ flexDirection: "row", gap: 10, flexWrap: "wrap" }}>
              {storages.map((s) => (
                <OptionChip
                  key={s}
                  label={s}
                  active={storage === s}
                  onPress={() => {
                    setStorage(s);
                    setGrade(null);
                  }}
                />
              ))}
            </View>
          </StepBlock>
        )}

        {/* 4. 등급 */}
        {selectedModel && storage && (
          <StepBlock step={4} title="기본 등급 선택">
            <View style={{ gap: 10 }}>
              {grades.map((g) => (
                <GradeRow
                  key={g}
                  label={GRADE_LABELS[g]}
                  hint={GRADE_HINTS[g]}
                  active={grade === g}
                  onPress={() => setGrade(g)}
                />
              ))}
            </View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>
              잘 모르시면 A급으로 시작한 뒤 아래 상태를 체크해 주세요.
            </Text>
          </StepBlock>
        )}

        {/* 5. 상태 옵션 */}
        {grade && (
          <StepBlock step={5} title="기기 상태 체크 (해당 항목만)">
            <View style={{ gap: 10 }}>
              {CONDITION_OPTIONS.map((opt) => (
                <ConditionCheck
                  key={opt.key}
                  label={opt.label}
                  hint={opt.hint}
                  checked={conditions.includes(opt.key)}
                  onToggle={() => toggleCondition(opt.key)}
                />
              ))}
            </View>
          </StepBlock>
        )}

        {/* 6. 기기 사진 첨부 */}
        {grade && (
          <StepBlock step={6} title="기기 사진 첨부 (선택)">
            <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 4 }}>
              기기 상태를 보여주는 사진을 첨부하면 더 정확한 견적을 받을 수 있어요. (최대 4장)
            </Text>
            {/* 이미지 미리보기 */}
            {images.length > 0 && (
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 8 }}>
                {images.map((uri, idx) => (
                  <View key={idx} style={{ position: "relative" }}>
                    <Image
                      source={{ uri }}
                      style={{ width: 72, height: 72, borderRadius: 10, backgroundColor: colors.surface }}
                    />
                    <Pressable
                      onPress={() => removeImage(idx)}
                      style={({ pressed }) => [
                        {
                          position: "absolute",
                          top: -6,
                          right: -6,
                          width: 22,
                          height: 22,
                          borderRadius: 11,
                          backgroundColor: colors.foreground,
                          alignItems: "center",
                          justifyContent: "center",
                        },
                        pressed && { opacity: 0.7 },
                      ]}
                    >
                      <Text style={{ color: colors.background, fontSize: 13, fontWeight: "800", lineHeight: 15 }}>×</Text>
                    </Pressable>
                  </View>
                ))}
              </View>
            )}
            {/* 버튼 */}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable
                onPress={pickFromGallery}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                    paddingVertical: 14,
                    borderRadius: 12,
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <IconSymbol name="photo.fill" size={18} color={colors.primary} />
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 14 }}>앨범</Text>
              </Pressable>
              <Pressable
                onPress={pickFromCamera}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                    paddingVertical: 14,
                    borderRadius: 12,
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <IconSymbol name="camera.fill" size={18} color={colors.primary} />
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 14 }}>카메라</Text>
              </Pressable>
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, textAlign: "center" }}>
              {images.length}/{MAX_IMAGES}장 첨부됨
            </Text>
          </StepBlock>
        )}

        {/* 7. IMEI 입력 */}
        {grade && (
          <StepBlock step={7} title="IMEI 입력 (선택)">
            <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 4 }}>
              IMEI를 입력하면 기기 정보를 자동으로 확인하고, 분실 여부 조회 안내를 받을 수 있어요.
            </Text>
            <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>
              📱 IMEI 확인 방법: 전화 앱에서 *#06# 입력
            </Text>
            <TextInput
              value={imei}
              onChangeText={handleImeiChange}
              placeholder="IMEI 15자리 숫자 입력"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              maxLength={15}
              returnKeyType="done"
              style={{
                backgroundColor: colors.surface,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 14,
                fontSize: 16,
                fontWeight: "600",
                color: colors.foreground,
                borderWidth: 1,
                borderColor: imeiValidation
                  ? imeiValidation.isValid
                    ? colors.primary
                    : "#DC2626"
                  : colors.border,
                letterSpacing: 1,
              }}
            />
            <Text style={{ color: colors.muted, fontSize: 11, textAlign: "right", marginTop: 2 }}>
              {imei.length}/15자리
            </Text>

            {/* IMEI 검증 결과 */}
            {imeiValidation && (
              <View
                style={{
                  marginTop: 8,
                  padding: 14,
                  borderRadius: 12,
                  backgroundColor: imeiValidation.isValid ? colors.surface : "#FEF2F2",
                  borderWidth: 1,
                  borderColor: imeiValidation.isValid ? colors.primary : "#DC2626",
                  gap: 6,
                }}
              >
                {imeiValidation.isValid ? (
                  <>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                      <IconSymbol name="checkmark.circle.fill" size={18} color={colors.primary} />
                      <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 14 }}>
                        유효한 IMEI입니다
                      </Text>
                    </View>
                    {imeiValidation.deviceInfo && (
                      <View style={{ paddingLeft: 24, gap: 2 }}>
                        <Text style={{ color: colors.foreground, fontSize: 13 }}>
                          제조사: {imeiValidation.deviceInfo.brand}
                        </Text>
                        <Text style={{ color: colors.foreground, fontSize: 13 }}>
                          모델: {imeiValidation.deviceInfo.model}
                        </Text>
                        <Text style={{ color: colors.muted, fontSize: 11, marginTop: 2 }}>
                          {imeiValidation.deviceInfo.source === "local" ? "로컬 DB 조회" : "API 조회"}
                        </Text>
                      </View>
                    )}
                    {!imeiValidation.deviceInfo && (
                      <Text style={{ color: colors.muted, fontSize: 12, paddingLeft: 24 }}>
                        기기 정보를 찾을 수 없습니다. IMEI가 정확한지 확인해 주세요.
                      </Text>
                    )}
                  </>
                ) : (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Text style={{ color: "#DC2626", fontSize: 14, fontWeight: "600" }}>
                      ⚠️ {imeiValidation.errorMessage}
                    </Text>
                  </View>
                )}
              </View>
            )}

            {/* 분실폰 확인 안내 링크 */}
            {imei.length === 15 && (
              <View style={{ marginTop: 12, gap: 8 }}>
                <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>
                  분실/도난 여부 확인 안내
                </Text>
                <Text style={{ color: colors.muted, fontSize: 11, lineHeight: 16 }}>
                  아래 기관에서 분실 등록 여부를 직접 확인하실 수 있습니다.
                </Text>
                {LOST_PHONE_CHECK_LINKS.map((link, idx) => (
                  <Pressable
                    key={idx}
                    onPress={() => Linking.openURL(link.url)}
                    style={({ pressed }) => [
                      {
                        flexDirection: "row",
                        alignItems: "center",
                        gap: 8,
                        paddingVertical: 10,
                        paddingHorizontal: 12,
                        borderRadius: 10,
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                      },
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <IconSymbol name="arrow.up.right" size={14} color={colors.primary} />
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "600" }}>
                        {link.name}
                      </Text>
                      <Text style={{ color: colors.muted, fontSize: 11 }}>
                        {link.description}
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </View>
            )}
          </StepBlock>
        )}

        {/* 예상 매입가 */}
        {quote && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 20,
              borderWidth: 1,
              borderColor: quote.ok ? colors.primary : colors.border,
              gap: 10,
            }}
          >
            {quote.ok ? (
              <>
                <View style={{ alignItems: "center", gap: 4 }}>
                  <Text style={{ color: colors.muted, fontSize: 14 }}>예상 매입가</Text>
                  <Text style={{ color: colors.primary, fontSize: 32, fontWeight: "900" }}>
                    {quote.finalPrice > 0 ? formatManwon(quote.finalPrice) : "별도 문의"}
                  </Text>
                </View>
                {/* 산출 내역 */}
                <View style={{ gap: 6, marginTop: 4 }}>
                  <LineRow label={`${quote.gradeLabel} 기준가`} value={`${formatManwon(quote.basePrice)}`} colors={colors} />
                  {quote.deductions.map((d, i) => (
                    <LineRow
                      key={i}
                      label={d.label}
                      value={`${d.amount}만원`}
                      colors={colors}
                      muted
                    />
                  ))}
                </View>
                <View style={{ height: 1, backgroundColor: colors.border, marginVertical: 2 }} />
                <Text style={{ color: colors.muted, fontSize: 12, textAlign: "center" }}>
                  배터리 효율 {quote.batteryMin}% 이상 기준 · 실제 매입가는 정밀 검수 후 확정됩니다.
                </Text>
              </>
            ) : (
              <Text style={{ color: colors.foreground, fontSize: 14, textAlign: "center" }}>
                {quote.reason}
              </Text>
            )}
          </View>
        )}

        {/* 개인정보 동의 */}
        {quote && quote.ok && (
          <View style={{ gap: 10 }}>
            <Pressable
              onPress={() => setPrivacyAgreed((v) => !v)}
              style={({ pressed }) => [
                {
                  flexDirection: "row",
                  alignItems: "flex-start",
                  gap: 10,
                  paddingVertical: 4,
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 6,
                  backgroundColor: privacyAgreed ? colors.primary : "transparent",
                  borderWidth: 1.5,
                  borderColor: privacyAgreed ? colors.primary : colors.border,
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 1,
                }}
              >
                {privacyAgreed && <IconSymbol name="checkmark" size={14} color={colors.background} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20 }}>
                  [필수] 개인정보 수집 및 이용에 동의합니다.
                </Text>
                <Text style={{ color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 2 }}>
                  견적 신청을 위해 기기 정보, 사진, 연락처를 수집합니다.
                </Text>
              </View>
            </Pressable>
            <Pressable
              onPress={() => router.push("/privacy")}
              style={({ pressed }) => [{ paddingLeft: 32 }, pressed && { opacity: 0.6 }]}
            >
              <Text style={{ color: colors.muted, fontSize: 12, textDecorationLine: "underline" }}>
                개인정보처리방침 전문 보기
              </Text>
            </Pressable>
          </View>
        )}

        {/* 안전거래 약관 동의 */}
        {quote && quote.ok && (
          <View style={{ gap: 10 }}>
            <Pressable
              onPress={() => setTradeTermsAgreed((v) => !v)}
              style={({ pressed }) => [
                {
                  flexDirection: "row",
                  alignItems: "flex-start",
                  gap: 10,
                  paddingVertical: 4,
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 6,
                  backgroundColor: tradeTermsAgreed ? colors.primary : "transparent",
                  borderWidth: 1.5,
                  borderColor: tradeTermsAgreed ? colors.primary : colors.border,
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 1,
                }}
              >
                {tradeTermsAgreed && <IconSymbol name="checkmark" size={14} color={colors.background} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20 }}>
                  [필수] 안전거래 약관에 동의합니다.
                </Text>
                <Text style={{ color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 2 }}>
                  매매 계약 조건(제1~5조) 및 하자 책임에 동의합니다.
                </Text>
              </View>
            </Pressable>
            <Pressable
              onPress={() => router.push("/trade-terms")}
              style={({ pressed }) => [{ paddingLeft: 32 }, pressed && { opacity: 0.6 }]}
            >
              <Text style={{ color: colors.muted, fontSize: 12, textDecorationLine: "underline" }}>
                안전거래 약관 전문 보기
              </Text>
            </Pressable>
          </View>
        )}

        {/* 분실폰 확인 */}
        {quote && quote.ok && (
          <View style={{ gap: 10 }}>
            <Pressable
              onPress={() => setNotStolenConfirmed((v) => !v)}
              style={({ pressed }) => [
                {
                  flexDirection: "row",
                  alignItems: "flex-start",
                  gap: 10,
                  paddingVertical: 4,
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 6,
                  backgroundColor: notStolenConfirmed ? "#DC2626" : "transparent",
                  borderWidth: 1.5,
                  borderColor: notStolenConfirmed ? "#DC2626" : colors.border,
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 1,
                }}
              >
                {notStolenConfirmed && <IconSymbol name="checkmark" size={14} color={colors.background} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: "#DC2626", fontSize: 13, fontWeight: "700", lineHeight: 20 }}>
                  [필수] 본 기기는 분실폰이 아닙니다.
                </Text>
                <Text style={{ color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 2 }}>
                  분실·도난폰 판매 시 법적 책임을 집니다. (형법 제360조 장물은닉죄)
                </Text>
              </View>
            </Pressable>
          </View>
        )}

        {/* 제출 */}
        <Pressable
          disabled={!canSubmit}
          onPress={submit}
          style={({ pressed }) => [
            {
              backgroundColor: canSubmit ? colors.primary : colors.border,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
            },
            pressed && canSubmit && { transform: [{ scale: 0.98 }], opacity: 0.9 },
          ]}
        >
          <Text style={{ color: canSubmit ? colors.background : colors.muted, fontWeight: "800", fontSize: 16 }}>
            판매 신청하기
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

function LineRow({
  label,
  value,
  colors,
  muted,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
  muted?: boolean;
}) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{ color: muted ? colors.muted : colors.foreground, fontSize: 13 }}>{label}</Text>
      <Text style={{ color: muted ? colors.muted : colors.foreground, fontSize: 13, fontWeight: "600" }}>
        {value}
      </Text>
    </View>
  );
}

function StepBlock({
  step,
  title,
  children,
}: {
  step: number;
  title: string;
  children: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={{ gap: 12 }}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
        <View
          style={{
            width: 24,
            height: 24,
            borderRadius: 12,
            backgroundColor: colors.primary,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ color: colors.background, fontSize: 13, fontWeight: "800" }}>{step}</Text>
        </View>
        <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "700" }}>{title}</Text>
      </View>
      {children}
    </View>
  );
}

function OptionChip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          paddingHorizontal: 20,
          paddingVertical: 12,
          borderRadius: 12,
          backgroundColor: active ? colors.primary : colors.surface,
          borderWidth: 1,
          borderColor: active ? colors.primary : colors.border,
        },
        pressed && { opacity: 0.7 },
      ]}
    >
      <Text style={{ color: active ? colors.background : colors.foreground, fontWeight: "700", fontSize: 14 }}>
        {label}
      </Text>
    </Pressable>
  );
}

function OptionRow({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 14,
          borderRadius: 12,
          backgroundColor: colors.surface,
          borderWidth: 1,
          borderColor: active ? colors.primary : colors.border,
        },
        pressed && { opacity: 0.7 },
      ]}
    >
      <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 15 }}>{label}</Text>
      {active && <IconSymbol name="checkmark.circle.fill" size={20} color={colors.primary} />}
    </Pressable>
  );
}

function GradeRow({
  label,
  hint,
  active,
  onPress,
}: {
  label: string;
  hint: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 14,
          borderRadius: 12,
          backgroundColor: active ? colors.primary : colors.surface,
          borderWidth: 1,
          borderColor: active ? colors.primary : colors.border,
        },
        pressed && { opacity: 0.7 },
      ]}
    >
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ color: active ? colors.background : colors.foreground, fontWeight: "700", fontSize: 15 }}>
          {label}
        </Text>
        <Text style={{ color: active ? colors.background : colors.muted, fontSize: 12, opacity: active ? 0.8 : 1 }}>
          {hint}
        </Text>
      </View>
      {active && <IconSymbol name="checkmark.circle.fill" size={20} color={colors.background} />}
    </Pressable>
  );
}

function ConditionCheck({
  label,
  hint,
  checked,
  onToggle,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onToggle: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onToggle}
      style={({ pressed }) => [
        {
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 14,
          borderRadius: 12,
          backgroundColor: colors.surface,
          borderWidth: 1,
          borderColor: checked ? colors.primary : colors.border,
          gap: 12,
        },
        pressed && { opacity: 0.8 },
      ]}
    >
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 14 }}>{label}</Text>
        <Text style={{ color: colors.muted, fontSize: 12 }}>{hint}</Text>
      </View>
      <View
        style={{
          width: 26,
          height: 26,
          borderRadius: 8,
          backgroundColor: checked ? colors.primary : "transparent",
          borderWidth: 1.5,
          borderColor: checked ? colors.primary : colors.border,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {checked && <IconSymbol name="checkmark" size={16} color={colors.background} />}
      </View>
    </Pressable>
  );
}
