import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";

import { Alert } from "react-native";

import { PhoneCard } from "@/components/phone-ui";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { formatPrice } from "@/constants/phones";
import { Order, SellRequest } from "@/constants/types";
import { formatKRW } from "@/lib/payment";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useAuthStore } from "@/lib/auth-store";
import { useAdminStore } from "@/lib/admin-store";
import { usePointStore } from "@/lib/point-store";
import { PHOTO_REVIEW_REWARD_POINTS, REVIEW_MAX_EDITS } from "@/lib/review-rules";
import { useReviewStore } from "@/lib/review-store";

type Tab = "sell" | "fav" | "listing" | "order";

const METHOD_LABEL: Record<Order["method"], string> = {
  card: "카드",
  transfer: "계좌이체",
  kakaopay: "카카오페이",
  naverpay: "네이버페이",
};

const STATUS_COLOR: Record<SellRequest["status"], string> = {
  접수: "#9A9A9A",
  검수중: "#4B4B4B",
  입금완료: "#111111",
};

export default function MyScreen() {
  const colors = useColors();
  const router = useRouter();
  const { balance } = usePointStore();
  const { getReviewForTransaction } = useReviewStore();
  const { sellRequests, favorites, allPhones, userListings, removeListing, orders, getFavoriteAlert, setFavoriteAlert } = useAppStore();
  const { user, isSeller, signOut, switchRole } = useAuthStore();
  const { isAdmin } = useAdminStore();
  const isBuyer = user?.role === "buyer";

  function handleSwitchRole() {
    const targetRole = isBuyer ? "판매자" : "구매자";
    const desc = isBuyer
      ? "판매자로 전환하면 매물을 등록하고 판매할 수 있습니다. 구매자 정보는 유지됩니다."
      : "구매자로 전환하면 매물 구경과 구매가 가능합니다. 판매자 매물은 유지됩니다.";
    Alert.alert("역할 전환", `${targetRole}로 전환하시겠습니까?\n\n${desc}`, [
      { text: "취소", style: "cancel" },
      {
        text: "전환",
        onPress: async () => {
          const res = await switchRole();
          if (res.ok) Alert.alert("완료", `${targetRole}로 전환되었습니다.`);
          else Alert.alert("오류", res.error ?? "전환에 실패했습니다.");
        },
      },
    ]);
  }

  const [tab, setTab] = useState<Tab>("sell");

  // 구매자이면서 판매자 전용 탭(sell/listing)에 머물러 있으면 주문내역으로 보정
  const effectiveTab: Tab = isBuyer && (tab === "sell" || tab === "listing") ? "order" : (!isBuyer && tab === "order" ? "sell" : tab);

  const favPhones = useMemo(
    () => allPhones.filter((p) => favorites.includes(p.id)),
    [allPhones, favorites],
  );

  const myListings = useMemo(
    () => userListings.filter((p) => p.sellerId === user?.id),
    [userListings, user?.id],
  );

  const myOrders = useMemo(
    () => orders.filter((o) => o.buyerId === user?.id),
    [orders, user?.id],
  );

  const confirmSignOut = () => {
    Alert.alert("로그아웃", "로그아웃 하시겠어요?", [
      { text: "취소", style: "cancel" },
      { text: "로그아웃", style: "destructive", onPress: () => signOut() },
    ]);
  };

  const confirmRemove = (id: string) => {
    Alert.alert("매물 삭제", "이 매물을 삭제할까요?", [
      { text: "취소", style: "cancel" },
      { text: "삭제", style: "destructive", onPress: () => removeListing(id) },
    ]);
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40, gap: 20 }}>
        {/* 프로필 헤더 */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
          <View
            style={{
              width: 60,
              height: 60,
              borderRadius: 30,
              backgroundColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <IconSymbol name="person.fill" size={30} color={user ? colors.primary : colors.muted} />
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>
                {user ? user.nickname : "게스트 사용자"}
              </Text>
              {user && (
                <View style={{ backgroundColor: colors.primary, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 }}>
                  <Text style={{ color: colors.background, fontSize: 11, fontWeight: "700" }}>
                    {isSeller ? "판매자" : "구매자"}
                  </Text>
                </View>
              )}
            </View>
            <Text style={{ color: colors.muted, fontSize: 13, marginTop: 2 }}>
              {user ? user.phone : "로그인하고 거래 내역을 관리하세요"}
            </Text>
          </View>
          {user ? (
            <Pressable onPress={confirmSignOut} hitSlop={8} style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}>
              <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "600" }}>로그아웃</Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={() => router.push("/auth")}
              style={({ pressed }) => [{ backgroundColor: colors.primary, borderRadius: 10, paddingHorizontal: 16, paddingVertical: 10 }, pressed && { opacity: 0.85 }]}
            >
              <Text style={{ color: colors.background, fontWeight: "700", fontSize: 13 }}>로그인</Text>
            </Pressable>
          )}
        </View>

        {/* 구매자 정보 관리 진입 */}
        {/* 역할 전환 */}
        {user && (
          <Pressable
            onPress={handleSwitchRole}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderRadius: 12,
                padding: 14,
                borderWidth: 1,
                borderColor: colors.border,
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <IconSymbol name="arrow.left.arrow.right" size={18} color={colors.primary} />
            <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "600", flex: 1 }}>
              {isBuyer ? "판매자로 전환" : "구매자로 전환"}
            </Text>
            <Text style={{ color: colors.muted, fontSize: 12 }}>현재: {isBuyer ? "구매자" : "판매자"}</Text>
          </Pressable>
        )}

        {/* 비밀번호 변경 */}
        {user && (
          <Pressable
            onPress={() => router.push("/change-password")}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderRadius: 12,
                padding: 14,
                borderWidth: 1,
                borderColor: colors.border,
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <IconSymbol name="lock.fill" size={18} color={colors.muted} />
            <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "600", flex: 1 }}>비밀번호 변경</Text>
            <IconSymbol name="chevron.right" size={16} color={colors.muted} />
          </Pressable>
        )}

        {/* 포인트 잔액: 탭 시 적립/사용 내역으로 이동 */}
        {user && (
          <Pressable
            onPress={() => router.push("/point-history")}
            style={({ pressed }) => [
              { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.foreground, borderRadius: 14, padding: 16 },
              pressed && { opacity: 0.82 },
            ]}
          >
            <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: colors.background + "26", alignItems: "center", justifyContent: "center" }}>
              <Text style={{ color: colors.background, fontWeight: "900", fontSize: 15 }}>P</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.background, fontSize: 12, opacity: 0.76 }}>보유 포인트</Text>
              <Text style={{ color: colors.background, fontSize: 20, fontWeight: "900", marginTop: 2 }}>{balance.toLocaleString()}P</Text>
            </View>
            <Text style={{ color: colors.background, fontSize: 12, fontWeight: "700" }}>내역 보기 ›</Text>
          </Pressable>
        )}

        {user && (
          <Pressable
            onPress={() => router.push("/my-reviews")}
            style={({ pressed }) => [
              { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.surface, borderRadius: 14, padding: 16, borderWidth: 1, borderColor: colors.border },
              pressed && { opacity: 0.72 },
            ]}
          >
            <Text style={{ color: colors.primary, fontSize: 22, fontWeight: "900" }}>★</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>내 거래 후기</Text>
              <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>사진 후기 작성 시 10,000P 적립</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </Pressable>
        )}

        {isBuyer && (
          <Pressable
            onPress={() => router.push("/buyer-info")}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                backgroundColor: colors.surface,
                borderRadius: 14,
                padding: 16,
                borderWidth: 1,
                borderColor: colors.border,
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <IconSymbol name="person.fill" size={20} color={colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>구매자 정보 관리</Text>
              <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>배송지 · 이메일 · 환불계좌 수정</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </Pressable>
        )}

        {/* 판매자 정산 내역 진입 */}
        {isSeller && (
          <Pressable
            onPress={() => router.push("/settlement")}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                backgroundColor: colors.surface,
                borderRadius: 14,
                padding: 16,
                borderWidth: 1,
                borderColor: colors.border,
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <IconSymbol name="chart.bar.fill" size={20} color={colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>정산 내역</Text>
              <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>판매 현황 · 수수료 · 정산 예정액</Text>
            </View>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </Pressable>
        )}

        {/* 관리자(사장님) 매물 관리 진입 */}
        {!isBuyer && <Pressable
          onPress={() => router.push("/admin")}
          style={({ pressed }) => [
            {
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              backgroundColor: colors.foreground,
              borderRadius: 14,
              padding: 16,
            },
            pressed && { opacity: 0.85 },
          ]}
        >
          <IconSymbol name="gearshape.fill" size={20} color={colors.background} />
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.background, fontSize: 15, fontWeight: "700" }}>
              매물 관리 (사장님)
            </Text>
            <Text style={{ color: colors.background, opacity: 0.7, fontSize: 12, marginTop: 2 }}>
              {isAdmin ? "관리자 모드 활성화됨 · 매물 추가/수정/삭제" : "관리자 PIN으로 매물을 직접 관리하세요"}
            </Text>
          </View>
          <IconSymbol name="chevron.right" size={20} color={colors.background} />
        </Pressable>}

        {/* 요약 통계 */}
        <View style={{ flexDirection: "row", gap: 12 }}>
          {isBuyer ? (
            <StatCard label="주문 내역" value={myOrders.length} />
          ) : (
            <StatCard label="판매 신청" value={sellRequests.length} />
          )}
          <StatCard label="찜한 매물" value={favorites.length} />
        </View>

        <Pressable onPress={() => router.push("/my-inquiries")} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 13 }, pressed && { opacity: 0.7 }]}>
          <IconSymbol name="message.fill" size={19} color={colors.primary} />
          <View style={{ flex: 1 }}><Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 14 }}>내 거래 1:1 문의</Text><Text style={{ color: colors.muted, fontSize: 11, marginTop: 2 }}>주문·판매 신청별 문의와 사장님 답변을 확인하세요.</Text></View>
          <IconSymbol name="chevron.right" size={18} color={colors.muted} />
        </Pressable>

        {/* 탭 전환 */}
        <View
          style={{
            flexDirection: "row",
            backgroundColor: colors.surface,
            borderRadius: 12,
            padding: 4,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          {isBuyer ? (
            <SegTab label="주문내역" active={tab === "order"} onPress={() => setTab("order")} />
          ) : (
            <SegTab label="매입신청" active={tab === "sell"} onPress={() => setTab("sell")} />
          )}
          <SegTab label="찜 목록" active={effectiveTab === "fav"} onPress={() => setTab("fav")} />
          {isSeller && (
            <SegTab label="내 매물" active={effectiveTab === "listing"} onPress={() => setTab("listing")} />
          )}
        </View>

        {/* 내용 */}
        {effectiveTab === "order" ? (
          myOrders.length === 0 ? (
            <EmptyState
              icon="doc.text.fill"
              text="주문 내역이 없습니다."
              actionLabel="매물 둘러보기"
              onAction={() => router.push("/(tabs)/listings")}
            />
          ) : (
            <View style={{ gap: 12 }}>
              {myOrders.map((o) => (
                <View
                  key={o.id}
                  style={{
                    backgroundColor: colors.surface,
                    borderRadius: 16,
                    padding: 16,
                    borderWidth: 1,
                    borderColor: colors.border,
                    gap: 8,
                  }}
                >
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                    <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }} numberOfLines={1}>
                      {o.productName}
                    </Text>
                    <View style={{ backgroundColor: colors.foreground, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}>
                      <Text style={{ color: colors.background, fontSize: 11, fontWeight: "700" }}>{o.status}</Text>
                    </View>
                  </View>
                  <Text style={{ color: colors.muted, fontSize: 12 }}>
                    {METHOD_LABEL[o.method]} · 주문번호 {o.id}
                  </Text>
                  <Text style={{ color: colors.primary, fontSize: 17, fontWeight: "800" }}>{formatKRW(o.amount)}</Text>
                  {o.status === "배송완료" && user && (() => {
                    const review = getReviewForTransaction(user.id, o.id, "purchase");
                    return review ? (
                      <Pressable onPress={() => router.push({ pathname: "/write-review", params: { transactionId: o.id, transactionType: "purchase", transactionLabel: o.productName, reviewId: review.id } })} style={{ alignSelf: "flex-start", paddingVertical: 5 }}>
                        <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "800" }}>{review.editCount < REVIEW_MAX_EDITS ? `후기 수정 (${review.editCount}/${REVIEW_MAX_EDITS})` : "후기 작성 완료"}</Text>
                      </Pressable>
                    ) : (
                      <Pressable onPress={() => router.push({ pathname: "/write-review", params: { transactionId: o.id, transactionType: "purchase", transactionLabel: o.productName } })} style={{ backgroundColor: colors.foreground, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 9, alignSelf: "flex-start" }}>
                        <Text style={{ color: colors.background, fontSize: 12, fontWeight: "800" }}>사진 후기 작성 · +{PHOTO_REVIEW_REWARD_POINTS.toLocaleString()}P</Text>
                      </Pressable>
                    );
                  })()}
                  <Pressable onPress={() => router.push({ pathname: "/trade-inquiry", params: { transactionId: o.id, transactionType: "order", transactionLabel: o.productName } })} style={({ pressed }) => [{ alignSelf: "flex-start", paddingVertical: 5 }, pressed && { opacity: 0.6 }]}>
                    <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "800" }}>이 거래 1:1 문의</Text>
                  </Pressable>
                </View>
              ))}
            </View>
          )
        ) : effectiveTab === "sell" ? (
          sellRequests.length === 0 ? (
            <EmptyState
              icon="doc.text.fill"
              text="아직 판매 신청 내역이 없습니다."
              actionLabel="중고폰 팔러 가기"
              onAction={() => router.push("/(tabs)/sell")}
            />
          ) : (
            <View style={{ gap: 12 }}>
              {sellRequests.map((req) => (
                <Pressable
                  key={req.id}
                  onPress={() => router.push(`/sell-detail?id=${req.id}`)}
                  style={({ pressed }) => [
                    {
                      backgroundColor: colors.surface,
                      borderRadius: 16,
                      padding: 16,
                      borderWidth: 1,
                      borderColor: colors.border,
                      gap: 8,
                    },
                    pressed && { opacity: 0.7 },
                  ]}
                >
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                    <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>
                      {req.model}
                    </Text>
                    <View
                      style={{
                        backgroundColor: STATUS_COLOR[req.status],
                        borderRadius: 6,
                        paddingHorizontal: 8,
                        paddingVertical: 3,
                      }}
                    >
                      <Text style={{ color: "#FFFFFF", fontSize: 11, fontWeight: "700" }}>{req.status}</Text>
                    </View>
                  </View>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>
                    {req.brand} · {req.storage}{req.gradeLabel ? ` · ${req.gradeLabel}` : ""} · 신청일 {req.createdAt}
                  </Text>
                  {req.conditionLabels && req.conditionLabels.length > 0 && (
                    <Text style={{ color: colors.muted, fontSize: 12 }}>
                      상태: {req.conditionLabels.join(", ")}
                    </Text>
                  )}
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                    <Text style={{ color: colors.primary, fontSize: 17, fontWeight: "800" }}>
                      예상 매입가 {formatPrice(req.estimatedPrice)}
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
                      <Text style={{ color: colors.muted, fontSize: 12 }}>상세보기</Text>
                      <IconSymbol name="chevron.right" size={16} color={colors.muted} />
                    </View>
                  </View>
                  {req.status === "입금완료" && user && (() => {
                    const review = getReviewForTransaction(user.id, req.id, "sell");
                    return review ? (
                      <Pressable onPress={() => router.push({ pathname: "/write-review", params: { transactionId: req.id, transactionType: "sell", transactionLabel: `${req.model} 판매 거래`, reviewId: review.id } })} style={{ alignSelf: "flex-end", paddingVertical: 4 }}>
                        <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "800" }}>{review.editCount < REVIEW_MAX_EDITS ? `후기 수정 (${review.editCount}/${REVIEW_MAX_EDITS})` : "후기 작성 완료"}</Text>
                      </Pressable>
                    ) : (
                      <Pressable onPress={() => router.push({ pathname: "/write-review", params: { transactionId: req.id, transactionType: "sell", transactionLabel: `${req.model} 판매 거래` } })} style={{ backgroundColor: colors.foreground, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 9, alignSelf: "flex-end" }}>
                        <Text style={{ color: colors.background, fontSize: 12, fontWeight: "800" }}>사진 후기 작성 · +{PHOTO_REVIEW_REWARD_POINTS.toLocaleString()}P</Text>
                      </Pressable>
                    );
                  })()}
                </Pressable>
              ))}
            </View>
          )
        ) : effectiveTab === "fav" ? (
          favPhones.length === 0 ? (
            <EmptyState
              icon="heart"
              text="찜한 매물이 없습니다."
              actionLabel="매물 둘러보기"
              onAction={() => router.push("/(tabs)/listings")}
            />
          ) : (
            <View style={{ gap: 12 }}>
              {favPhones.map((p) => (
                <View key={p.id} style={{ gap: 7 }}>
                  <PhoneCard phone={p} onPress={() => router.push(`/product/${p.id}`)} />
                  {(() => {
                    const preference = getFavoriteAlert(p.id) ?? { priceDrop: false, lowStock: false };
                    return <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 4 }}>
                      <Pressable onPress={() => setFavoriteAlert(p.id, { priceDrop: !preference.priceDrop, lowStock: preference.lowStock })} style={({ pressed }) => [{ flex: 1, borderRadius: 8, paddingVertical: 8, alignItems: "center", backgroundColor: preference.priceDrop ? colors.foreground : colors.surface, borderWidth: 1, borderColor: preference.priceDrop ? colors.foreground : colors.border }, pressed && { opacity: 0.7 }]}><Text style={{ color: preference.priceDrop ? colors.background : colors.foreground, fontSize: 11, fontWeight: "800" }}>가격 인하 알림</Text></Pressable>
                      <Pressable onPress={() => setFavoriteAlert(p.id, { priceDrop: preference.priceDrop, lowStock: !preference.lowStock })} style={({ pressed }) => [{ flex: 1, borderRadius: 8, paddingVertical: 8, alignItems: "center", backgroundColor: preference.lowStock ? colors.foreground : colors.surface, borderWidth: 1, borderColor: preference.lowStock ? colors.foreground : colors.border }, pressed && { opacity: 0.7 }]}><Text style={{ color: preference.lowStock ? colors.background : colors.foreground, fontSize: 11, fontWeight: "800" }}>품절 임박 알림</Text></Pressable>
                    </View>;
                  })()}
                </View>
              ))}
            </View>
          )
        ) : myListings.length === 0 ? (
          <EmptyState
            icon="doc.text.fill"
            text="등록한 매물이 없습니다."
            actionLabel="매물 등록하기"
            onAction={() => router.push("/sell-new")}
          />
        ) : (
          <View style={{ gap: 12 }}>
            {myListings.map((p) => (
              <View key={p.id} style={{ gap: 6 }}>
                <PhoneCard phone={p} onPress={() => router.push(`/product/${p.id}`)} />
                <Pressable
                  onPress={() => confirmRemove(p.id)}
                  style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 8 }, pressed && { opacity: 0.6 }]}
                >
                  <IconSymbol name="trash.fill" size={16} color={colors.error} />
                  <Text style={{ color: colors.error, fontSize: 13, fontWeight: "600" }}>매물 삭제</Text>
                </Pressable>
              </View>
            ))}
          </View>
        )}
        {/* 하단 링크 */}
        <View style={{ flexDirection: "row", justifyContent: "center", gap: 16, paddingVertical: 16, marginTop: 12 }}>
          <Pressable
            onPress={() => router.push("/terms")}
            style={({ pressed }) => [pressed && { opacity: 0.6 }]}
          >
            <Text style={{ color: colors.muted, fontSize: 12, textDecorationLine: "underline" }}>이용약관</Text>
          </Pressable>
          <Text style={{ color: colors.border, fontSize: 12 }}>|</Text>
          <Pressable
            onPress={() => router.push("/privacy")}
            style={({ pressed }) => [pressed && { opacity: 0.6 }]}
          >
            <Text style={{ color: colors.muted, fontSize: 12, textDecorationLine: "underline" }}>개인정보처리방침</Text>
          </Pressable>
          <Text style={{ color: colors.border, fontSize: 12 }}>|</Text>
          <Pressable
            onPress={() => router.push("/trade-terms")}
            style={({ pressed }) => [pressed && { opacity: 0.6 }]}
          >
            <Text style={{ color: colors.muted, fontSize: 12, textDecorationLine: "underline" }}>안전거래 약관</Text>
          </Pressable>
        </View>
        {/* 회원 탈퇴 */}
        {user && (
          <Pressable onPress={() => router.push("/delete-account")} style={{ alignItems: "center", paddingVertical: 8 }}>
            <Text style={{ color: "#EF4444", fontSize: 12 }}>회원 탈퇴</Text>
          </Pressable>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  const colors = useColors();
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: colors.surface,
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: colors.border,
        gap: 4,
      }}
    >
      <Text style={{ color: colors.primary, fontSize: 26, fontWeight: "900" }}>{value}</Text>
      <Text style={{ color: colors.muted, fontSize: 13 }}>{label}</Text>
    </View>
  );
}

function SegTab({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          flex: 1,
          paddingVertical: 10,
          borderRadius: 9,
          backgroundColor: active ? colors.background : "transparent",
          alignItems: "center",
        },
        pressed && { opacity: 0.7 },
      ]}
    >
      <Text style={{ color: active ? colors.foreground : colors.muted, fontWeight: "700", fontSize: 14 }}>
        {label}
      </Text>
    </Pressable>
  );
}

function EmptyState({
  icon,
  text,
  actionLabel,
  onAction,
}: {
  icon: "doc.text.fill" | "heart";
  text: string;
  actionLabel: string;
  onAction: () => void;
}) {
  const colors = useColors();
  return (
    <View style={{ alignItems: "center", paddingVertical: 40, gap: 12 }}>
      <IconSymbol name={icon} size={48} color={colors.muted} />
      <Text style={{ color: colors.muted, fontSize: 15 }}>{text}</Text>
      <Pressable
        onPress={onAction}
        style={({ pressed }) => [
          {
            backgroundColor: colors.primary,
            borderRadius: 12,
            paddingHorizontal: 20,
            paddingVertical: 12,
          },
          pressed && { opacity: 0.85 },
        ]}
      >
        <Text style={{ color: colors.background, fontWeight: "700" }}>{actionLabel}</Text>
      </Pressable>
    </View>
  );
}
