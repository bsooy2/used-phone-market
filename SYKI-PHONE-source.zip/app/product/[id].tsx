import * as Haptics from "expo-haptics";
import * as Linking from "expo-linking";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useRef } from "react";
import { Alert, Platform, Pressable, ScrollView, Text, View } from "react-native";

import { GradeBadge } from "@/components/phone-ui";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { GRADE_INFO, formatPrice } from "@/constants/phones";
import { STORE_INFO } from "@/constants/store-info";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useAuthStore } from "@/lib/auth-store";
import { makeStoreTelUrl } from "@/lib/store-contact";

export default function ProductDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { isFavorite, toggleFavorite, getPhoneById, recordListingView, recordListingFavorite } = useAppStore();
  const { user } = useAuthStore();

  const phone = getPhoneById(id);
  const recordedViewId = useRef<string | null>(null);

  useEffect(() => {
    if (!phone || recordedViewId.current === phone.id) return;
    recordedViewId.current = phone.id;
    recordListingView(phone.id);
  }, [phone?.id, recordListingView]);

  if (!phone) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text style={{ color: colors.muted }}>상품을 찾을 수 없습니다.</Text>
      </ScreenContainer>
    );
  }

  const fav = isFavorite(phone.id);
  const gradeInfo = GRADE_INFO[phone.grade];

  function onToggleFav() {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    toggleFavorite(phone!.id);
    recordListingFavorite(phone!.id, !fav);
  }

  function onBuy() {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    if (!user) {
      Alert.alert("로그인 필요", "구매(결제)는 로그인 후 이용할 수 있습니다.", [
        { text: "취소", style: "cancel" },
        { text: "로그인", onPress: () => router.push("/auth") },
      ]);
      return;
    }
    if (user.role !== "buyer") {
      Alert.alert("안내", "구매(결제)는 구매자 회원만 이용할 수 있습니다.", [{ text: "확인" }]);
      return;
    }
    router.push(`/checkout/${phone!.id}`);
  }

  function onInquiry() {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    Alert.alert(
      "전화로 구매 문의하기",
      `${phone!.model} (${phone!.storage}) 상품을 문의하시겠어요?\n시끼폰 ${STORE_INFO.phone}으로 연결합니다.`,
      [
        { text: "취소", style: "cancel" },
        {
          text: "전화하기",
          onPress: async () => {
            try {
              await Linking.openURL(makeStoreTelUrl(STORE_INFO.phone));
            } catch {
              Alert.alert("전화 연결 실패", `전화 앱을 열 수 없습니다.\n${STORE_INFO.phone}으로 직접 연락해 주세요.`);
            }
          },
        },
      ],
    );
  }

  function onSellThisModel() {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push("/(tabs)/sell");
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />

      {/* 커스텀 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 8,
        }}
      >
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}
        >
          <IconSymbol name="chevron.right" size={26} color={colors.foreground} style={{ transform: [{ rotate: "180deg" }] }} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>상품 상세</Text>
        <Pressable
          onPress={onToggleFav}
          style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}
        >
          <IconSymbol
            name={fav ? "heart.fill" : "heart"}
            size={24}
            color={fav ? colors.error : colors.foreground}
          />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
        {/* 대표 이미지 */}
        <View
          style={{
            height: 280,
            backgroundColor: phone.image,
            alignItems: "center",
            justifyContent: "center",
            marginHorizontal: 16,
            borderRadius: 20,
          }}
        >
          <IconSymbol name="phone.fill" size={120} color="#FFFFFF" />
        </View>

        <View style={{ padding: 20, gap: 20 }}>
          {/* 기본 정보 */}
          <View style={{ gap: 8 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <GradeBadge grade={phone.grade} />
              <Text style={{ color: colors.muted, fontSize: 14 }}>{phone.brand}</Text>
            </View>
            <Text style={{ color: colors.foreground, fontSize: 24, fontWeight: "800" }}>
              {phone.model}
            </Text>
            <Text style={{ color: colors.muted, fontSize: 15 }}>
              {phone.storage} · {phone.color}
            </Text>
            <Text style={{ color: colors.primary, fontSize: 28, fontWeight: "900", marginTop: 4 }}>
              {formatPrice(phone.price)}
            </Text>
            <Pressable
              onPress={onSellThisModel}
              style={({ pressed }) => [{ marginTop: 8, alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10, backgroundColor: colors.primary }, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
            >
              <IconSymbol name="tag.fill" size={16} color={colors.background} />
              <Text style={{ color: colors.background, fontSize: 13, fontWeight: "800" }}>이 가격에 팔기 · 견적 신청</Text>
              <IconSymbol name="arrow.right" size={15} color={colors.background} />
            </Pressable>
          </View>

          {/* 스펙 테이블 */}
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.border,
              gap: 12,
            }}
          >
            <SpecRow label="상태 등급" value={`${gradeInfo.label} · ${gradeInfo.description}`} />
            <SpecRow label="배터리 효율" value={`${phone.battery}%`} />
            <SpecRow label="용량" value={phone.storage} />
            <SpecRow label="색상" value={phone.color} />
            <SpecRow label="구성품" value={phone.accessories} />
            <SpecRow label="등록일" value={phone.createdAt} />
            {phone.sellerName ? <SpecRow label="판매자" value={phone.sellerName} /> : null}
          </View>

          {/* 설명 */}
          <View style={{ gap: 8 }}>
            <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "700" }}>상품 설명</Text>
            <Text style={{ color: colors.muted, fontSize: 15, lineHeight: 22 }}>
              {phone.description}
            </Text>
          </View>

          {/* 안심거래 안내 */}
          <View
            style={{
              flexDirection: "row",
              gap: 10,
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 14,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <IconSymbol name="checkmark.circle.fill" size={22} color={colors.success} />
            <Text style={{ color: colors.muted, fontSize: 13, flex: 1, lineHeight: 19 }}>
              모든 매물은 전문가 검수를 거친 상품입니다. 수령 후 이상이 있을 경우 환불이 가능합니다.
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* 하단 고정 버튼 */}
      <View
        style={{
          flexDirection: "row",
          gap: 12,
          padding: 16,
          paddingBottom: 24,
          borderTopWidth: 0.5,
          borderTopColor: colors.border,
          backgroundColor: colors.background,
        }}
      >
        <Pressable
          onPress={onToggleFav}
          style={({ pressed }) => [
            {
              width: 56,
              borderRadius: 14,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.border,
              backgroundColor: colors.surface,
            },
            pressed && { opacity: 0.7 },
          ]}
        >
          <IconSymbol
            name={fav ? "heart.fill" : "heart"}
            size={26}
            color={fav ? colors.error : colors.muted}
          />
        </Pressable>
        <Pressable
          onPress={onInquiry}
          style={({ pressed }) => [
            {
              flex: 1,
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.primary,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
            },
            pressed && { opacity: 0.8 },
          ]}
        >
          <Text style={{ color: colors.primary, fontWeight: "800", fontSize: 16 }}>문의하기</Text>
        </Pressable>
        <Pressable
          onPress={onBuy}
          style={({ pressed }) => [
            {
              flex: 1.4,
              backgroundColor: colors.primary,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
            },
            pressed && { transform: [{ scale: 0.98 }], opacity: 0.9 },
          ]}
        >
          <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>바로 구매</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

function SpecRow({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 12 }}>
      <Text style={{ color: colors.muted, fontSize: 14 }}>{label}</Text>
      <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "600", flex: 1, textAlign: "right" }}>
        {value}
      </Text>
    </View>
  );
}
