import * as Haptics from "expo-haptics";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { formatPrice } from "@/constants/phones";
import { Order } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { useAuthStore } from "@/lib/auth-store";
import { usePointStore } from "@/lib/point-store";
import { calculatePurchasePoints, isValidPointRedemption, maxRedeemablePoints } from "@/lib/point-rules";
import {
  PAYMENT_METHODS,
  PaymentMethod,
  PaymentResult,
  formatKRW,
  generateOrderId,
  isLiveMode,
  requestPayment,
} from "@/lib/payment";

const METHOD_ICON: Record<PaymentMethod, any> = {
  card: "creditcard.fill",
  transfer: "building.columns.fill",
  kakaopay: "wonsign.circle.fill",
  naverpay: "wonsign.circle.fill",
};

const SHIPPING_FEE = 3000;

export default function CheckoutScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getPhoneById, addOrder, pushNotification } = useAppStore();
  const { user } = useAuthStore();
  const { balance, earnPoints, usePoints } = usePointStore();

  const phone = getPhoneById(id);
  const [method, setMethod] = useState<PaymentMethod>("card");
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<PaymentResult | null>(null);
  const [pointInput, setPointInput] = useState("");
  const [appliedPoints, setAppliedPoints] = useState(0);

  const productPayment = useMemo(() => Math.max(0, (phone?.price ?? 0) - appliedPoints), [appliedPoints, phone?.price]);
  const total = useMemo(() => productPayment + SHIPPING_FEE, [productPayment]);
  const expectedPoints = useMemo(() => calculatePurchasePoints(productPayment), [productPayment]);

  if (!phone) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text style={{ color: colors.muted }}>상품을 찾을 수 없습니다.</Text>
      </ScreenContainer>
    );
  }

  const buyerProfile = user?.buyerProfile;

  function applyPoints() {
    const requested = Number(pointInput.replace(/[^0-9]/g, ""));
    if (!phone || !isValidPointRedemption(requested, balance, phone.price)) {
      Alert.alert("포인트 사용 안내", `포인트는 1,000원 단위로 사용할 수 있으며, 최대 ${maxRedeemablePoints(balance, phone?.price ?? 0).toLocaleString()}P까지 가능합니다.`);
      return;
    }
    setAppliedPoints(requested);
  }

  function clearPoints() {
    setAppliedPoints(0);
    setPointInput("");
  }

  async function onPay() {
    if (!user) return;
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setProcessing(true);
    const orderId = generateOrderId();
    const res = await requestPayment({
      orderId,
      productId: phone!.id,
      productName: `${phone!.model} ${phone!.storage}`,
      amount: total,
      method,
      buyerName: buyerProfile?.name ?? user.nickname,
      buyerEmail: buyerProfile?.email ?? "",
    });
    setProcessing(false);

    if (res.status === "success") {
      const order: Order = {
        id: res.orderId,
        productId: phone!.id,
        productName: `${phone!.model} ${phone!.storage}`,
        amount: total,
        method,
        status: "결제완료",
        buyerId: user.id,
        receiptId: res.receiptId,
        createdAt: new Date().toISOString(),
      };
      addOrder(order);
      if (appliedPoints > 0) {
        usePoints(appliedPoints, `${order.productName} 구매 포인트 사용`);
      }
      if (expectedPoints > 0) {
        earnPoints(expectedPoints, `${order.productName} 구매 2% 적립`);
      }
      pushNotification({
        kind: "order",
        title: "주문이 접수되었어요",
        body: `${order.productName} · ${formatKRW(order.amount)} 결제가 완료되었습니다. 주문번호 ${order.id}`,
        userId: user.id,
        refId: order.id,
      });
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } else if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
    setResult(res);
  }

  const liveBadge = isLiveMode(method) ? null : "테스트 모드";

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />

      {/* 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 8,
          gap: 8,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>결제하기</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 24, gap: 20 }}>
        {/* 주문 상품 */}
        <Section title="주문 상품" colors={colors}>
          <View style={{ flexDirection: "row", gap: 12, alignItems: "center" }}>
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 12,
                backgroundColor: phone.image,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <IconSymbol name="phone.fill" size={28} color="#FFFFFF" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 15 }}>{phone.model}</Text>
              <Text style={{ color: colors.muted, fontSize: 13, marginTop: 2 }}>
                {phone.storage} · {phone.color}
              </Text>
            </View>
            <Text style={{ color: colors.foreground, fontWeight: "800" }}>{formatPrice(phone.price)}</Text>
          </View>
        </Section>

        {/* 배송지 / 구매자 정보 */}
        <Section title="받는 사람 정보" colors={colors}>
          {buyerProfile ? (
            <View style={{ gap: 6 }}>
              <InfoLine label="이름" value={buyerProfile.name} colors={colors} />
              <InfoLine label="이메일" value={buyerProfile.email} colors={colors} />
              <InfoLine label="주소" value={buyerProfile.address} colors={colors} />
            </View>
          ) : (
            <Text style={{ color: colors.muted, fontSize: 13 }}>
              구매자 정보가 없습니다. 마이페이지에서 정보를 입력해 주세요.
            </Text>
          )}
        </Section>

        {/* 결제 수단 */}
        <Section title="결제 수단" colors={colors}>
          <View style={{ gap: 10 }}>
            {PAYMENT_METHODS.map((m) => {
              const active = method === m.key;
              return (
                <Pressable
                  key={m.key}
                  onPress={() => setMethod(m.key)}
                  style={({ pressed }) => [
                    {
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 12,
                      padding: 14,
                      borderRadius: 14,
                      borderWidth: 1.5,
                      borderColor: active ? colors.primary : colors.border,
                      backgroundColor: active ? colors.primary + "10" : colors.surface,
                    },
                    pressed && { opacity: 0.85 },
                  ]}
                >
                  <View
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: 10,
                      backgroundColor: m.brandColor,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <IconSymbol name={METHOD_ICON[m.key]} size={22} color={m.key === "kakaopay" ? "#3C1E1E" : "#fff"} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 15 }}>{m.label}</Text>
                    <Text style={{ color: colors.muted, fontSize: 12 }}>{m.description}</Text>
                  </View>
                  <View
                    style={{
                      width: 22,
                      height: 22,
                      borderRadius: 11,
                      borderWidth: 2,
                      borderColor: active ? colors.primary : colors.border,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {active && (
                      <View style={{ width: 11, height: 11, borderRadius: 6, backgroundColor: colors.primary }} />
                    )}
                  </View>
                </Pressable>
              );
            })}
          </View>
          {liveBadge && (
            <View
              style={{
                flexDirection: "row",
                gap: 8,
                alignItems: "center",
                marginTop: 12,
                backgroundColor: colors.warning + "18",
                borderRadius: 10,
                padding: 10,
              }}
            >
              <IconSymbol name="shield.fill" size={16} color={colors.warning} />
              <Text style={{ color: colors.muted, fontSize: 12, flex: 1 }}>
                현재 {liveBadge}입니다. PG사 계약 및 키 연동 후 실제 결제로 전환됩니다.
              </Text>
            </View>
          )}
        </Section>

        {/* 포인트 사용 */}
        <Section title="포인트 사용" colors={colors}>
          <View style={{ gap: 10 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={{ color: colors.muted, fontSize: 13 }}>보유 포인트</Text>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>{balance.toLocaleString()}P</Text>
            </View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>다음 구매부터 1,000원 단위로 사용 가능합니다.</Text>
            {appliedPoints > 0 ? (
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: colors.primary + "12", borderRadius: 10, padding: 12 }}>
                <Text style={{ color: colors.primary, fontWeight: "700" }}>{appliedPoints.toLocaleString()}P 사용 적용됨</Text>
                <Pressable onPress={clearPoints}>
                  <Text style={{ color: colors.muted, fontSize: 13, fontWeight: "700" }}>취소</Text>
                </Pressable>
              </View>
            ) : (
              <View style={{ flexDirection: "row", gap: 8 }}>
                <TextInput
                  value={pointInput}
                  onChangeText={setPointInput}
                  placeholder="사용할 포인트"
                  placeholderTextColor={colors.muted}
                  keyboardType="number-pad"
                  style={{ flex: 1, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 12, color: colors.foreground, fontSize: 14 }}
                />
                <Pressable onPress={applyPoints} style={{ backgroundColor: colors.foreground, paddingHorizontal: 16, borderRadius: 10, justifyContent: "center" }}>
                  <Text style={{ color: colors.background, fontWeight: "700" }}>사용</Text>
                </Pressable>
              </View>
            )}
          </View>
        </Section>

        {/* 결제 금액 */}
        <Section title="결제 금액" colors={colors}>
          <View style={{ gap: 8 }}>
            <InfoLine label="상품 금액" value={formatPrice(phone.price)} colors={colors} />
            <InfoLine label="배송비" value={formatKRW(SHIPPING_FEE)} colors={colors} />
            {appliedPoints > 0 && <InfoLine label="포인트 사용" value={`-${formatKRW(appliedPoints)}`} colors={colors} />}
            <View style={{ height: 0.5, backgroundColor: colors.border, marginVertical: 4 }} />
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 16 }}>총 결제금액</Text>
              <Text style={{ color: colors.primary, fontWeight: "900", fontSize: 18 }}>{formatKRW(total)}</Text>
            </View>
          </View>
        </Section>
      </ScrollView>

      {/* 하단 결제 버튼 */}
      <View
        style={{
          padding: 16,
          paddingBottom: 24,
          borderTopWidth: 0.5,
          borderTopColor: colors.border,
          backgroundColor: colors.background,
        }}
      >
        <Pressable
          onPress={onPay}
          disabled={processing}
          style={({ pressed }) => [
            {
              backgroundColor: colors.primary,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              opacity: processing ? 0.7 : 1,
            },
            pressed && { transform: [{ scale: 0.99 }] },
          ]}
        >
          {processing ? (
            <ActivityIndicator color={colors.background} />
          ) : (
            <View style={{ alignItems: "center", gap: 2 }}>
              <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>{formatKRW(total)} 결제하기</Text>
              <Text style={{ color: colors.background, fontSize: 11, opacity: 0.75 }}>결제 후 {expectedPoints.toLocaleString()}P 적립 예정</Text>
            </View>
          )}
        </Pressable>
      </View>

      {/* 결과 모달 */}
      <Modal visible={!!result} transparent animationType="fade" onRequestClose={() => setResult(null)}>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", padding: 32 }}>
          <View style={{ backgroundColor: colors.background, borderRadius: 20, padding: 24, alignItems: "center" }}>
            {result?.status === "success" ? (
              <>
                <IconSymbol name="checkmark.circle.fill" size={64} color={colors.success} />
                <Text style={{ color: colors.foreground, fontSize: 19, fontWeight: "800", marginTop: 14 }}>
                  결제가 완료되었습니다
                </Text>
                <Text style={{ color: colors.muted, fontSize: 13, marginTop: 8, textAlign: "center" }}>
                  주문번호: {result.orderId}
                  {"\n"}마이페이지에서 주문 내역을 확인할 수 있습니다.
                </Text>
              </>
            ) : (
              <>
                <IconSymbol name="xmark.circle.fill" size={64} color={colors.error} />
                <Text style={{ color: colors.foreground, fontSize: 19, fontWeight: "800", marginTop: 14 }}>
                  결제에 실패했습니다
                </Text>
                <Text style={{ color: colors.muted, fontSize: 13, marginTop: 8, textAlign: "center" }}>
                  {result?.status === "failed" ? result.reason : "결제가 취소되었습니다."}
                </Text>
              </>
            )}
            <Pressable
              onPress={() => {
                const ok = result?.status === "success";
                setResult(null);
                if (ok) {
                  router.dismissAll?.();
                  router.replace("/(tabs)/my");
                }
              }}
              style={({ pressed }) => [
                {
                  marginTop: 22,
                  backgroundColor: colors.primary,
                  borderRadius: 12,
                  paddingVertical: 14,
                  paddingHorizontal: 32,
                  alignSelf: "stretch",
                  alignItems: "center",
                },
                pressed && { opacity: 0.85 },
              ]}
            >
              <Text style={{ color: colors.background, fontWeight: "700", fontSize: 15 }}>
                {result?.status === "success" ? "주문 내역 보기" : "확인"}
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

function Section({ title, children, colors }: { title: string; children: React.ReactNode; colors: ReturnType<typeof useColors> }) {
  return (
    <View>
      <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800", marginBottom: 10 }}>{title}</Text>
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 16,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        {children}
      </View>
    </View>
  );
}

function InfoLine({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 12 }}>
      <Text style={{ color: colors.muted, fontSize: 13 }}>{label}</Text>
      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "600", flex: 1, textAlign: "right" }}>
        {value}
      </Text>
    </View>
  );
}
