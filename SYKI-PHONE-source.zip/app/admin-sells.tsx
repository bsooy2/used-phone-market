import { Stack, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, FlatList, Image, Platform, Pressable, Text, View } from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { formatPrice } from "@/constants/phones";
import { SellRequest } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";

const STATUS_COLOR: Record<SellRequest["status"], string> = {
  접수: "#F59E0B",
  검수중: "#3B82F6",
  입금완료: "#22C55E",
};

const NEXT_STATUS: Record<SellRequest["status"], SellRequest["status"] | null> = {
  접수: "검수중",
  검수중: "입금완료",
  입금완료: null,
};

export default function AdminSellsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { sellRequests, advanceSellStatus, archiveSellRequests, restoreSellRequests, deleteSellRequests } = useAppStore();
  const [showArchive, setShowArchive] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const visibleRequests = useMemo(
    () => sellRequests.filter((request) => (showArchive ? Boolean(request.archivedAt) : !request.archivedAt)),
    [sellRequests, showArchive],
  );
  const allVisibleSelected = visibleRequests.length > 0 && visibleRequests.every((request) => selectedIds.includes(request.id));

  function toggleSelection(id: string) {
    setSelectedIds((current) => (current.includes(id) ? current.filter((selectedId) => selectedId !== id) : [...current, id]));
  }

  function toggleSelectAll() {
    if (allVisibleSelected) {
      setSelectedIds((current) => current.filter((id) => !visibleRequests.some((request) => request.id === id)));
    } else {
      setSelectedIds((current) => Array.from(new Set([...current, ...visibleRequests.map((request) => request.id)])));
    }
  }

  function clearSelectionAndToggleArchive() {
    setSelectedIds([]);
    setShowArchive((current) => !current);
  }

  function handleArchiveSelected() {
    if (selectedIds.length === 0) return;
    const action = showArchive ? "보관 해제" : "보관";
    Alert.alert(`${action} 확인`, `선택한 ${selectedIds.length}건을 ${action}할까요?`, [
      { text: "취소", style: "cancel" },
      {
        text: action,
        onPress: () => {
          if (showArchive) restoreSellRequests(selectedIds);
          else archiveSellRequests(selectedIds);
          setSelectedIds([]);
          if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
      },
    ]);
  }

  function handleDeleteSelected() {
    if (selectedIds.length === 0) return;
    Alert.alert("영구 삭제", `선택한 ${selectedIds.length}건을 완전히 삭제할까요? 관련 알림도 함께 삭제되며 되돌릴 수 없습니다.`, [
      { text: "취소", style: "cancel" },
      {
        text: "삭제",
        style: "destructive",
        onPress: () => {
          deleteSellRequests(selectedIds);
          setSelectedIds([]);
          if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        },
      },
    ]);
  }

  function handleAdvance(req: SellRequest) {
    const next = NEXT_STATUS[req.status];
    if (!next) {
      Alert.alert("완료", "이미 입금완료 상태입니다.");
      return;
    }
    Alert.alert(
      "상태 변경",
      `'${req.model}' 견적을 "${next}" 상태로 변경할까요?\n변경 시 고객에게 알림이 발송됩니다.`,
      [
        { text: "취소", style: "cancel" },
        {
          text: "변경",
          onPress: () => {
            advanceSellStatus(req.id);
            if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ],
    );
  }

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      {/* 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
          borderBottomWidth: 0.5,
          borderBottomColor: colors.border,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>{showArchive ? "견적 신청 보관함" : "견적 신청 관리"}</Text>
        <Pressable onPress={clearSelectionAndToggleArchive} style={({ pressed }) => [{ paddingHorizontal: 8, paddingVertical: 6, borderRadius: 8, backgroundColor: colors.surface }, pressed && { opacity: 0.65 }]}>
          <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "700" }}>{showArchive ? `신청 목록 (${sellRequests.filter((request) => !request.archivedAt).length})` : `보관함 (${sellRequests.filter((request) => request.archivedAt).length})`}</Text>
        </Pressable>
      </View>

      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 0.5, borderBottomColor: colors.border }}>
        <Pressable onPress={toggleSelectAll} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 4 }, pressed && { opacity: 0.65 }]}>
          <SelectionBox checked={allVisibleSelected} colors={colors} />
          <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>{allVisibleSelected ? "전체 해제" : "전체 선택"}</Text>
        </Pressable>
        <Text style={{ color: colors.muted, fontSize: 12, flex: 1 }}>{selectedIds.length > 0 ? `${selectedIds.length}건 선택` : `${visibleRequests.length}건`}</Text>
        <Pressable disabled={selectedIds.length === 0} onPress={handleArchiveSelected} style={({ pressed }) => [{ opacity: selectedIds.length === 0 ? 0.35 : pressed ? 0.6 : 1, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 7, backgroundColor: colors.surface }]}> 
          <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "800" }}>{showArchive ? "보관 해제" : "보관"}</Text>
        </Pressable>
        <Pressable disabled={selectedIds.length === 0} onPress={handleDeleteSelected} style={({ pressed }) => [{ opacity: selectedIds.length === 0 ? 0.35 : pressed ? 0.6 : 1, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 7, backgroundColor: colors.error }]}> 
          <Text style={{ color: colors.background, fontSize: 12, fontWeight: "800" }}>삭제</Text>
        </Pressable>
      </View>

      {visibleRequests.length === 0 ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 12 }}>
          <IconSymbol name="doc.text.fill" size={48} color={colors.muted} />
          <Text style={{ color: colors.muted }}>{showArchive ? "보관된 견적 신청이 없습니다." : "접수된 견적 신청이 없습니다."}</Text>
        </View>
      ) : (
        <FlatList
          data={visibleRequests}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 32 }}
          ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
          renderItem={({ item }) => {
            const next = NEXT_STATUS[item.status];
            const selected = selectedIds.includes(item.id);
            return (
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 14,
                  borderWidth: selected ? 2 : 1,
                  borderColor: selected ? colors.foreground : colors.border,
                  padding: 14,
                  gap: 10,
                }}
              >
                {/* 상단: 모델 + 상태 배지 */}
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: selected }} accessibilityLabel={`${item.model} 견적 신청 선택`} onPress={() => toggleSelection(item.id)} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
                    <SelectionBox checked={selected} colors={colors} />
                  </Pressable>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }} numberOfLines={1}>
                      {item.brand} {item.model}
                    </Text>
                    <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>
                      {item.storage} · {item.gradeLabel ?? "미지정"} · {item.createdAt}
                    </Text>
                  </View>
                  <View
                    style={{
                      backgroundColor: STATUS_COLOR[item.status] + "20",
                      borderRadius: 8,
                      paddingHorizontal: 10,
                      paddingVertical: 4,
                    }}
                  >
                    <Text style={{ color: STATUS_COLOR[item.status], fontSize: 12, fontWeight: "800" }}>
                      {item.status}
                    </Text>
                  </View>
                </View>

                {/* 예상 매입가 */}
                <Text style={{ color: colors.primary, fontSize: 18, fontWeight: "900" }}>
                  {formatPrice(item.estimatedPrice)}
                </Text>

                {/* 상태 옵션 */}
                {item.conditionLabels && item.conditionLabels.length > 0 && (
                  <Text style={{ color: colors.muted, fontSize: 12 }}>
                    상태: {item.conditionLabels.join(", ")}
                  </Text>
                )}

                {/* IMEI */}
                {item.imei && (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Text style={{ color: colors.muted, fontSize: 12, fontWeight: "600" }}>IMEI:</Text>
                    <Text style={{ color: colors.foreground, fontSize: 12, fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace" }}>
                      {item.imei}
                    </Text>
                    {item.imeiDeviceInfo && (
                      <Text style={{ color: colors.primary, fontSize: 11 }}>
                        ({item.imeiDeviceInfo.brand} {item.imeiDeviceInfo.model})
                      </Text>
                    )}
                  </View>
                )}

                {/* 첨부 사진 */}
                {item.images && item.images.length > 0 && (
                  <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
                    {item.images.map((uri, idx) => (
                      <Image
                        key={idx}
                        source={{ uri }}
                        style={{ width: 56, height: 56, borderRadius: 8, backgroundColor: colors.border }}
                      />
                    ))}
                    <Text style={{ color: colors.muted, fontSize: 11, alignSelf: "flex-end" }}>
                      {item.images.length}장 첨부
                    </Text>
                  </View>
                )}

                {/* 동의 내역 */}
                {item.agreements && (
                  <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                      <IconSymbol name="checkmark" size={10} color={colors.success} />
                      <Text style={{ color: colors.muted, fontSize: 11 }}>개인정보</Text>
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                      <IconSymbol name="checkmark" size={10} color={colors.success} />
                      <Text style={{ color: colors.muted, fontSize: 11 }}>안전거래</Text>
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                      <IconSymbol name="checkmark" size={10} color={colors.success} />
                      <Text style={{ color: colors.muted, fontSize: 11 }}>분실폰확인</Text>
                    </View>
                    <Text style={{ color: colors.muted, fontSize: 10 }}>
                      ({item.agreements.agreedAt.slice(0, 10)})
                    </Text>
                  </View>
                )}

                {/* 상태 변경 버튼 */}
                {next ? (
                  <Pressable
                    onPress={() => handleAdvance(item)}
                    style={({ pressed }) => [
                      {
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 6,
                        backgroundColor: STATUS_COLOR[next],
                        borderRadius: 10,
                        paddingVertical: 12,
                      },
                      pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                    ]}
                  >
                    <IconSymbol name="arrow.right" size={16} color="#FFFFFF" />
                    <Text style={{ color: "#FFFFFF", fontWeight: "700", fontSize: 14 }}>
                      "{next}" 상태로 변경
                    </Text>
                  </Pressable>
                ) : (
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 6,
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: STATUS_COLOR["입금완료"],
                      borderRadius: 10,
                      paddingVertical: 12,
                    }}
                  >
                    <IconSymbol name="checkmark.circle.fill" size={16} color={STATUS_COLOR["입금완료"]} />
                    <Text style={{ color: STATUS_COLOR["입금완료"], fontWeight: "700", fontSize: 14 }}>처리 완료</Text>
                  </View>
                )}
              </View>
            );
          }}
        />
      )}
    </ScreenContainer>
  );
}

function SelectionBox({ checked, colors }: { checked: boolean; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={{ width: 22, height: 22, borderRadius: 6, alignItems: "center", justifyContent: "center", borderWidth: 1.5, borderColor: checked ? colors.foreground : colors.border, backgroundColor: checked ? colors.foreground : colors.background }}>
      {checked ? <IconSymbol name="checkmark" size={14} color={colors.background} /> : null}
    </View>
  );
}
