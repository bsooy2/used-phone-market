import { Stack, useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TradeTermsScreen() {
  const colors = useColors();
  const router = useRouter();

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      {/* 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
          borderBottomWidth: 0.5,
          borderBottomColor: colors.border,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>안전거래 약관</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60, gap: 20 }}>
        <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800" }}>
          제품 정보 및 단말기 체크리스트 별지 첨부
        </Text>
        <Text style={{ color: colors.muted, fontSize: 13, lineHeight: 20 }}>
          ※ 매도인 "갑(매도인)"과 매수인 "을(매수인)"은 정당한 합의에 의하여 매매 계약을(매수인) 아래와 같이 하기로 한다.
        </Text>

        <View style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 18, borderWidth: 1, borderColor: colors.border, gap: 16 }}>
          <ArticleSection
            title="제1조 (당사자 표시)"
            content="매도인을 '갑' 이라 하고, 매수인을 '을'이라 한다."
            colors={colors}
          />

          <ArticleSection
            title="제2조 (동시이행 등)"
            content={`"갑(매도인)"은 물품을 매도함과 동시에 소유권 이전등록에 필요한 모든 것들을 "을(매수인)" 에게 제공하여야 한다.`}
            colors={colors}
          />

          <ArticleSection
            title="제3조 (공과금 부담)"
            content={`본 매매 물품에 대한 제시공과금, 미납요금, 연체료, 할부금, 등록비 등이 발생할 경우 전액을 "갑(매도인)"이 '을(매수인)'에게 부담하기로하고, 만약 "갑(매도인)"이 부담하지 않음에 따라 "을(매수인)"이 피해를 입게될 경우 본 계약은 무효로 하며 "갑(매도인)"은 "을(매수인)"에게 매매 금액을 반환한다. 만약 '갑(매도인)'이 이를 수행하지 않을 때 에는 계약위반으로 법적인 책임을받을 수 있다. (민형사상 신고, 소송 등)`}
            colors={colors}
          />

          <ArticleSection
            title="제4조 (사고 책임)"
            content={`"을(매수인)"이 물품을 인수한 이후 "갑(매도인)"의 과실로 인하여 발생하는 모든 사고에 대하여 "갑(매도인)"은 모든 책임을 진다.`}
            colors={colors}
          />

          <ArticleSection
            title="제5조 (하자 책임)"
            content={`매매한 물품이 법률적으로 문제가 있는 물품일 경우 "갑(매도인)"은 매매에 따른 일체의 법률적 책임을져야 하며, "을(매수인)" 에게 피해가 발생하지 않도록 하여야 한다. 중고 제품은 유심기변, 확정기변 제품이어야 하고 개통 신품은 유심기변이 가능한 제품이어야 한다. 또한 유심기변 물품일 경우 차후에 발생되는 연체, 미납할부금, 분실도난에 대한 모든책임을 진다. 이를 위하여 "을(매수인)"은 "갑(매도인)"의 신분 확인을 요구할 수 있고 "갑(매도인)"은 이에 따른다.`}
            colors={colors}
          />
        </View>

        <View style={{ backgroundColor: "#FEF2F2", borderRadius: 14, padding: 18, borderWidth: 1, borderColor: "#FECACA", gap: 8 }}>
          <Text style={{ color: "#DC2626", fontSize: 14, fontWeight: "700" }}>중요 고지사항</Text>
          <Text style={{ color: "#991B1B", fontSize: 13, lineHeight: 20 }}>
            또한, '갑(매도인)'의 사유로 인하여 '을(매수인)'이 해당 매입한 중고폰을 재판매 했을 시 피해가 발생한 경우 '갑(매도인)'은 매매금액 이외의 매매금액의 50% 피해보상금을 '을(매수인)'에게 추가로 지급해야 한다.
          </Text>
        </View>

        <View style={{ borderTopWidth: 0.5, borderTopColor: colors.border, paddingTop: 16 }}>
          <Text style={{ color: colors.muted, fontSize: 12, textAlign: "center" }}>
            SYKI PHONE (시끼폰) | 010-2394-1420
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function ArticleSection({
  title,
  content,
  colors,
}: {
  title: string;
  content: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 6 }}>
      <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "700" }}>{title}</Text>
      <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20 }}>{content}</Text>
    </View>
  );
}
