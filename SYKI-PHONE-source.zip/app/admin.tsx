import { router } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { formatPrice } from "@/constants/phones";
import { useColors } from "@/hooks/use-colors";
import { useAdminStore } from "@/lib/admin-store";
import { trpc } from "@/lib/trpc";

const GRADE_LABEL: Record<string, string> = { S: "S급", A: "A급", B: "B급", C: "C급" };

export default function AdminScreen() {
  const colors = useColors();
  const { isAdmin, pin, enableAdmin, disableAdmin, loaded } = useAdminStore();

  if (!loaded) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} className="items-center justify-center">
        <ActivityIndicator color={colors.foreground} />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Header
        title="매물 관리 (사장님)"
        right={
          isAdmin ? (
            <TouchableOpacity
              hitSlop={10}
              onPress={() => {
                Alert.alert("관리자 모드 종료", "관리자 모드를 종료할까요?", [
                  { text: "취소", style: "cancel" },
                  { text: "종료", style: "destructive", onPress: () => disableAdmin() },
                ]);
              }}
            >
              <Text style={{ color: colors.muted, fontWeight: "600" }}>종료</Text>
            </TouchableOpacity>
          ) : undefined
        }
      />
      {isAdmin ? (
        <>
          {/* 견적 관리 바로가기 */}
          <View style={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4, gap: 8 }}>
            <TouchableOpacity
              onPress={() => router.push("/admin-sells")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
              }}
            >
              <IconSymbol name="doc.text.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>견적 신청 관리</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-settings")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
              }}
            >
             <IconSymbol name="gearshape.fill" size={20} color={colors.primary} />
             <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>관리자 설정</Text>
             <IconSymbol name="chevron.right" size={18} color={colors.muted} />
           </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-content")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
              }}
            >
              <IconSymbol name="doc.text.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>공지사항 · 이벤트 관리</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-broadcast")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
              }}
            >
              <IconSymbol name="bell.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>일괄 알림 발송</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-dashboard")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 12,
              }}
            >
              <IconSymbol name="chart.bar.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>대시보드</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-sms")}
              activeOpacity={0.85}
              style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12 }}
            >
              <IconSymbol name="bell.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>인증 문자 발송 이력</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-reviews")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.surface,
                borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12,
              }}
            >
              <IconSymbol name="doc.text.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>고객 후기 관리</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/admin-inquiries")}
              activeOpacity={0.85}
              style={{
                flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.surface,
                borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12,
              }}
            >
              <IconSymbol name="message.fill" size={20} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>거래 문의 관리</Text>
              <IconSymbol name="chevron.right" size={18} color={colors.muted} />
            </TouchableOpacity>
          </View>
          <AdminListings pin={pin!} />
        </>
      ) : (
        <PinGate onSuccess={enableAdmin} />
      )}
    </ScreenContainer>
  );
}

function PinGate({ onSuccess }: { onSuccess: (pin: string) => Promise<void> }) {
  const colors = useColors();
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);
  const verify = trpc.listings.verifyPin.useMutation();

  const submit = async () => {
    if (value.length < 4) {
      Alert.alert("PIN 확인", "PIN을 입력해 주세요.");
      return;
    }
    setLoading(true);
    try {
      const res = await verify.mutateAsync({ pin: value });
      if (res.ok) {
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        await onSuccess(value);
      } else {
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        Alert.alert("인증 실패", "PIN이 올바르지 않습니다.");
      }
    } catch {
      Alert.alert("오류", "서버 연결에 실패했습니다. 잠시 후 다시 시도해 주세요.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View className="flex-1 items-center justify-center px-8">
      <View
        style={{
          width: 72,
          height: 72,
          borderRadius: 20,
          backgroundColor: colors.surface,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 20,
        }}
      >
        <IconSymbol name="lock.fill" size={34} color={colors.foreground} />
      </View>
      <Text className="text-xl font-bold text-foreground">관리자 모드</Text>
      <Text className="text-sm text-muted mt-2 text-center">
        사장님 전용 매물 관리 화면입니다.{"\n"}관리자 PIN을 입력해 주세요.
      </Text>
      <TextInput
        value={value}
        onChangeText={(t) => setValue(t.replace(/[^0-9]/g, ""))}
        placeholder="PIN 입력"
        placeholderTextColor={colors.muted}
        keyboardType="number-pad"
        secureTextEntry
        returnKeyType="done"
        onSubmitEditing={submit}
        maxLength={10}
        style={{
          marginTop: 28,
          width: "100%",
          backgroundColor: colors.surface,
          borderWidth: 1,
          borderColor: colors.border,
          borderRadius: 14,
          paddingHorizontal: 18,
          paddingVertical: 16,
          fontSize: 18,
          letterSpacing: 6,
          textAlign: "center",
          color: colors.foreground,
        }}
      />
      <TouchableOpacity
        onPress={submit}
        disabled={loading}
        activeOpacity={0.85}
        style={{
          marginTop: 18,
          width: "100%",
          backgroundColor: colors.primary,
          borderRadius: 14,
          paddingVertical: 16,
          alignItems: "center",
          opacity: loading ? 0.7 : 1,
        }}
      >
        {loading ? (
          <ActivityIndicator color={colors.background} />
        ) : (
          <Text style={{ color: colors.background, fontWeight: "700", fontSize: 16 }}>관리자 모드 진입</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

function AdminListings({ pin }: { pin: string }) {
  const colors = useColors();
  const utils = trpc.useUtils();
  const { disableAdmin } = useAdminStore();
  const listQuery = trpc.listings.list.useQuery();
  const deleteMutation = trpc.listings.delete.useMutation({
    onSuccess: () => {
      utils.listings.list.invalidate();
    },
  });

  const handleDelete = (id: number, model: string) => {
    Alert.alert("매물 삭제", `'${model}' 매물을 삭제할까요?`, [
      { text: "취소", style: "cancel" },
      {
        text: "삭제",
        style: "destructive",
        onPress: async () => {
          try {
            await deleteMutation.mutateAsync({ pin, id });
            if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          } catch (err: any) {
            const msg = err?.message ?? "";
            if (msg.includes("PIN") || msg.includes("FORBIDDEN")) {
              Alert.alert(
                "PIN 인증 실패",
                "저장된 PIN이 서버와 일치하지 않습니다.\n관리자 모드를 종료하고 다시 로그인해 주세요.",
                [
                  { text: "닫기", style: "cancel" },
                  { text: "모드 종료", style: "destructive", onPress: () => disableAdmin() },
                ],
              );
            } else {
              Alert.alert("오류", "삭제에 실패했습니다. 잠시 후 다시 시도해 주세요.");
            }
          }
        },
      },
    ]);
  };

  if (listQuery.isLoading) {
    return (
      <View className="flex-1 items-center justify-center">
        <ActivityIndicator color={colors.foreground} />
      </View>
    );
  }

  const data = listQuery.data ?? [];

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={data}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: 110 }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={
          <View className="items-center mt-20">
            <Text className="text-muted">등록된 매물이 없습니다.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: colors.surface,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: colors.border,
              padding: 12,
            }}
          >
            <View style={{ width: 48, height: 48, borderRadius: 10, backgroundColor: item.image, marginRight: 12 }} />
            <View style={{ flex: 1 }}>
              <Text className="text-foreground font-bold" numberOfLines={1}>
                {item.model}
              </Text>
              <Text className="text-muted text-xs mt-0.5" numberOfLines={1}>
                {item.storage} · {item.color} · {GRADE_LABEL[item.grade]}
                {item.sold ? " · 판매완료" : ""}
              </Text>
              <Text className="text-foreground font-semibold mt-1">{formatPrice(item.price)}</Text>
            </View>
            <View style={{ gap: 8 }}>
              <TouchableOpacity
                onPress={() => router.push({ pathname: "/admin-edit", params: { id: String(item.id) } })}
                style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 9, backgroundColor: colors.primary }}
                activeOpacity={0.85}
              >
                <Text style={{ color: colors.background, fontWeight: "700", fontSize: 13 }}>수정</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handleDelete(item.id, item.model)}
                style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 9, borderWidth: 1, borderColor: colors.border }}
                activeOpacity={0.7}
              >
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 13 }}>삭제</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      {/* 신규 등록 FAB */}
      <TouchableOpacity
        onPress={() => router.push({ pathname: "/admin-edit", params: {} })}
        activeOpacity={0.88}
        style={{
          position: "absolute",
          right: 20,
          bottom: 28,
          flexDirection: "row",
          alignItems: "center",
          gap: 6,
          backgroundColor: colors.primary,
          paddingHorizontal: 20,
          paddingVertical: 15,
          borderRadius: 30,
          shadowColor: "#000",
          shadowOpacity: 0.2,
          shadowRadius: 8,
          shadowOffset: { width: 0, height: 3 },
          elevation: 4,
        }}
      >
        <IconSymbol name="plus" size={20} color={colors.background} />
        <Text style={{ color: colors.background, fontWeight: "700" }}>매물 등록</Text>
      </TouchableOpacity>
    </View>
  );
}

function Header({ title, right }: { title: string; right?: React.ReactNode }) {
  const colors = useColors();
  return (
    <View className="flex-row items-center justify-between px-5 py-3 border-b border-border">
      <TouchableOpacity onPress={() => router.back()} hitSlop={10} style={{ opacity: 0.7, width: 40 }}>
        <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
      </TouchableOpacity>
      <Text className="text-base font-bold text-foreground">{title}</Text>
      <View style={{ width: 40, alignItems: "flex-end" }}>{right}</View>
    </View>
  );
}
