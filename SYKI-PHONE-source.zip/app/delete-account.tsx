import { useState } from "react";
import { Text, TextInput, View, Pressable, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";

export default function DeleteAccountScreen() {
  const colors = useColors();
  const router = useRouter();
  const { deleteAccount, deleteScheduledAt, cancelDeleteAccount } = useAuthStore();
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleDelete = () => {
    Alert.alert(
      "회원 탈퇴 예약",
      "탈퇴를 예약하시겠습니까?\n7일 후 계정이 영구 삭제됩니다.\n7일 이내에 취소할 수 있습니다.",
      [
        { text: "취소", style: "cancel" },
        {
          text: "탈퇴 예약",
          style: "destructive",
          onPress: async () => {
            setLoading(true);
            const res = await deleteAccount(password);
            setLoading(false);
            if (res.ok) {
              Alert.alert("예약 완료", `7일 후(${new Date(res.scheduledAt!).toLocaleDateString("ko-KR")}) 계정이 삭제됩니다.\n취소하려면 마이페이지에서 가능합니다.`, [{ text: "확인", onPress: () => router.back() }]);
            } else {
              Alert.alert("오류", res.error ?? "탈퇴에 실패했습니다.");
            }
          },
        },
      ],
    );
  };

  const handleCancel = async () => {
    const res = await cancelDeleteAccount();
    if (res.ok) Alert.alert("취소 완료", "탈퇴 예약이 취소되었습니다.", [{ text: "확인", onPress: () => router.back() }]);
    else Alert.alert("오류", res.error ?? "취소에 실패했습니다.");
  };

  return (
    <ScreenContainer className="p-6">
      <View style={{ gap: 16, flex: 1, justifyContent: "center" }}>
        <Text style={{ color: "#EF4444", fontSize: 20, fontWeight: "800", textAlign: "center" }}>회원 탈퇴{deleteScheduledAt ? " (예약됨)" : ""}</Text>
        {deleteScheduledAt ? (
          <>
            <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center", lineHeight: 20 }}>
              탈퇴가 예약되었습니다.{"\n"}{new Date(deleteScheduledAt).toLocaleDateString("ko-KR")}에 계정이 삭제됩니다.{"\n"}지금 취소하면 계속 이용할 수 있습니다.
            </Text>
            <Pressable onPress={handleCancel} style={{ backgroundColor: colors.foreground, paddingVertical: 14, borderRadius: 12, alignItems: "center" }}>
              <Text style={{ color: colors.background, fontWeight: "800", fontSize: 15 }}>탈퇴 취소하기</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Text style={{ color: colors.muted, fontSize: 14, textAlign: "center", lineHeight: 20 }}>
              탈퇴 예약 후 7일간 유예됩니다.{"\n"}7일 이내에 취소할 수 있으며,{"\n"}이후 모든 데이터가 영구 삭제됩니다.
            </Text>
            <TextInput value={password} onChangeText={setPassword} placeholder="비밀번호 입력" placeholderTextColor={colors.muted} secureTextEntry style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 15, color: colors.foreground }} />
            <Pressable onPress={handleDelete} disabled={loading || !password} style={{ backgroundColor: "#EF4444", paddingVertical: 14, borderRadius: 12, alignItems: "center", opacity: loading || !password ? 0.5 : 1 }}>
              <Text style={{ color: "#ffffff", fontWeight: "800", fontSize: 15 }}>탈퇴 예약하기</Text>
            </Pressable>
          </>
        )}
        <Pressable onPress={() => router.back()} style={{ alignItems: "center", paddingVertical: 10 }}>
          <Text style={{ color: colors.muted, fontSize: 14 }}>취소</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
