import { useEffect, useMemo, useState } from "react";
import { Text, View, ScrollView, Pressable, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore, Account } from "@/lib/auth-store";
import { useAppStore } from "@/lib/app-store";
import { toCSV, exportCSV } from "@/lib/csv-export";
import { getListingAnalyticsSummary, rankListingPopularity } from "@/lib/listing-analytics";
import { getReviewAnalyticsSummary } from "@/lib/review-analytics";
import { useReviewStore } from "@/lib/review-store";
import { getBannerClickSummary, getBannerPeriodChannelComparison } from "@/lib/banner-analytics";
import { useContentStore } from "@/lib/content-store";
import { useAdminStore } from "@/lib/admin-store";

export default function AdminDashboardScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAdmin } = useAdminStore();
  const { getAllAccounts } = useAuthStore();
  const { sellRequests, allPhones, orders } = useAppStore();
  const { reviews } = useReviewStore();
  const { banners } = useContentStore();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [bannerPeriod, setBannerPeriod] = useState<7 | 30 | 90>(30);

  useEffect(() => {
    getAllAccounts().then(setAccounts);
  }, []);

  const totalMembers = accounts.length;
  const buyers = accounts.filter((a) => a.role === "buyer").length;
  const sellers = accounts.filter((a) => a.role === "seller").length;

  // 최근 7일 가입자
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const recentSignups = accounts.filter((a) => a.createdAt >= sevenDaysAgo).length;

  // 견적 신청 통계
  const totalRequests = sellRequests.length;
  const pendingRequests = sellRequests.filter((r) => r.status === "접수").length;
  const inspectingRequests = sellRequests.filter((r) => r.status === "검수중").length;
  const completedRequests = sellRequests.filter((r) => r.status === "입금완료").length;

  // 최근 7일 견적 신청
  const recentRequests = sellRequests.filter((r) => r.createdAt >= sevenDaysAgo).length;

  // 일별 견적 신청 추이 (최근 30일)
  const dailyData = useMemo(() => {
    const days: { label: string; count: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
      const dateStr = d.toISOString().slice(0, 10);
      const label = `${d.getMonth() + 1}/${d.getDate()}`;
      const count = sellRequests.filter((r) => r.createdAt.slice(0, 10) === dateStr).length;
      days.push({ label, count });
    }
    return days;
  }, [sellRequests]);

  const maxCount = Math.max(...dailyData.map((d) => d.count), 1);

  // 매출 통계 (입금완료 건의 예상 매입가 합산)
  const totalRevenue = useMemo(() => {
    return sellRequests
      .filter((r) => r.status === "입금완료")
      .reduce((sum, r) => sum + (r.estimatedPrice ?? 0), 0);
  }, [sellRequests]);

  const monthlyRevenue = useMemo(() => {
    const thisMonth = new Date().toISOString().slice(0, 7);
    return sellRequests
      .filter((r) => r.status === "입금완료" && r.createdAt.slice(0, 7) === thisMonth)
      .reduce((sum, r) => sum + (r.estimatedPrice ?? 0), 0);
  }, [sellRequests]);

  const popularListings = useMemo(() => rankListingPopularity(allPhones), [allPhones]);
  const listingAnalytics = useMemo(() => getListingAnalyticsSummary(popularListings), [popularListings]);
  const reviewAnalytics = useMemo(() => {
    const eligibleTransactions = orders.filter((order) => order.status === "배송완료").length + sellRequests.filter((request) => request.status === "입금완료").length;
    return getReviewAnalyticsSummary(reviews, eligibleTransactions);
  }, [orders, reviews, sellRequests]);
  const bannerAnalytics = useMemo(() => getBannerClickSummary(banners), [banners]);
  const bannerComparison = useMemo(() => getBannerPeriodChannelComparison(banners, bannerPeriod), [banners, bannerPeriod]);
  const bannerChartMax = Math.max(...bannerComparison.map((banner) => Math.max(banner.taps, banner.conversions)), 1);

  if (!isAdmin) {
    return <ScreenContainer className="items-center justify-center p-6"><Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "800" }}>관리자 전용 화면입니다.</Text><Text style={{ color: colors.muted, marginTop: 6 }}>관리자 PIN 인증 후 통계를 확인할 수 있습니다.</Text><Pressable onPress={() => router.replace("/admin")} style={{ marginTop: 16, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10, backgroundColor: colors.foreground }}><Text style={{ color: colors.background, fontWeight: "800" }}>관리자 인증하기</Text></Pressable></ScreenContainer>;
  }

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ gap: 20, paddingBottom: 40 }}>
        <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: "900" }}>관리자 대시보드</Text>

        {/* CSV 내보내기 */}
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable
            onPress={async () => {
              const headers = ["이름", "연락처", "역할", "가입일"];
              const rows = accounts.map((a) => [a.nickname, a.phone, a.role === "seller" ? "판매자" : "구매자", new Date(a.createdAt).toLocaleDateString("ko-KR")]);
              const csv = toCSV(headers, rows);
              await exportCSV(`회원목록_${new Date().toISOString().slice(0, 10)}.csv`, csv);
            }}
            style={{ flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingVertical: 10, alignItems: "center" }}
          >
            <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>회원 CSV</Text>
          </Pressable>
          <Pressable
            onPress={async () => {
              const headers = ["브랜드", "모델", "용량", "등급", "예상매입가", "상태", "신청일"];
              const rows = sellRequests.map((r) => [r.brand, r.model, r.storage, r.gradeLabel, String(r.estimatedPrice ?? 0), r.status, new Date(r.createdAt).toLocaleDateString("ko-KR")]);
              const safeRows = rows.map((row) => row.map((v) => v ?? ""));
              const csv = toCSV(headers, safeRows);
              await exportCSV(`견적신청_${new Date().toISOString().slice(0, 10)}.csv`, csv);
            }}
            style={{ flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingVertical: 10, alignItems: "center" }}
          >
            <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>견적 CSV</Text>
          </Pressable>
        </View>

        {/* 회원 통계 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>회원 현황</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            <StatBox label="전체 회원" value={totalMembers} color={colors.foreground} />
            <StatBox label="구매자" value={buyers} color="#4B4B4B" />
            <StatBox label="판매자" value={sellers} color={colors.primary} />
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#22C55E" }} />
            <Text style={{ color: colors.muted, fontSize: 13 }}>최근 7일 신규 가입: <Text style={{ fontWeight: "700", color: colors.foreground }}>{recentSignups}명</Text></Text>
          </View>
        </View>

        {/* 견적 신청 통계 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>견적 신청 현황</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            <StatBox label="전체" value={totalRequests} color={colors.foreground} />
            <StatBox label="접수" value={pendingRequests} color="#9A9A9A" />
            <StatBox label="검수중" value={inspectingRequests} color="#4B4B4B" />
            <StatBox label="입금완료" value={completedRequests} color="#22C55E" />
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#F59E0B" }} />
            <Text style={{ color: colors.muted, fontSize: 13 }}>최근 7일 신청: <Text style={{ fontWeight: "700", color: colors.foreground }}>{recentRequests}건</Text></Text>
          </View>
        </View>

        {/* 일별 견적 신청 추이 그래프 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>일별 견적 신청 추이 (30일)</Text>
          <View style={{ height: 120, flexDirection: "row", alignItems: "flex-end", gap: 2 }}>
            {dailyData.map((d, i) => (
              <View key={i} style={{ flex: 1, alignItems: "center", justifyContent: "flex-end", height: "100%" }}>
                <View style={{ width: "80%", height: `${(d.count / maxCount) * 100}%`, backgroundColor: d.count > 0 ? colors.foreground : colors.border, borderRadius: 2, minHeight: 2 }} />
              </View>
            ))}
          </View>
          <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
            <Text style={{ color: colors.muted, fontSize: 10 }}>{dailyData[0]?.label}</Text>
            <Text style={{ color: colors.muted, fontSize: 10 }}>{dailyData[14]?.label}</Text>
            <Text style={{ color: colors.muted, fontSize: 10 }}>{dailyData[29]?.label}</Text>
          </View>
        </View>

        {/* 매출 통계 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>매출 통계 (입금완료 기준)</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            <View style={{ flex: 1, alignItems: "center", gap: 4 }}>
              <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "900" }}>{(monthlyRevenue / 10000).toFixed(0)}만원</Text>
              <Text style={{ color: colors.muted, fontSize: 12 }}>이번 달</Text>
            </View>
            <View style={{ flex: 1, alignItems: "center", gap: 4 }}>
              <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "900" }}>{(totalRevenue / 10000).toFixed(0)}만원</Text>
              <Text style={{ color: colors.muted, fontSize: 12 }}>누적 합계</Text>
            </View>
          </View>
        </View>

        {/* 매물 인기 분석 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>매물 인기 분석</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            <StatBox label="누적 조회" value={listingAnalytics.totalViews} color={colors.foreground} />
            <StatBox label="누적 찜" value={listingAnalytics.totalFavorites} color={colors.primary} />
          </View>
          {popularListings.length === 0 ? (
            <Text style={{ color: colors.muted, fontSize: 13, textAlign: "center", paddingVertical: 12 }}>분석할 매물이 없습니다.</Text>
          ) : (
            popularListings.slice(0, 10).map((listing, index) => (
              <View key={listing.id} style={{ flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 9, borderTopWidth: index === 0 ? 0 : 0.5, borderColor: colors.border }}>
                <Text style={{ color: index < 3 ? colors.foreground : colors.muted, fontSize: 14, fontWeight: "900", width: 20 }}>{index + 1}</Text>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }} numberOfLines={1}>{listing.label}</Text>
                  <Text style={{ color: colors.muted, fontSize: 11 }}>{listing.price.toLocaleString()}원</Text>
                </View>
                <View style={{ alignItems: "flex-end", gap: 2 }}>
                  <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: "700" }}>조회 {listing.views.toLocaleString()}</Text>
                  <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "700" }}>찜 {listing.favorites.toLocaleString()}</Text>
                </View>
              </View>
            ))
          )}
        </View>

        {/* 후기 통계 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>고객 후기 통계</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            <StatBox label="후기 작성률" value={reviewAnalytics.reviewWriteRate} color={colors.foreground} />
            <View style={{ flex: 1, alignItems: "center", gap: 4 }}><Text style={{ color: colors.primary, fontSize: 24, fontWeight: "900" }}>{reviewAnalytics.averageRating.toFixed(1)}</Text><Text style={{ color: colors.muted, fontSize: 12 }}>평균 평점</Text></View>
            <StatBox label="공개 후기" value={reviewAnalytics.publicReviews} color={colors.primary} />
          </View>
          <Text style={{ color: colors.muted, fontSize: 12 }}>거래 완료 {reviewAnalytics.eligibleTransactionCount}건 중 후기 {reviewAnalytics.totalReviews}건이 작성되었습니다.</Text>
        </View>

        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>광고 연결 성과</Text><Text style={{ color: colors.primary, fontSize: 16, fontWeight: "900" }}>탭 {bannerAnalytics.totalClicks} · 연결 {bannerAnalytics.totalConversions}</Text></View>
          <Text style={{ color: colors.muted, fontSize: 11 }}>연결 성과는 전화·웹 링크 실행이 성공한 횟수입니다.</Text>
          {bannerAnalytics.ranked.length === 0 ? <Text style={{ color: colors.muted, fontSize: 13 }}>등록된 광고가 없습니다.</Text> : bannerAnalytics.ranked.map((banner, index) => <View key={banner.id} style={{ flexDirection: "row", alignItems: "center", gap: 8, borderTopWidth: index === 0 ? 0 : 0.5, borderColor: colors.border, paddingTop: index === 0 ? 0 : 9 }}><Text style={{ color: colors.muted, width: 18, fontSize: 12, fontWeight: "800" }}>{index + 1}</Text><Text style={{ color: colors.foreground, flex: 1, fontSize: 13, fontWeight: "700" }} numberOfLines={1}>{banner.title}</Text><Text style={{ color: colors.primary, fontSize: 12, fontWeight: "800" }}>탭 {banner.clickCount ?? 0} · 연결 {banner.conversionCount ?? 0}</Text></View>)}
        </View>

        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>광고 기간·채널 비교</Text><Text style={{ color: colors.muted, fontSize: 11 }}>추적 시작 후 데이터</Text></View>
          <View style={{ flexDirection: "row", gap: 7 }}>{([7, 30, 90] as const).map((days) => <Pressable key={days} onPress={() => setBannerPeriod(days)} style={{ paddingHorizontal: 11, paddingVertical: 7, borderRadius: 8, backgroundColor: bannerPeriod === days ? colors.foreground : colors.background, borderWidth: 1, borderColor: colors.border }}><Text style={{ color: bannerPeriod === days ? colors.background : colors.foreground, fontSize: 12, fontWeight: "800" }}>{days}일</Text></Pressable>)}</View>
          {bannerComparison.length === 0 ? <Text style={{ color: colors.muted, fontSize: 13 }}>비교할 광고가 없습니다.</Text> : bannerComparison.map((banner) => <View key={banner.id} style={{ gap: 6, paddingTop: 7, borderTopWidth: 0.5, borderColor: colors.border }}><View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}><Text style={{ color: colors.foreground, flex: 1, fontSize: 12, fontWeight: "800" }} numberOfLines={1}>{banner.title}</Text><Text style={{ color: colors.muted, fontSize: 11 }}>{banner.channel} · 전환율 {banner.conversionRate}%</Text></View><View style={{ gap: 4 }}><View style={{ height: 7, borderRadius: 4, backgroundColor: colors.border }}><View style={{ width: `${Math.max(1, (banner.taps / bannerChartMax) * 100)}%`, height: 7, borderRadius: 4, backgroundColor: colors.muted }} /></View><View style={{ height: 7, borderRadius: 4, backgroundColor: colors.border }}><View style={{ width: `${Math.max(1, (banner.conversions / bannerChartMax) * 100)}%`, height: 7, borderRadius: 4, backgroundColor: colors.foreground }} /></View></View><Text style={{ color: colors.muted, fontSize: 10 }}>탭 {banner.taps} · 링크 실행 {banner.conversions}</Text></View>)}
        </View>

        {/* 최근 가입 회원 목록 */}
        <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 20, borderWidth: 1, borderColor: colors.border, gap: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "800" }}>최근 가입 회원</Text>
          {accounts.slice(0, 10).map((a) => (
            <View key={a.id} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 6, borderBottomWidth: 0.5, borderBottomColor: colors.border }}>
              <View style={{ gap: 2 }}>
                <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "600" }}>{a.nickname}</Text>
                <Text style={{ color: colors.muted, fontSize: 12 }}>{a.phone}</Text>
              </View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                <View style={{ backgroundColor: a.role === "seller" ? colors.primary : colors.border, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 }}>
                  <Text style={{ color: a.role === "seller" ? colors.background : colors.foreground, fontSize: 10, fontWeight: "700" }}>{a.role === "seller" ? "판매자" : "구매자"}</Text>
                </View>
                <Text style={{ color: colors.muted, fontSize: 11 }}>{new Date(a.createdAt).toLocaleDateString("ko-KR")}</Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function StatBox({ label, value, color }: { label: string; value: number; color: string }) {
  const colors = useColors();
  return (
    <View style={{ flex: 1, alignItems: "center", gap: 4 }}>
      <Text style={{ color, fontSize: 24, fontWeight: "900" }}>{value}</Text>
      <Text style={{ color: colors.muted, fontSize: 12 }}>{label}</Text>
    </View>
  );
}
