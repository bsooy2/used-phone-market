import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { Image, Pressable, ScrollView, Share, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { ImageViewer } from "@/components/image-viewer";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { formatPrice } from "@/constants/phones";
import { SellRequest } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";
import { STORE_INFO } from "@/constants/store-info";
import { useState } from "react";

const STATUS_COLOR: Record<SellRequest["status"], string> = {
  접수: "#9A9A9A",
  검수중: "#4B4B4B",
  입금완료: "#111111",
};

const STATUS_DESC: Record<SellRequest["status"], string> = {
  접수: "신청이 접수되었습니다. 매장에서 곧 연락드립니다.",
  검수중: "기기 검수가 진행 중입니다.",
  입금완료: "매입 대금 입금이 완료되었습니다.",
};

function buildShareText(req: SellRequest): string {
  const lines = [
    `[${STORE_INFO.name}] 중고폰 매입 예상 견적`,
    ``,
    `· 기종: ${req.brand} ${req.model}`,
    `· 용량: ${req.storage}`,
    req.gradeLabel ? `· 등급: ${req.gradeLabel}` : "",
    req.conditionLabels && req.conditionLabels.length > 0
      ? `· 상태: ${req.conditionLabels.join(", ")}`
      : `· 상태: 이상 없음`,
    ``,
    `▶ 예상 매입가: ${formatPrice(req.estimatedPrice)}`,
    ``,
    `※ 실제 매입가는 정밀 검수 후 확정됩니다.`,
    `문의: ${STORE_INFO.phone}`,
  ];
  return lines.filter((l) => l !== "").join("\n");
}

export default function SellDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { sellRequests } = useAppStore();

  const req = sellRequests.find((r) => r.id === id);
  const [viewerVisible, setViewerVisible] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(0);

  async function onShare() {
    if (!req) return;
    try {
      await Share.share({
        message: buildShareText(req),
      });
    } catch {
      // 사용자가 공유를 취소한 경우 등은 무시
    }
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      {/* 헤더 */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>견적 상세</Text>
      </View>

      {!req ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 32, gap: 12 }}>
          <IconSymbol name="doc.text.fill" size={48} color={colors.muted} />
          <Text style={{ color: colors.muted }}>견적 내역을 찾을 수 없습니다.</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40, gap: 20 }}>
          {/* 상태 배지 */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <View
              style={{
                backgroundColor: STATUS_COLOR[req.status],
                borderRadius: 6,
                paddingHorizontal: 10,
                paddingVertical: 4,
              }}
            >
              <Text style={{ color: "#FFFFFF", fontSize: 12, fontWeight: "700" }}>{req.status}</Text>
            </View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>신청일 {req.createdAt}</Text>
          </View>
          <Text style={{ color: colors.muted, fontSize: 13 }}>{STATUS_DESC[req.status]}</Text>

          {/* 예상 매입가 */}
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 20,
              borderWidth: 1,
              borderColor: colors.primary,
              alignItems: "center",
              gap: 4,
            }}
          >
            <Text style={{ color: colors.muted, fontSize: 14 }}>예상 매입가</Text>
            <Text style={{ color: colors.primary, fontSize: 32, fontWeight: "900" }}>
              {formatPrice(req.estimatedPrice)}
            </Text>
          </View>

          {/* 상세 정보 */}
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 18,
              borderWidth: 1,
              borderColor: colors.border,
              gap: 12,
            }}
          >
            <InfoRow label="제조사" value={req.brand} colors={colors} />
            <InfoRow label="모델" value={req.model} colors={colors} />
            <InfoRow label="용량" value={req.storage} colors={colors} />
            {req.gradeLabel && <InfoRow label="기본 등급" value={req.gradeLabel} colors={colors} />}
            <InfoRow
              label="기기 상태"
              value={
                req.conditionLabels && req.conditionLabels.length > 0
                  ? req.conditionLabels.join(", ")
                  : "이상 없음"
              }
              colors={colors}
            />
            {req.imei && (
              <InfoRow
                label="IMEI"
                value={`${req.imei}${req.imeiDeviceInfo ? ` (${req.imeiDeviceInfo.brand} ${req.imeiDeviceInfo.model})` : ""}`}
                colors={colors}
              />
            )}
          </View>

          {/* 첨부 사진 */}
          {req.images && req.images.length > 0 && (
            <View
              style={{
                backgroundColor: colors.surface,
                borderRadius: 16,
                padding: 18,
                borderWidth: 1,
                borderColor: colors.border,
                gap: 12,
              }}
            >
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>
                첨부 사진 ({req.images.length}장)
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
                {req.images.map((uri, idx) => (
                  <Pressable
                    key={idx}
                    onPress={() => { setViewerIndex(idx); setViewerVisible(true); }}
                    style={({ pressed }) => [pressed && { opacity: 0.7 }]}
                  >
                    <Image
                      source={{ uri }}
                      style={{ width: 80, height: 80, borderRadius: 10, backgroundColor: colors.border }}
                    />
                  </Pressable>
                ))}
              </View>
              <ImageViewer
                images={req.images}
                visible={viewerVisible}
                initialIndex={viewerIndex}
                onClose={() => setViewerVisible(false)}
              />
            </View>
          )}

          {/* 동의 내역 */}
          {req.agreements && (
            <View
              style={{
                backgroundColor: colors.surface,
                borderRadius: 16,
                padding: 18,
                borderWidth: 1,
                borderColor: colors.border,
                gap: 8,
              }}
            >
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "700" }}>동의 내역</Text>
              <View style={{ gap: 4 }}>
                <Text style={{ color: colors.success, fontSize: 13 }}>✓ 개인정보 수집·이용 동의</Text>
                <Text style={{ color: colors.success, fontSize: 13 }}>✓ 안전거래 약관 동의</Text>
                <Text style={{ color: colors.success, fontSize: 13 }}>✓ 분실폰이 아님을 확인</Text>
              </View>
              <Text style={{ color: colors.muted, fontSize: 11 }}>
                동의일시: {req.agreements.agreedAt.slice(0, 10)} {req.agreements.agreedAt.slice(11, 16)}
              </Text>
            </View>
          )}

          {/* 공유 버튼 */}
          <Pressable
            onPress={onShare}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                backgroundColor: colors.primary,
                borderRadius: 14,
                paddingVertical: 16,
              },
              pressed && { transform: [{ scale: 0.98 }], opacity: 0.9 },
            ]}
          >
            <IconSymbol name="square.and.arrow.up" size={20} color={colors.background} />
            <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>견적 공유하기</Text>
          </Pressable>

          <Pressable
            onPress={() => router.push({ pathname: "/trade-inquiry", params: { transactionId: req.id, transactionType: "sell", transactionLabel: `${req.model} 판매 신청` } })}
            style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, paddingVertical: 14 }, pressed && { opacity: 0.72 }]}
          >
            <IconSymbol name="message.fill" size={18} color={colors.primary} />
            <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 15 }}>이 거래 1:1 문의</Text>
          </Pressable>

          {/* 다시 견적내기 */}
          <Pressable
            onPress={() => router.push("/(tabs)/sell")}
            style={({ pressed }) => [{ alignItems: "center", paddingVertical: 8 }, pressed && { opacity: 0.6 }]}
          >
            <Text style={{ color: colors.muted, fontSize: 14, fontWeight: "600" }}>다른 기기 견적내기</Text>
          </Pressable>
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

function InfoRow({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
      <Text style={{ color: colors.muted, fontSize: 14 }}>{label}</Text>
      <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "600", flex: 1, textAlign: "right" }}>
        {value}
      </Text>
    </View>
  );
}
