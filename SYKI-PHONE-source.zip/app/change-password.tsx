import { Stack, useRouter } from "expo-router";
import { useState } from "react";
import { Alert, Pressable, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuthStore } from "@/lib/auth-store";

export default function ChangePasswordScreen() {
  const colors = useColors();
  const router = useRouter();
  const { verifyPassword, changePassword } = useAuthStore();

  const [current, setCurrent] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    setError(null);
    if (!current) { setError("현재 비밀번호를 입력해 주세요."); return; }
    if (newPw.length < 4) { setError("새 비밀번호는 4자 이상이어야 합니다."); return; }
    if (newPw !== confirmPw) { setError("새 비밀번호가 일치하지 않습니다."); return; }

    const ok = await verifyPassword(current);
    if (!ok) { setError("현재 비밀번호가 틀립니다."); return; }

    setSaving(true);
    const res = await changePassword(newPw);
    setSaving(false);
    if (res.ok) {
      Alert.alert("완료", "비밀번호가 변경되었습니다.", [{ text: "확인", onPress: () => router.back() }]);
    } else {
      setError(res.error ?? "변경에 실패했습니다.");
    }
  }

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 8, gap: 8 }}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>비밀번호 변경</Text>
      </View>

      <View style={{ flex: 1, padding: 24, gap: 16 }}>
        <Text style={{ color: colors.muted, fontSize: 13 }}>현재 비밀번호를 입력한 후 새 비밀번호를 설정하세요.</Text>

        <TextInput
          value={current}
          onChangeText={setCurrent}
          placeholder="현재 비밀번호"
          placeholderTextColor={colors.muted}
          secureTextEntry
          style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14, fontSize: 15, color: colors.foreground }}
        />
        <TextInput
          value={newPw}
          onChangeText={setNewPw}
          placeholder="새 비밀번호 (4자 이상)"
          placeholderTextColor={colors.muted}
          secureTextEntry
          style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14, fontSize: 15, color: colors.foreground }}
        />
        <TextInput
          value={confirmPw}
          onChangeText={setConfirmPw}
          placeholder="새 비밀번호 확인"
          placeholderTextColor={colors.muted}
          secureTextEntry
          returnKeyType="done"
          onSubmitEditing={handleSubmit}
          style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14, fontSize: 15, color: colors.foreground }}
        />

        {error && <Text style={{ color: colors.error, fontSize: 13 }}>{error}</Text>}

        <Pressable
          onPress={handleSubmit}
          disabled={saving}
          style={({ pressed }) => [
            { backgroundColor: colors.foreground, borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 8, opacity: saving ? 0.7 : 1 },
            pressed && { opacity: 0.85 },
          ]}
        >
          <Text style={{ color: colors.background, fontWeight: "800", fontSize: 16 }}>{saving ? "변경 중..." : "비밀번호 변경"}</Text>
        </Pressable>
      </View>
    </ScreenContainer>
  );
}
