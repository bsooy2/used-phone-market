import { Stack, useRouter } from "expo-router";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

const EFFECTIVE_DATE = "2025년 7월 29일";

export default function TermsScreen() {
  const colors = useColors();
  const router = useRouter();

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: false }} />
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 12,
          paddingVertical: 8,
          gap: 4,
          borderBottomWidth: 0.5,
          borderBottomColor: colors.border,
        }}
      >
        <Pressable onPress={() => router.back()} style={({ pressed }) => [{ padding: 6 }, pressed && { opacity: 0.6 }]}>
          <IconSymbol name="chevron.left" size={26} color={colors.foreground} />
        </Pressable>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700", flex: 1 }}>이용약관</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60, gap: 24 }}>
        <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "800" }}>이용약관</Text>
        <Text style={{ color: colors.muted, fontSize: 13 }}>시행일: {EFFECTIVE_DATE}</Text>

        <Section title="제1조 (목적)" colors={colors}>
          {`본 약관은 SYKI PHONE 시끼폰(이하 "회사")이 제공하는 중고폰 매입·매매 중개 서비스(이하 "서비스")의 이용 조건 및 절차, 회사와 이용자의 권리·의무 및 책임 사항을 규정함을 목적으로 합니다.`}
        </Section>

        <Section title="제2조 (정의)" colors={colors}>
          {`① "서비스"란 회사가 제공하는 중고 휴대폰 매입 견적, 매물 등록, 거래 중개 등 일체의 서비스를 말합니다.
② "이용자"란 본 약관에 따라 서비스를 이용하는 자를 말합니다.
③ "매도인"이란 중고폰을 판매하고자 하는 이용자를 말합니다.
④ "매수인"이란 중고폰을 매입하는 회사를 말합니다.`}
        </Section>

        <Section title="제3조 (약관의 효력 및 변경)" colors={colors}>
          {`① 본 약관은 서비스 화면에 게시하거나 기타의 방법으로 이용자에게 공지함으로써 효력이 발생합니다.
② 회사는 관련 법령을 위배하지 않는 범위에서 약관을 개정할 수 있으며, 개정 시 적용일자 7일 전부터 공지합니다.
③ 변경된 약관에 동의하지 않는 이용자는 서비스 이용을 중단하고 탈퇴할 수 있습니다.`}
        </Section>

        <Section title="제4조 (서비스의 제공)" colors={colors}>
          {`회사는 다음과 같은 서비스를 제공합니다.
① 중고폰 매입 견적 조회 서비스
② 중고폰 매물 등록 및 판매 중개 서비스
③ 기기 상태 검수 및 등급 판정 서비스
④ 기타 회사가 정하는 서비스`}
        </Section>

        <Section title="제5조 (이용자의 의무)" colors={colors}>
          {`이용자는 다음 행위를 하여서는 안 됩니다.
① 허위 정보를 등록하는 행위
② 분실·도난 기기를 판매하는 행위
③ 타인의 정보를 도용하는 행위
④ 서비스의 운영을 방해하는 행위
⑤ 관련 법령에 위반되는 행위`}
        </Section>

        <Section title="제6조 (거래 조건)" colors={colors}>
          {`① 매입 견적은 이용자가 입력한 정보를 기반으로 산출되며, 실제 매입가는 정밀 검수 후 확정됩니다.
② 검수 결과 이용자가 입력한 정보와 실제 기기 상태가 다를 경우, 매입가가 조정될 수 있습니다.
③ 매입 확정 후 대금은 이용자가 지정한 계좌로 영업일 기준 1~3일 이내에 입금됩니다.`}
        </Section>

        <Section title="제7조 (책임의 제한)" colors={colors}>
          {`① 회사는 천재지변, 전쟁, 기간통신사업자의 서비스 중지 등 불가항력적 사유로 서비스를 제공할 수 없는 경우 책임이 면제됩니다.
② 이용자의 귀책사유로 인한 서비스 이용 장애에 대하여 회사는 책임을 지지 않습니다.
③ 이용자가 제공한 정보의 정확성에 대한 책임은 이용자에게 있습니다.`}
        </Section>

        <Section title="제8조 (분쟁 해결)" colors={colors}>
          {`① 서비스 이용과 관련하여 분쟁이 발생한 경우, 회사와 이용자는 상호 협의하여 해결합니다.
② 협의가 이루어지지 않을 경우, 관할 법원은 회사 소재지 관할 법원으로 합니다.`}
        </Section>

        <Section title="제9조 (기타)" colors={colors}>
          {`본 약관에 명시되지 않은 사항은 관련 법령 및 상관례에 따릅니다.`}
        </Section>

        <View style={{ borderTopWidth: 0.5, borderTopColor: colors.border, paddingTop: 16 }}>
          <Text style={{ color: colors.muted, fontSize: 12, textAlign: "center" }}>
            SYKI PHONE (시끼폰) | 010-2394-1420 | 제주특별자치도 서귀포시
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function Section({
  title,
  children,
  colors,
}: {
  title: string;
  children: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>{title}</Text>
      <Text style={{ color: colors.foreground, fontSize: 14, lineHeight: 22 }}>{children}</Text>
    </View>
  );
}
