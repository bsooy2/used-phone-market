import { useMemo, useState } from "react";
import { FlatList, Modal, Platform, Pressable, Text, TextInput, View } from "react-native";
import { WebView } from "react-native-webview";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { AddressItem, searchAddress } from "@/constants/address-data";

type Props = {
  visible: boolean;
  onClose: () => void;
  onSelect: (item: AddressItem) => void;
};

/**
 * 다음(카카오) 우편번호 서비스를 임베드한 HTML.
 * 주소 선택 시 window.ReactNativeWebView.postMessage 로 결과를 전달한다.
 * 외부 API 키가 필요 없는 공개 서비스이다.
 */
const DAUM_POSTCODE_HTML = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <style>
    html, body { margin: 0; padding: 0; height: 100%; background: #ffffff; }
    #wrap { width: 100%; height: 100%; }
  </style>
</head>
<body>
  <div id="wrap"></div>
  <script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
  <script>
    function post(payload) {
      if (window.ReactNativeWebView) {
        window.ReactNativeWebView.postMessage(JSON.stringify(payload));
      }
    }
    function openPostcode() {
      new daum.Postcode({
        oncomplete: function (data) {
          var road = data.roadAddress || data.address || "";
          var jibun = data.jibunAddress || data.autoJibunAddress || "";
          var region = (data.sido || "") + " " + (data.sigungu || "");
          post({
            type: "select",
            zipcode: data.zonecode || "",
            road: road,
            jibun: jibun,
            region: region.trim(),
          });
        },
        onclose: function (state) {
          if (state === "FORCE_CLOSE" || state === "COMPLETE_CLOSE") {
            post({ type: "close" });
          }
        },
        width: "100%",
        height: "100%",
      }).embed(document.getElementById("wrap"), { autoClose: false });
    }
    if (window.daum && window.daum.Postcode) {
      openPostcode();
    } else {
      window.addEventListener("load", openPostcode);
    }
  </script>
</body>
</html>`;

export function AddressSearchModal({ visible, onClose, onSelect }: Props) {
  const colors = useColors();
  const [query, setQuery] = useState("");

  // 웹(미리보기) 환경에서는 WebView가 제한적이라 내장 샘플 검색으로 폴백한다.
  const useFallback = Platform.OS === "web";

  const results = useMemo(() => searchAddress(query), [query]);
  const hasQuery = query.trim().length > 0;

  function handleClose() {
    setQuery("");
    onClose();
  }

  function handleSelect(item: AddressItem) {
    onSelect(item);
    setQuery("");
    onClose();
  }

  function handleWebMessage(raw: string) {
    try {
      const data = JSON.parse(raw) as
        | { type: "select"; zipcode: string; road: string; jibun: string; region: string }
        | { type: "close" };
      if (data.type === "select") {
        handleSelect({
          zipcode: data.zipcode,
          road: data.road,
          jibun: data.jibun || data.road,
          region: data.region,
        });
      } else if (data.type === "close") {
        handleClose();
      }
    } catch {
      // 파싱 실패는 무시
    }
  }

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={handleClose}>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        {/* 헤더 */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingHorizontal: 16,
            paddingTop: Platform.OS === "ios" ? 16 : 20,
            paddingBottom: 12,
            borderBottomWidth: 0.5,
            borderBottomColor: colors.border,
          }}
        >
          <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "800" }}>주소 검색</Text>
          <Pressable onPress={handleClose} style={({ pressed }) => [{ padding: 4 }, pressed && { opacity: 0.6 }]}>
            <IconSymbol name="xmark" size={24} color={colors.foreground} />
          </Pressable>
        </View>

        {useFallback ? (
          <FallbackSearch
            colors={colors}
            query={query}
            setQuery={setQuery}
            hasQuery={hasQuery}
            results={results}
            onSelect={handleSelect}
          />
        ) : (
          <WebView
            originWhitelist={["*"]}
            source={{ html: DAUM_POSTCODE_HTML, baseUrl: "https://postcode.map.daum.net" }}
            onMessage={(e) => handleWebMessage(e.nativeEvent.data)}
            style={{ flex: 1, backgroundColor: colors.background }}
            javaScriptEnabled
            domStorageEnabled
            startInLoadingState
          />
        )}
      </View>
    </Modal>
  );
}

/** 웹 미리보기 환경 전용: 내장 샘플 주소 검색 UI */
function FallbackSearch({
  colors,
  query,
  setQuery,
  hasQuery,
  results,
  onSelect,
}: {
  colors: ReturnType<typeof useColors>;
  query: string;
  setQuery: (v: string) => void;
  hasQuery: boolean;
  results: AddressItem[];
  onSelect: (item: AddressItem) => void;
}) {
  return (
    <>
      <View style={{ padding: 16, gap: 6 }}>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: colors.surface,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: colors.border,
            paddingHorizontal: 12,
          }}
        >
          <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="도로명, 동/읍/면 또는 건물명 입력"
            placeholderTextColor={colors.muted}
            autoFocus
            returnKeyType="search"
            style={{ flex: 1, paddingVertical: 12, paddingHorizontal: 8, fontSize: 15, color: colors.foreground }}
          />
        </View>
        <Text style={{ color: colors.muted, fontSize: 12 }}>
          미리보기(웹)에서는 샘플 주소만 검색됩니다. 실제 앱에서는 전국 주소 검색이 지원됩니다. 예: 테헤란로, 중앙로, 송도동, 판교
        </Text>
      </View>

      {!hasQuery ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 24 }}>
          <IconSymbol name="location.fill" size={40} color={colors.muted} />
          <Text style={{ color: colors.muted, marginTop: 12, textAlign: "center" }}>
            검색어를 입력하면 주소 후보가 표시됩니다.
          </Text>
        </View>
      ) : results.length === 0 ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 24 }}>
          <Text style={{ color: colors.muted, textAlign: "center" }}>
            검색 결과가 없습니다.{"\n"}다른 검색어로 시도해 주세요.
          </Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item) => item.zipcode + item.road}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 32 }}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => onSelect(item)}
              style={({ pressed }) => [
                {
                  paddingVertical: 14,
                  borderBottomWidth: 0.5,
                  borderBottomColor: colors.border,
                },
                pressed && { opacity: 0.6 },
              ]}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 }}>
                <View
                  style={{
                    backgroundColor: colors.primary + "18",
                    paddingHorizontal: 8,
                    paddingVertical: 2,
                    borderRadius: 6,
                  }}
                >
                  <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "800" }}>{item.zipcode}</Text>
                </View>
              </View>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "600" }}>{item.road}</Text>
              <Text style={{ color: colors.muted, fontSize: 13, marginTop: 2 }}>[지번] {item.jibun}</Text>
            </Pressable>
          )}
        />
      )}
    </>
  );
}
