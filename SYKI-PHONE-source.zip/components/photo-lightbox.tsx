import { useState } from "react";
import { Modal, Pressable, Text, View, Dimensions } from "react-native";
import { Image } from "expo-image";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export function PhotoLightbox({
  photos,
  initialIndex = 0,
  visible,
  onClose,
}: {
  photos: string[];
  initialIndex?: number;
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const screenWidth = Dimensions.get("window").width;

  if (!visible || photos.length === 0) return null;

  const currentUri = photos[currentIndex] ?? photos[0];

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.92)", justifyContent: "center", alignItems: "center" }}>
        <Pressable onPress={onClose} style={{ position: "absolute", top: 48, right: 24, zIndex: 10, padding: 8, backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 20 }}>
          <IconSymbol name="xmark" size={22} color="#ffffff" />
        </Pressable>
        <View style={{ width: screenWidth, height: screenWidth * 1.1, justifyContent: "center", alignItems: "center" }}>
          <Image source={{ uri: currentUri }} style={{ width: "100%", height: "100%" }} contentFit="contain" />
        </View>
        {photos.length > 1 && (
          <View style={{ flexDirection: "row", gap: 10, marginTop: 24, alignItems: "center" }}>
            {photos.map((uri, index) => (
              <Pressable key={`${uri}-${index}`} onPress={() => setCurrentIndex(index)} style={{ width: index === currentIndex ? 24 : 8, height: 8, borderRadius: 4, backgroundColor: index === currentIndex ? "#ffffff" : "rgba(255,255,255,0.4)" }} />
            ))}
          </View>
        )}
        <Text style={{ color: "#ffffff", fontSize: 14, marginTop: 16, opacity: 0.85 }}>{currentIndex + 1} / {photos.length}</Text>
      </View>
    </Modal>
  );
}
