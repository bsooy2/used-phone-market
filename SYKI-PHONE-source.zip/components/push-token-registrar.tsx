import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import { useEffect } from "react";
import { Platform } from "react-native";

import { useAuthStore } from "@/lib/auth-store";
import { trpc } from "@/lib/trpc";

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: true }),
});

/** 로그인된 실제 기기에서 Expo 토큰을 받아 서버에 저장한다. 웹·에뮬레이터에서는 조용히 건너뛴다. */
export function PushTokenRegistrar() {
  const { user } = useAuthStore();
  const register = trpc.push.registerDevice.useMutation();

  useEffect(() => {
    if (Platform.OS === "web" || !user?.id) return;
    let active = true;
    const run = async () => {
      try {
        if (Platform.OS === "android") {
          await Notifications.setNotificationChannelAsync("trade-replies", { name: "거래 문의 답변", importance: Notifications.AndroidImportance.HIGH });
        }
        const existing = await Notifications.getPermissionsAsync();
        const permission = existing.status === "granted" ? existing : await Notifications.requestPermissionsAsync();
        if (permission.status !== "granted") return;
        const projectId = Constants.easConfig?.projectId ?? Constants.expoConfig?.extra?.eas?.projectId;
        if (!projectId) return;
        const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
        if (active) await register.mutateAsync({ userId: user.id, token });
      } catch {
        // 네트워크·Expo Go 환경에서는 다음 앱 실행 시 재시도한다.
      }
    };
    void run();
    return () => { active = false; };
  }, [register, user?.id]);

  return null;
}
