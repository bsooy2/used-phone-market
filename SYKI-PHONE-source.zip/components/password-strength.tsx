import { View, Text } from "react-native";
import { useColors } from "@/hooks/use-colors";

type Strength = "none" | "weak" | "medium" | "strong";

export function getPasswordStrength(pw: string): Strength {
  if (!pw || pw.length < 1) return "none";
  if (pw.length < 4) return "weak";
  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (score <= 1) return "weak";
  if (score <= 3) return "medium";
  return "strong";
}

const LABELS: Record<Strength, string> = { none: "", weak: "약함", medium: "보통", strong: "강함" };
const COLORS: Record<Strength, string> = { none: "transparent", weak: "#EF4444", medium: "#F59E0B", strong: "#22C55E" };

export function PasswordStrengthBar({ password }: { password: string }) {
  const colors = useColors();
  const strength = getPasswordStrength(password);
  if (strength === "none") return null;

  const barCount = strength === "weak" ? 1 : strength === "medium" ? 2 : 3;
  return (
    <View style={{ gap: 4 }}>
      <View style={{ flexDirection: "row", gap: 4 }}>
        {[1, 2, 3].map((i) => (
          <View key={i} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: i <= barCount ? COLORS[strength] : colors.border }} />
        ))}
      </View>
      <Text style={{ fontSize: 11, color: COLORS[strength], fontWeight: "600" }}>{LABELS[strength]}</Text>
    </View>
  );
}
