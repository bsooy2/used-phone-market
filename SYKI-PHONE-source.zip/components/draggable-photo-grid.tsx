import { Image, Pressable, Text, View } from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import Animated, { runOnJS, useAnimatedStyle, useSharedValue, withTiming } from "react-native-reanimated";

import { getPhotoDropIndex } from "@/lib/photo-order";

const PHOTO_SIZE = 72;
const PHOTO_GAP = 10;
const PHOTO_CELL_WIDTH = PHOTO_SIZE + PHOTO_GAP;
const PHOTO_CELL_HEIGHT = PHOTO_SIZE + 31;
const COLUMN_COUNT = 3;

type PhotoGridColors = {
  background: string;
  border: string;
  error: string;
  foreground: string;
  muted: string;
  surface: string;
};

type DraggablePhotoGridProps = {
  colors: PhotoGridColors;
  photos: string[];
  draggingIndex: number | null;
  dropIndex: number | null;
  onDragStart: (index: number) => void;
  onDragMove: (index: number) => void;
  onDragEnd: () => void;
  onDrop: (fromIndex: number, toIndex: number) => void;
  onRemove: (index: number) => void;
};

export function DraggablePhotoGrid({
  colors,
  photos,
  draggingIndex,
  dropIndex,
  onDragStart,
  onDragMove,
  onDragEnd,
  onDrop,
  onRemove,
}: DraggablePhotoGridProps) {
  return (
    <View
      style={{
        width: PHOTO_SIZE * COLUMN_COUNT + PHOTO_GAP * (COLUMN_COUNT - 1),
        flexDirection: "row",
        flexWrap: "wrap",
        gap: PHOTO_GAP,
        marginBottom: 10,
      }}
    >
      {photos.map((uri, index) => (
        <DraggablePhotoTile
          key={`${uri}-${index}`}
          uri={uri}
          index={index}
          totalPhotos={photos.length}
          colors={colors}
          dragging={draggingIndex === index}
          receivingDrop={dropIndex === index && draggingIndex !== index}
          onDragStart={onDragStart}
          onDragMove={onDragMove}
          onDragEnd={onDragEnd}
          onDrop={onDrop}
          onRemove={onRemove}
        />
      ))}
    </View>
  );
}

type DraggablePhotoTileProps = Omit<DraggablePhotoGridProps, "photos" | "draggingIndex" | "dropIndex"> & {
  uri: string;
  index: number;
  totalPhotos: number;
  dragging: boolean;
  receivingDrop: boolean;
};

function DraggablePhotoTile({
  uri,
  index,
  totalPhotos,
  colors,
  dragging,
  receivingDrop,
  onDragStart,
  onDragMove,
  onDragEnd,
  onDrop,
  onRemove,
}: DraggablePhotoTileProps) {
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const lastTargetIndex = useSharedValue(index);

  const dragGesture = Gesture.Pan()
    .activateAfterLongPress(280)
    .shouldCancelWhenOutside(false)
    .onBegin(() => {
      lastTargetIndex.value = index;
      runOnJS(onDragStart)(index);
    })
    .onUpdate((event) => {
      translateX.value = event.translationX;
      translateY.value = event.translationY;
      const targetIndex = getPhotoDropIndex(
        index,
        event.translationX,
        event.translationY,
        totalPhotos,
        COLUMN_COUNT,
        PHOTO_CELL_WIDTH,
        PHOTO_CELL_HEIGHT,
      );
      if (targetIndex !== lastTargetIndex.value) {
        lastTargetIndex.value = targetIndex;
        runOnJS(onDragMove)(targetIndex);
      }
    })
    .onEnd((event) => {
      const targetIndex = getPhotoDropIndex(
        index,
        event.translationX,
        event.translationY,
        totalPhotos,
        COLUMN_COUNT,
        PHOTO_CELL_WIDTH,
        PHOTO_CELL_HEIGHT,
      );
      runOnJS(onDrop)(index, targetIndex);
    })
    .onFinalize(() => {
      translateX.value = withTiming(0, { duration: 150 });
      translateY.value = withTiming(0, { duration: 150 });
      runOnJS(onDragEnd)();
    });

  const draggingStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }, { translateY: translateY.value }, { scale: dragging ? 1.08 : 1 }],
    opacity: dragging ? 0.92 : 1,
  }));

  return (
    <GestureDetector gesture={dragGesture}>
      <Animated.View
        style={[
          { width: PHOTO_SIZE, gap: 5, zIndex: dragging ? 10 : 1 },
          draggingStyle,
        ]}
      >
        <View
          style={{
            position: "relative",
            borderRadius: 11,
            borderWidth: receivingDrop ? 2.5 : 1,
            borderColor: receivingDrop ? colors.foreground : colors.border,
            padding: receivingDrop ? 0 : 1,
            backgroundColor: colors.background,
          }}
        >
          <Image
            source={{ uri }}
            style={{ width: PHOTO_SIZE - 2, height: PHOTO_SIZE - 2, borderRadius: 9, backgroundColor: colors.surface }}
          />
          {index === 0 ? (
            <View
              style={{
                position: "absolute",
                left: 5,
                bottom: 5,
                paddingHorizontal: 5,
                paddingVertical: 2,
                borderRadius: 4,
                backgroundColor: colors.foreground,
              }}
            >
              <Text style={{ color: colors.background, fontSize: 9, fontWeight: "800" }}>대표</Text>
            </View>
          ) : null}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`${index + 1}번 사진 삭제`}
            onPress={() => onRemove(index)}
            style={({ pressed }) => [
              {
                position: "absolute",
                top: -7,
                right: -7,
                width: 22,
                height: 22,
                borderRadius: 11,
                backgroundColor: colors.foreground,
                alignItems: "center",
                justifyContent: "center",
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={{ color: colors.background, fontSize: 13, fontWeight: "800", lineHeight: 15 }}>×</Text>
          </Pressable>
        </View>
        <Text style={{ color: dragging ? colors.foreground : colors.muted, textAlign: "center", fontSize: 10, fontWeight: dragging ? "800" : "600" }}>
          {dragging ? "이동 중" : "길게 눌러 이동"}
        </Text>
      </Animated.View>
    </GestureDetector>
  );
}
