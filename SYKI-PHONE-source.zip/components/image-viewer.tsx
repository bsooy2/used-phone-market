import { useState } from "react";
import {
  Dimensions,
  FlatList,
  Image,
  Modal,
  Pressable,
  Text,
  View,
} from "react-native";
import { useColors } from "@/hooks/use-colors";

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");

type Props = {
  images: string[];
  visible: boolean;
  initialIndex?: number;
  onClose: () => void;
};

/**
 * 전체 화면 이미지 갤러리 뷰어.
 * 좌우 스와이프로 사진을 넘길 수 있고, 상단 X 버튼으로 닫습니다.
 */
export function ImageViewer({ images, visible, initialIndex = 0, onClose }: Props) {
  const colors = useColors();
  const [currentIndex, setCurrentIndex] = useState(initialIndex);

  if (!visible || images.length === 0) return null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.95)" }}>
        {/* 헤더 */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingTop: 60,
            paddingHorizontal: 20,
            paddingBottom: 12,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 15, fontWeight: "600" }}>
            {currentIndex + 1} / {images.length}
          </Text>
          <Pressable
            onPress={onClose}
            style={({ pressed }) => [
              {
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: "rgba(255,255,255,0.15)",
                alignItems: "center",
                justifyContent: "center",
              },
              pressed && { opacity: 0.6 },
            ]}
          >
            <Text style={{ color: "#fff", fontSize: 20, fontWeight: "700", lineHeight: 22 }}>×</Text>
          </Pressable>
        </View>

        {/* 이미지 스와이프 */}
        <FlatList
          data={images}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          initialScrollIndex={initialIndex}
          getItemLayout={(_, index) => ({
            length: SCREEN_W,
            offset: SCREEN_W * index,
            index,
          })}
          onMomentumScrollEnd={(e) => {
            const idx = Math.round(e.nativeEvent.contentOffset.x / SCREEN_W);
            setCurrentIndex(idx);
          }}
          keyExtractor={(_, idx) => String(idx)}
          renderItem={({ item }) => (
            <View style={{ width: SCREEN_W, flex: 1, justifyContent: "center", alignItems: "center" }}>
              <Image
                source={{ uri: item }}
                style={{ width: SCREEN_W - 40, height: SCREEN_H * 0.6, borderRadius: 12 }}
                resizeMode="contain"
              />
            </View>
          )}
        />

        {/* 하단 인디케이터 */}
        {images.length > 1 && (
          <View style={{ flexDirection: "row", justifyContent: "center", gap: 6, paddingBottom: 40 }}>
            {images.map((_, idx) => (
              <View
                key={idx}
                style={{
                  width: idx === currentIndex ? 20 : 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: idx === currentIndex ? "#fff" : "rgba(255,255,255,0.3)",
                }}
              />
            ))}
          </View>
        )}
      </View>
    </Modal>
  );
}
