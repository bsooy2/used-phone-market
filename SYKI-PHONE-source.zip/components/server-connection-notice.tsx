import { useEffect, useRef } from "react";
import { Alert, Pressable, Text, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAppStore } from "@/lib/app-store";

/**
 * 앱 시작 시 서버 매물 API 연결에 실패하면 한 번만 안내하고 즉시 재시도할 수 있게 한다.
 */
export function ServerConnectionAlert() {
  const { listingsError, refetchListings } = useAppStore();
  const alertedRef = useRef(false);

  useEffect(() => {
    if (!listingsError) {
      alertedRef.current = false;
      return;
    }
    if (alertedRef.current) return;

    alertedRef.current = true;
    Alert.alert(
      "서버 연결 확인",
      "매물 정보를 불러오지 못했습니다. 인터넷 연결을 확인한 뒤 다시 시도해 주세요.",
      [
        { text: "나중에", style: "cancel" },
        { text: "다시 시도", onPress: refetchListings },
      ],
    );
  }, [listingsError, refetchListings]);

  return null;
}

/** 매물 화면에 유지되는 연결 실패 안내 및 재시도 버튼 */
export function ServerConnectionBanner() {
  const colors = useColors();
  const { listingsError, listingsRefreshing, refetchListings } = useAppStore();

  if (!listingsError) return null;

  return (
    <View
      style={{
        marginHorizontal: 20,
        marginBottom: 12,
        padding: 14,
        gap: 10,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: colors.border,
        backgroundColor: colors.surface,
      }}
    >
      <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "800" }}>
        매물 정보를 불러오지 못했습니다
      </Text>
      <Text style={{ color: colors.muted, fontSize: 12, lineHeight: 18 }}>
        네트워크 상태를 확인한 뒤 다시 시도해 주세요.
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="매물 정보 다시 불러오기"
        disabled={listingsRefreshing}
        onPress={refetchListings}
        style={({ pressed }) => [
          {
            alignSelf: "flex-start",
            flexDirection: "row",
            alignItems: "center",
            gap: 5,
            paddingHorizontal: 10,
            paddingVertical: 8,
            borderRadius: 9,
            backgroundColor: colors.primary,
            opacity: listingsRefreshing ? 0.55 : 1,
          },
          pressed && !listingsRefreshing && { opacity: 0.8 },
        ]}
      >
        <IconSymbol name="arrow.clockwise" size={16} color={colors.background} />
        <Text style={{ color: colors.background, fontWeight: "800", fontSize: 12 }}>
          {listingsRefreshing ? "다시 불러오는 중" : "다시 시도"}
        </Text>
      </Pressable>
    </View>
  );
}
