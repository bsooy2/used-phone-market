// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

/**
 * Add your SF Symbols to Material Icons mappings here.
 */
const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "list.bullet": "list",
  "bag.fill": "shopping-bag",
  "person.fill": "person",
  "magnifyingglass": "search",
  "heart": "favorite-border",
  "heart.fill": "favorite",
  "checkmark.circle.fill": "check-circle",
  "phone.fill": "smartphone",
  "tag.fill": "sell",
  "arrow.right": "arrow-forward",
  "plus.circle.fill": "add-circle",
  "doc.text.fill": "receipt-long",
  "xmark": "close",
  "cart.fill": "shopping-cart",
  "clock.fill": "schedule",
  "phone.down.fill": "call",
  "plus": "add",
  "trash.fill": "delete",
  "location.fill": "location-on",
  "lock.fill": "lock",
  "checkmark": "check",
  "chevron.left": "chevron-left",
  "creditcard.fill": "credit-card",
  "building.columns.fill": "account-balance",
  "wonsign.circle.fill": "paid",
  "shield.fill": "verified-user",
  "xmark.circle.fill": "cancel",
  "bell.fill": "notifications",
  "bell": "notifications-none",
  "chart.bar.fill": "bar-chart",
  "shippingbox.fill": "local-shipping",
  "checkmark.seal.fill": "verified",
  "banknote.fill": "payments",
  "hourglass": "hourglass-empty",
  "gearshape.fill": "settings",
  "slider.horizontal.3": "tune",
  "square.and.arrow.up": "ios-share",
  "photo.fill": "photo-library",
  "camera.fill": "photo-camera",
  "arrow.clockwise": "refresh",
  "arrow.left.arrow.right": "swap-horiz",
} as IconMapping;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
