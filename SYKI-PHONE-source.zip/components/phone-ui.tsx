import { useEffect, useState } from "react";
import { Image, Pressable, Text, View } from "react-native";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { GRADE_INFO, formatPrice } from "@/constants/phones";
import { Grade, Phone } from "@/constants/types";
import { useColors } from "@/hooks/use-colors";

export function GradeBadge({ grade, size = "md" }: { grade: Grade; size?: "sm" | "md" }) {
  const info = GRADE_INFO[grade];
  const pad = size === "sm" ? { paddingHorizontal: 6, paddingVertical: 2 } : { paddingHorizontal: 8, paddingVertical: 3 };
  return (
    <View style={{ backgroundColor: info.color, borderRadius: 6, ...pad }}>
      <Text style={{ color: "#fff", fontSize: size === "sm" ? 10 : 12, fontWeight: "700" }}>
        {info.label}
      </Text>
    </View>
  );
}

// 등록 사진 우선, 사진이 없거나 불러오지 못하면 색상 + 아이콘으로 표시한다.
export function PhoneThumb({ color, photos, size = 64 }: { color: string; photos?: string[]; size?: number }) {
  const photoUri = photos?.[0]?.trim();
  const [imageFailed, setImageFailed] = useState(false);

  useEffect(() => {
    setImageFailed(false);
  }, [photoUri]);

  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: 14,
        backgroundColor: color,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <IconSymbol name="phone.fill" size={size * 0.5} color="#FFFFFF" />
      {photoUri && !imageFailed ? (
        <Image
          source={{ uri: photoUri }}
          onError={() => setImageFailed(true)}
          accessibilityLabel="등록된 매물 사진"
          style={{ position: "absolute", width: size, height: size, borderRadius: 14 }}
          resizeMode="cover"
        />
      ) : null}
    </View>
  );
}

export function PhoneCard({ phone, onPress }: { phone: Phone; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          flexDirection: "row",
          backgroundColor: colors.surface,
          borderRadius: 16,
          padding: 12,
          gap: 12,
          alignItems: "center",
          borderWidth: 1,
          borderColor: colors.border,
        },
        pressed && { opacity: 0.7 },
      ]}
    >
      <PhoneThumb color={phone.image} photos={phone.photos} size={68} />
      <View style={{ flex: 1, gap: 4 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <GradeBadge grade={phone.grade} size="sm" />
          <Text style={{ color: colors.muted, fontSize: 12 }}>{phone.brand}</Text>
        </View>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }} numberOfLines={1}>
          {phone.model}
        </Text>
        <Text style={{ color: colors.muted, fontSize: 13 }} numberOfLines={1}>
          {phone.storage} · {phone.color} · 배터리 {phone.battery}%
        </Text>
        <Text style={{ color: colors.primary, fontSize: 17, fontWeight: "800", marginTop: 2 }}>
          {formatPrice(phone.price)}
        </Text>
      </View>
    </Pressable>
  );
}

export function SectionHeader({
  title,
  actionLabel,
  onAction,
}: {
  title: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 12,
      }}
    >
      <Text style={{ color: colors.foreground, fontSize: 19, fontWeight: "800" }}>{title}</Text>
      {actionLabel && onAction ? (
        <Pressable
          onPress={onAction}
          style={({ pressed }) => [
            { flexDirection: "row", alignItems: "center", gap: 2 },
            pressed && { opacity: 0.6 },
          ]}
        >
          <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "600" }}>{actionLabel}</Text>
          <IconSymbol name="chevron.right" size={16} color={colors.primary} />
        </Pressable>
      ) : null}
    </View>
  );
}
