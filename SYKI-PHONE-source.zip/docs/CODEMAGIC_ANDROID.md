# Codemagic Android 빌드 안내

이 프로젝트는 `codemagic.yaml`로 **테스트용 APK**와 **Google Play용 AAB**를 만들 수 있습니다. Codemagic 계정·저장소 연결·빌드 실행은 프로젝트 소유자가 Codemagic 웹 화면에서 진행합니다.

| 워크플로 | 산출물 | 사용 시점 |
|---|---|---|
| `syki-android-apk` | APK + AAB | 내부 설치 테스트 또는 서명 설정 전 확인 |
| `syki-android-play` | 서명된 AAB | Google Play Console 업로드 |

## 최초 연결

1. [Codemagic](https://codemagic.io/start)에 로그인하고 GitHub·GitLab·Bitbucket 중 프로젝트 저장소를 연결합니다.
2. 앱을 추가한 뒤 저장소 루트의 `codemagic.yaml`을 스캔합니다.
3. 우선 `syki-android-apk`를 실행해 APK가 내려받아지는지 확인합니다.
4. Google Play 배포가 필요할 때만 아래 서명 설정을 완료하고 `syki-android-play`를 실행합니다.

## Google Play 서명 설정

`Team settings → codemagic.yaml settings → Code signing identities → Android keystores`에서 기존 Google Play 업로드 키를 업로드하고, 참조 이름을 **`syki-google-play`**로 지정합니다. 워크플로는 Codemagic이 제공하는 `CM_KEYSTORE_PATH`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS`, `CM_KEY_PASSWORD`를 빌드 중에만 사용하며 저장소에는 키나 비밀번호를 저장하지 않습니다.

> 기존에 Google Play에 올린 앱이 있다면 반드시 **같은 업로드 키**를 사용해야 합니다. 새 키로 서명하면 기존 앱 업데이트가 거부됩니다.

## 버전 코드

Google Play에 올리는 AAB는 이전 버전보다 큰 Android `versionCode`가 필요합니다. 첫 Codemagic AAB는 현재 설치 버전 21 다음 값인 **22**로 설정되어 있습니다. 이후 Google Play용 빌드마다 `ANDROID_VERSION_CODE`를 23, 24처럼 증가시켜 `codemagic.yaml`에 반영하세요.

## 참고 자료

- [Codemagic React Native 공식 가이드](https://docs.codemagic.io/yaml-quick-start/building-a-react-native-app/)
- [Expo 로컬 Android 빌드 가이드](https://docs.expo.dev/guides/local-app-development/)
