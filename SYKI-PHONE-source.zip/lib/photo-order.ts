/** 배열 항목을 지정한 위치로 이동한다. 유효하지 않은 위치면 원본 순서를 유지한다. */
export function moveArrayItem<T>(items: readonly T[], fromIndex: number, toIndex: number): T[] {
  if (
    fromIndex < 0 ||
    fromIndex >= items.length ||
    toIndex < 0 ||
    toIndex >= items.length ||
    fromIndex === toIndex
  ) {
    return [...items];
  }

  const reordered = [...items];
  const [moved] = reordered.splice(fromIndex, 1);
  reordered.splice(toIndex, 0, moved);
  return reordered;
}

/** 드래그한 사진의 이동 거리로 3열 사진 그리드에서의 놓을 위치를 계산한다. */
export function getPhotoDropIndex(
  sourceIndex: number,
  translationX: number,
  translationY: number,
  itemCount: number,
  columnCount: number,
  cellWidth: number,
  cellHeight: number,
): number {
  if (sourceIndex < 0 || sourceIndex >= itemCount || itemCount <= 0 || columnCount <= 0 || cellWidth <= 0 || cellHeight <= 0) {
    return sourceIndex;
  }

  const sourceRow = Math.floor(sourceIndex / columnCount);
  const sourceColumn = sourceIndex % columnCount;
  const targetRow = Math.max(0, sourceRow + Math.round(translationY / cellHeight));
  const targetColumn = Math.max(0, Math.min(columnCount - 1, sourceColumn + Math.round(translationX / cellWidth)));
  return Math.max(0, Math.min(itemCount - 1, targetRow * columnCount + targetColumn));
}
