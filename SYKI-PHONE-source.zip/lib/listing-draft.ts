import AsyncStorage from "@react-native-async-storage/async-storage";

import type { Grade } from "@/constants/types";

const DRAFT_KEY_PREFIX = "@syki/listing-draft";

export type ListingDraft = {
  version: 1;
  brand: string;
  model: string;
  storage: string;
  color: string;
  grade: Grade;
  battery: string;
  price: string;
  buyPrice: string;
  accessories: string;
  description: string;
  swatch: string;
  sold: boolean;
  photos: string[];
  savedAt: string;
};

export function getListingDraftKey(editId?: number | null): string {
  return editId && Number.isFinite(editId)
    ? `${DRAFT_KEY_PREFIX}:edit:${editId}`
    : `${DRAFT_KEY_PREFIX}:new`;
}

/** 기본값만 있는 완전히 빈 등록 폼은 별도로 보관하지 않는다. */
export function hasListingDraftContent(draft: Omit<ListingDraft, "version" | "savedAt">): boolean {
  return Boolean(
    draft.model.trim() ||
      draft.storage.trim() ||
      draft.color.trim() ||
      draft.price.trim() ||
      draft.buyPrice.trim() ||
      draft.description.trim() ||
      draft.photos.length ||
      draft.sold ||
      draft.brand !== "Apple" ||
      draft.grade !== "A" ||
      draft.battery !== "100" ||
      draft.accessories !== "본체만",
  );
}

export async function loadListingDraft(key: string): Promise<ListingDraft | null> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isListingDraft(parsed)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export async function saveListingDraft(key: string, draft: ListingDraft): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(draft));
}

export async function clearListingDraft(key: string): Promise<void> {
  await AsyncStorage.removeItem(key);
}

function isListingDraft(value: unknown): value is ListingDraft {
  if (!value || typeof value !== "object") return false;
  const draft = value as Partial<ListingDraft>;
  return (
    draft.version === 1 &&
    typeof draft.brand === "string" &&
    typeof draft.model === "string" &&
    typeof draft.storage === "string" &&
    typeof draft.color === "string" &&
    typeof draft.grade === "string" &&
    typeof draft.battery === "string" &&
    typeof draft.price === "string" &&
    typeof draft.buyPrice === "string" &&
    typeof draft.accessories === "string" &&
    typeof draft.description === "string" &&
    typeof draft.swatch === "string" &&
    typeof draft.sold === "boolean" &&
    Array.isArray(draft.photos) &&
    draft.photos.every((photo) => typeof photo === "string") &&
    typeof draft.savedAt === "string"
  );
}
