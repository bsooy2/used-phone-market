export const REVIEW_MIN_LENGTH = 10;
export const REVIEW_MAX_LENGTH = 1000;
export const REVIEW_MAX_PHOTOS = 3;
export const REVIEW_MAX_EDITS = 3;
export const PHOTO_REVIEW_REWARD_POINTS = 10_000;
export const REVIEW_MIN_RATING = 1;
export const REVIEW_MAX_RATING = 5;

export function validateReviewDraft(text: string, photoCount: number): string | null {
  const content = text.trim();
  if (content.length < REVIEW_MIN_LENGTH) return `후기를 ${REVIEW_MIN_LENGTH}자 이상 작성해 주세요.`;
  if (content.length > REVIEW_MAX_LENGTH) return `${REVIEW_MAX_LENGTH}자 이내로 작성해 주세요.`;
  if (!Number.isInteger(photoCount) || photoCount < 0 || photoCount > REVIEW_MAX_PHOTOS) {
    return `사진은 최대 ${REVIEW_MAX_PHOTOS}장까지 첨부 가능합니다.`;
  }
  return null;
}

export function canEditReview(editCount: number): boolean {
  return Number.isInteger(editCount) && editCount >= 0 && editCount < REVIEW_MAX_EDITS;
}

export function isPhotoReviewRewardEligible(photoCount: number): boolean {
  return Number.isInteger(photoCount) && photoCount > 0 && photoCount <= REVIEW_MAX_PHOTOS;
}

export function isValidReviewRating(rating: number): boolean {
  return Number.isInteger(rating) && rating >= REVIEW_MIN_RATING && rating <= REVIEW_MAX_RATING;
}
