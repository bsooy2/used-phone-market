import React, { createContext, useContext, useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { isEventVisible } from "@/lib/event-visibility";

export type Notice = {
  id: string;
  title: string;
  body: string;
  createdAt: string;
  pinned: boolean;
};

export type EventBanner = {
  id: string;
  title: string;
  imageUri: string; // 로컬 또는 S3 URL
  linkUrl?: string; // 탭 시 이동할 URL (선택)
  active: boolean;
  createdAt: string;
  startDate?: string; // ISO date string (유효기간 시작)
  endDate?: string;   // ISO date string (유효기간 종료)
  clickCount?: number;
  conversionCount?: number;
  performanceEvents?: BannerPerformanceEvent[];
};

export type BannerPerformanceEvent = {
  type: "tap" | "conversion";
  channel: "전화" | "웹" | "앱";
  occurredAt: string;
};

export const SYKI_BANNER_ASSETS: Record<string, number> = {
  "syki-ad-02": require("@/assets/images/syki-ads/02-store-location.jpg"),
  "syki-ad-03": require("@/assets/images/syki-ads/03-mobile-consulting.jpg"),
  "syki-ad-04": require("@/assets/images/syki-ads/04-services.jpg"),
};

/** 번들 광고 이미지 키 또는 원격 이미지 URL을 expo-image source로 변환한다. */
export function getBannerImageSource(imageUri: string): number | { uri: string } {
  return SYKI_BANNER_ASSETS[imageUri] ?? { uri: imageUri };
}

/** 고객이 전달한 이미지의 순서를 유지하는 홈 광고 기본 배너. */
const DEFAULT_SYKI_BANNERS: EventBanner[] = [
  { id: "syki-ad-02", title: "시끼폰 매장 위치", imageUri: "syki-ad-02", linkUrl: "tel:01023941420", active: true, createdAt: "2026-08-19T00:00:01.000Z" },
  { id: "syki-ad-03", title: "휴대폰 상담 시끼폰에서", imageUri: "syki-ad-03", linkUrl: "tel:01023941420", active: true, createdAt: "2026-08-19T00:00:02.000Z" },
  { id: "syki-ad-04", title: "생활에 필요한 다양한 서비스", imageUri: "syki-ad-04", linkUrl: "tel:01023941420", active: true, createdAt: "2026-08-19T00:00:03.000Z" },
];

type ContentStore = {
  notices: Notice[];
  banners: EventBanner[];
  addNotice: (title: string, body: string, pinned?: boolean) => void;
  updateNotice: (id: string, title: string, body: string, pinned?: boolean) => void;
  deleteNotice: (id: string) => void;
  addBanner: (title: string, imageUri: string, linkUrl?: string, startDate?: string, endDate?: string) => void;
  updateBanner: (id: string, updates: Partial<Pick<EventBanner, "title" | "imageUri" | "linkUrl" | "active" | "startDate" | "endDate">>) => void;
  deleteBanner: (id: string) => void;
  recordBannerClick: (id: string) => void;
  recordBannerConversion: (id: string) => void;
  /** 유효기간 내 활성 배너만 반환 */
  activeBanners: EventBanner[];
};

const NOTICES_KEY = "@syki/notices";
const BANNERS_KEY = "@syki/banners";

const ContentContext = createContext<ContentStore | null>(null);

export function ContentProvider({ children }: { children: React.ReactNode }) {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [banners, setBanners] = useState<EventBanner[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const nRaw = await AsyncStorage.getItem(NOTICES_KEY);
        if (nRaw) setNotices(JSON.parse(nRaw));
        const bRaw = await AsyncStorage.getItem(BANNERS_KEY);
        const savedBanners: EventBanner[] = (bRaw ? JSON.parse(bRaw) : []).filter((banner: EventBanner) => banner.id !== "syki-ad-01");
        const savedById = new Map(savedBanners.map((banner) => [banner.id, banner]));
        const defaultIds = new Set(DEFAULT_SYKI_BANNERS.map((banner) => banner.id));
        const mergedBanners = [
          ...DEFAULT_SYKI_BANNERS.map((banner) => savedById.get(banner.id) ?? banner),
          ...savedBanners.filter((banner) => !defaultIds.has(banner.id)),
        ];
        setBanners(mergedBanners);
        if (!bRaw || mergedBanners.length !== savedBanners.length) await AsyncStorage.setItem(BANNERS_KEY, JSON.stringify(mergedBanners));
      } catch {}
    })();
  }, []);

  const persist = async (n: Notice[], b: EventBanner[]) => {
    await AsyncStorage.setItem(NOTICES_KEY, JSON.stringify(n));
    await AsyncStorage.setItem(BANNERS_KEY, JSON.stringify(b));
  };

  const addNotice: ContentStore["addNotice"] = (title, body, pinned = false) => {
    const n: Notice = { id: `n_${Date.now()}`, title, body, createdAt: new Date().toISOString(), pinned };
    const updated = [n, ...notices];
    setNotices(updated);
    persist(updated, banners);
  };

  const updateNotice: ContentStore["updateNotice"] = (id, title, body, pinned) => {
    const updated = notices.map((n) => n.id === id ? { ...n, title, body, pinned: pinned ?? n.pinned } : n);
    setNotices(updated);
    persist(updated, banners);
  };

  const deleteNotice: ContentStore["deleteNotice"] = (id) => {
    const updated = notices.filter((n) => n.id !== id);
    setNotices(updated);
    persist(updated, banners);
  };

  const addBanner: ContentStore["addBanner"] = (title, imageUri, linkUrl, startDate, endDate) => {
    const b: EventBanner = { id: `b_${Date.now()}`, title, imageUri, linkUrl, active: true, createdAt: new Date().toISOString(), startDate, endDate };
    const updated = [b, ...banners];
    setBanners(updated);
    persist(notices, updated);
  };

  const updateBanner: ContentStore["updateBanner"] = (id, updates) => {
    const updated = banners.map((b) => b.id === id ? { ...b, ...updates } : b);
    setBanners(updated);
    persist(notices, updated);
  };

  const deleteBanner: ContentStore["deleteBanner"] = (id) => {
    const updated = banners.filter((b) => b.id !== id);
    setBanners(updated);
    persist(notices, updated);
  };

  const recordBannerClick: ContentStore["recordBannerClick"] = (id) => {
    const updated = banners.map((banner) => banner.id === id ? appendPerformanceEvent(banner, "tap") : banner);
    setBanners(updated);
    persist(notices, updated);
  };

  const recordBannerConversion: ContentStore["recordBannerConversion"] = (id) => {
    const updated = banners.map((banner) => banner.id === id ? appendPerformanceEvent(banner, "conversion") : banner);
    setBanners(updated);
    persist(notices, updated);
  };

  const now = new Date();
  const activeBannersFiltered = banners.filter((b) => isEventVisible(b, now));

  return (
    <ContentContext.Provider value={{ notices, banners, addNotice, updateNotice, deleteNotice, addBanner, updateBanner, deleteBanner, recordBannerClick, recordBannerConversion, activeBanners: activeBannersFiltered }}>
      {children}
    </ContentContext.Provider>
  );
}

function getBannerChannel(linkUrl?: string): BannerPerformanceEvent["channel"] {
  if (linkUrl?.startsWith("tel:")) return "전화";
  if (linkUrl?.startsWith("http:") || linkUrl?.startsWith("https:")) return "웹";
  return "앱";
}

function appendPerformanceEvent(banner: EventBanner, type: BannerPerformanceEvent["type"]): EventBanner {
  const event: BannerPerformanceEvent = { type, channel: getBannerChannel(banner.linkUrl), occurredAt: new Date().toISOString() };
  const performanceEvents = [...(banner.performanceEvents ?? []), event].slice(-500);
  return {
    ...banner,
    clickCount: type === "tap" ? (banner.clickCount ?? 0) + 1 : banner.clickCount,
    conversionCount: type === "conversion" ? (banner.conversionCount ?? 0) + 1 : banner.conversionCount,
    performanceEvents,
  };
}

export function useContentStore(): ContentStore {
  const ctx = useContext(ContentContext);
  if (!ctx) throw new Error("useContentStore must be used within ContentProvider");
  return ctx;
}
