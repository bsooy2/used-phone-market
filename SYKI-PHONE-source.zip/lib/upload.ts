/**
 * 매물 사진 서버 스토리지(S3) 업로드 헬퍼.
 *
 * 서버의 storageProxy를 통해 S3에 파일을 업로드하고 공개 URL을 반환합니다.
 * 로컬 URI(file://)를 서버 URL로 변환하여 다른 기기에서도 사진이 보이도록 합니다.
 */

import { Platform } from "react-native";

const API_BASE = (
  process.env.EXPO_PUBLIC_API_BASE_URL ||
  process.env.EXPO_PUBLIC_API_URL ||
  "https://usedphonemkt-98grbfe4.manus.space"
).replace(/\/$/, "");

/**
 * 로컬 이미지 URI를 서버에 업로드하고 공개 URL을 반환합니다.
 * @param localUri - 로컬 파일 URI (file:// 또는 content://)
 * @returns 업로드된 파일의 공개 URL
 */
export async function uploadImage(localUri: string): Promise<string> {
  // 이미 http URL이면 그대로 반환
  if (localUri.startsWith("http://") || localUri.startsWith("https://")) {
    return localUri;
  }

  const filename = localUri.split("/").pop() || `photo_${Date.now()}.jpg`;
  const match = /\.(\w+)$/.exec(filename);
  const type = match ? `image/${match[1]}` : "image/jpeg";

  const formData = new FormData();
  if (Platform.OS === "web") {
    // 웹: fetch로 blob 변환 후 업로드
    const response = await fetch(localUri);
    const blob = await response.blob();
    formData.append("file", blob, filename);
  } else {
    // 네이티브: URI 직접 전달
    formData.append("file", {
      uri: localUri,
      name: filename,
      type,
    } as any);
  }

  const uploadRes = await fetch(`${API_BASE}/api/storage/upload`, {
    method: "POST",
    body: formData,
  });

  if (!uploadRes.ok) {
    throw new Error(`업로드 실패: ${uploadRes.status}`);
  }

  const data = await uploadRes.json();
  return data.url;
}

/**
 * 여러 로컬 이미지를 순차적으로 업로드합니다.
 * @param localUris - 로컬 URI 배열
 * @returns 업로드된 URL 배열
 */
export async function uploadImages(localUris: string[]): Promise<string[]> {
  return Promise.all(localUris.map(uploadImage));
}
