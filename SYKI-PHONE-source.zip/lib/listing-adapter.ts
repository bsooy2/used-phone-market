import { Grade, Phone } from "@/constants/types";

/** 서버 listings 테이블 행 형태 (tRPC 반환 타입과 동일 구조) */
export type ServerListing = {
  id: number;
  brand: string;
  model: string;
  storage: string;
  color: string;
  grade: Grade;
  battery: number;
  price: number;
  buyPrice: number;
  image: string;
  photos?: string | null;
  description: string | null;
  accessories: string;
  sold: number;
  viewCount?: number;
  favoriteCount?: number;
  createdAt: string | Date;
  updatedAt: string | Date;
};

/**
 * 소비자 표시가는 서버(관리자)에 저장된 원본 가격을 그대로 사용한다.
 * (이전의 20% 인하 정책은 제거됨)
 */
export const CONSUMER_PRICE_RATE = 1;

/** 소비자 표시가 계산 (현재는 원본가 그대로) */
export function toConsumerPrice(price: number): number {
  return price;
}

function toDateString(value: string | Date): string {
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toISOString().slice(0, 10);
}

/** DB의 JSON 문자열 사진 목록을 앱에서 안전하게 사용할 수 있는 URI 배열로 변환한다. */
export function parseListingPhotos(value?: string | null): string[] {
  if (!value) return [];

  try {
    const parsed: unknown = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((photo): photo is string => typeof photo === "string" && photo.trim().length > 0);
  } catch {
    return [];
  }
}

/**
 * 서버 매물(Listing)을 앱 내부에서 쓰는 Phone 타입으로 변환한다.
 * id는 문자열 "srv_{id}" 형태로 통일하여 즐겨찾기/주문 등 기존 로직과 호환시킨다.
 */
export function serverListingToPhone(l: ServerListing): Phone {
  return {
    id: `srv_${l.id}`,
    brand: l.brand,
    model: l.model,
    storage: l.storage,
    color: l.color,
    grade: l.grade,
    battery: l.battery,
    price: toConsumerPrice(l.price),
    buyPrice: l.buyPrice,
    image: l.image,
    photos: parseListingPhotos(l.photos),
    description: l.description ?? "",
    accessories: l.accessories,
    createdAt: toDateString(l.createdAt),
    sellerId: undefined, // 서버 매물 = 공식(매장) 매물
    sellerName: "시끼폰",
    viewCount: l.viewCount ?? 0,
    favoriteCount: l.favoriteCount ?? 0,
  };
}

/** Phone id("srv_3")에서 서버 숫자 id(3)를 추출. 서버 매물이 아니면 null */
export function phoneIdToServerId(phoneId: string): number | null {
  if (!phoneId.startsWith("srv_")) return null;
  const n = Number(phoneId.slice(4));
  return Number.isFinite(n) ? n : null;
}

export function mapServerListings(rows: ServerListing[]): Phone[] {
  return rows.map(serverListingToPhone);
}
