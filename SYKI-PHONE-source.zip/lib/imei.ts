/**
 * IMEI 유틸리티
 * - 15자리 형식 검증 (Luhn 알고리즘)
 * - TAC(Type Allocation Code) 기반 기기 정보 추출
 */

/**
 * IMEI 15자리 숫자인지 기본 형식 확인
 */
export function isValidImeiFormat(imei: string): boolean {
  return /^\d{15}$/.test(imei.replace(/[\s-]/g, ""));
}

/**
 * Luhn 체크섬 검증 (IMEI 유효성)
 */
export function validateImeiLuhn(imei: string): boolean {
  const cleaned = imei.replace(/[\s-]/g, "");
  if (!isValidImeiFormat(cleaned)) return false;

  let sum = 0;
  for (let i = 0; i < 15; i++) {
    let digit = parseInt(cleaned[i], 10);
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
  }
  return sum % 10 === 0;
}

/**
 * TAC (처음 8자리)에서 기기 정보 추출
 * 실제 서비스에서는 API를 호출하지만, 오프라인 폴백용 주요 모델 매핑
 */
const TAC_DATABASE: Record<string, { brand: string; model: string }> = {
  // Apple iPhone
  "35332211": { brand: "Apple", model: "iPhone 15 Pro Max" },
  "35332210": { brand: "Apple", model: "iPhone 15 Pro" },
  "35407115": { brand: "Apple", model: "iPhone 15 Pro" },
  "35391112": { brand: "Apple", model: "iPhone 15" },
  "35391111": { brand: "Apple", model: "iPhone 15 Plus" },
  "35325611": { brand: "Apple", model: "iPhone 14 Pro Max" },
  "35325610": { brand: "Apple", model: "iPhone 14 Pro" },
  "35322313": { brand: "Apple", model: "iPhone 14" },
  "35322312": { brand: "Apple", model: "iPhone 14 Plus" },
  "35397514": { brand: "Apple", model: "iPhone 13 Pro Max" },
  "35397513": { brand: "Apple", model: "iPhone 13 Pro" },
  "35397512": { brand: "Apple", model: "iPhone 13" },
  "35397511": { brand: "Apple", model: "iPhone 13 mini" },
  "35395211": { brand: "Apple", model: "iPhone 12 Pro Max" },
  "35395210": { brand: "Apple", model: "iPhone 12 Pro" },
  "35395209": { brand: "Apple", model: "iPhone 12" },
  "35694911": { brand: "Apple", model: "iPhone 11 Pro Max" },
  "35694910": { brand: "Apple", model: "iPhone 11 Pro" },
  "35694909": { brand: "Apple", model: "iPhone 11" },
  // Samsung Galaxy S
  "35256715": { brand: "Samsung", model: "Galaxy S24 Ultra" },
  "35256714": { brand: "Samsung", model: "Galaxy S24+" },
  "35256713": { brand: "Samsung", model: "Galaxy S24" },
  "35454612": { brand: "Samsung", model: "Galaxy S23 Ultra" },
  "35454611": { brand: "Samsung", model: "Galaxy S23+" },
  "35454610": { brand: "Samsung", model: "Galaxy S23" },
  "35327510": { brand: "Samsung", model: "Galaxy S22 Ultra" },
  "35327509": { brand: "Samsung", model: "Galaxy S22+" },
  "35327508": { brand: "Samsung", model: "Galaxy S22" },
  // Samsung Galaxy Z
  "35966115": { brand: "Samsung", model: "Galaxy Z Flip5" },
  "35966114": { brand: "Samsung", model: "Galaxy Z Fold5" },
  "35966113": { brand: "Samsung", model: "Galaxy Z Flip4" },
  "35966112": { brand: "Samsung", model: "Galaxy Z Fold4" },
  // Samsung Galaxy A
  "35291612": { brand: "Samsung", model: "Galaxy A54" },
  "35291611": { brand: "Samsung", model: "Galaxy A34" },
};

export type ImeiDeviceInfo = {
  brand: string;
  model: string;
  source: "local" | "api";
};

/**
 * TAC 로컬 DB에서 기기 정보 조회
 */
export function lookupDeviceByTac(imei: string): ImeiDeviceInfo | null {
  const cleaned = imei.replace(/[\s-]/g, "");
  if (cleaned.length < 8) return null;
  const tac = cleaned.slice(0, 8);
  const info = TAC_DATABASE[tac];
  if (info) return { ...info, source: "local" };
  return null;
}

/**
 * IMEI 전체 검증 결과
 */
export type ImeiValidation = {
  isValid: boolean;
  isFormatValid: boolean;
  isLuhnValid: boolean;
  deviceInfo: ImeiDeviceInfo | null;
  errorMessage?: string;
};

export function validateImei(imei: string): ImeiValidation {
  const cleaned = imei.replace(/[\s-]/g, "");

  if (!cleaned) {
    return { isValid: false, isFormatValid: false, isLuhnValid: false, deviceInfo: null, errorMessage: "IMEI를 입력해 주세요." };
  }

  if (!/^\d+$/.test(cleaned)) {
    return { isValid: false, isFormatValid: false, isLuhnValid: false, deviceInfo: null, errorMessage: "숫자만 입력 가능합니다." };
  }

  if (cleaned.length !== 15) {
    return { isValid: false, isFormatValid: false, isLuhnValid: false, deviceInfo: null, errorMessage: `15자리를 입력해 주세요. (현재 ${cleaned.length}자리)` };
  }

  const isLuhnValid = validateImeiLuhn(cleaned);
  const deviceInfo = lookupDeviceByTac(cleaned);

  if (!isLuhnValid) {
    return { isValid: false, isFormatValid: true, isLuhnValid: false, deviceInfo, errorMessage: "유효하지 않은 IMEI입니다. 다시 확인해 주세요." };
  }

  return { isValid: true, isFormatValid: true, isLuhnValid: true, deviceInfo };
}

/**
 * 분실폰 확인 안내 링크 목록
 */
export const LOST_PHONE_CHECK_LINKS = [
  {
    name: "경찰청 분실폰 찾기",
    url: "https://www.lost112.go.kr",
    description: "경찰청 유실물 통합 포털에서 분실 신고 여부를 확인할 수 있습니다.",
  },
  {
    name: "한국정보통신진흥협회 (IMEI 조회)",
    url: "https://www.kait.or.kr",
    description: "단말기 자급제 확인 및 IMEI 정보를 조회할 수 있습니다.",
  },
  {
    name: "SKT 분실폰 조회",
    url: "https://www.tworld.co.kr",
    description: "SKT 고객센터(114)에서 분실 등록 여부를 확인하세요.",
  },
  {
    name: "KT 분실폰 조회",
    url: "https://www.kt.com",
    description: "KT 고객센터(100)에서 분실 등록 여부를 확인하세요.",
  },
  {
    name: "LGU+ 분실폰 조회",
    url: "https://www.lguplus.com",
    description: "LGU+ 고객센터(114)에서 분실 등록 여부를 확인하세요.",
  },
];
