import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

const ADMIN_PIN_KEY = "@syki/admin_pin";

type AdminStore = {
  /** 현재 관리자 모드 활성화 여부 */
  isAdmin: boolean;
  /** 저장된 PIN (이후 mutation 호출 시 서버 검증에 사용) */
  pin: string | null;
  /** 관리자 모드 진입 (검증된 PIN 저장) */
  enableAdmin: (pin: string) => Promise<void>;
  /** 관리자 모드 해제 */
  disableAdmin: () => Promise<void>;
  loaded: boolean;
};

const AdminContext = createContext<AdminStore | null>(null);

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const [pin, setPin] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(ADMIN_PIN_KEY);
        if (saved) setPin(saved);
      } catch {
        // ignore
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const enableAdmin = async (newPin: string) => {
    setPin(newPin);
    await AsyncStorage.setItem(ADMIN_PIN_KEY, newPin);
  };

  const disableAdmin = async () => {
    setPin(null);
    await AsyncStorage.removeItem(ADMIN_PIN_KEY);
  };

  const value: AdminStore = {
    isAdmin: !!pin,
    pin,
    enableAdmin,
    disableAdmin,
    loaded,
  };

  return <AdminContext.Provider value={value}>{children}</AdminContext.Provider>;
}

export function useAdminStore(): AdminStore {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdminStore must be used within AdminProvider");
  return ctx;
}
