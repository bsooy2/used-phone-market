import { IPHONE_MODELS } from "@/constants/buyback-data";
import type { BuybackModel } from "@/constants/buyback-data";
import { SAMSUNG_MODELS } from "@/constants/buyback-data-samsung";

/**
 * 모델명과 용량·등급으로 매입 시세 기반 판매 추천 가격을 계산합니다.
 * 매입가의 1.2~1.5배를 판매 추천가로 제시합니다.
 */
export function suggestPrice(model: string, storage: string, grade: string): { min: number; max: number; buyback: number } | null {
  const allModels: BuybackModel[] = [...IPHONE_MODELS, ...SAMSUNG_MODELS];

  // 모델명 부분 매칭 (대소문자 무시)
  const normalizedModel = model.toLowerCase().replace(/\s+/g, "");
  const found = allModels.find((m) => {
    const mName = m.model.toLowerCase().replace(/\s+/g, "");
    return normalizedModel.includes(mName) || mName.includes(normalizedModel);
  });

  if (!found) return null;

  // 용량 매칭
  const storageKey = storage.replace(/\s/g, "").toUpperCase();
  const storageEntry = found.variants.find((v) => v.storage.replace(/\s/g, "").toUpperCase() === storageKey);
  if (!storageEntry) return null;

  // 등급 매칭 (S→A, A→A, B→B+, C→B)
  const gradeMap: Record<string, string> = { S: "A", A: "A", B: "B+", C: "B" };
  const mappedGrade = gradeMap[grade.toUpperCase()] ?? "A";
  const prices = storageEntry.prices;
  const gradeKeyMap: Record<string, keyof typeof prices> = { A: "A", "A-": "Aminus", "B+": "Bplus", B: "B" };
  const priceKey = gradeKeyMap[mappedGrade] ?? "A";
  const buyback = prices[priceKey] ?? 0;

  if (buyback <= 0) return null;
  return {
    buyback,
    min: Math.round(buyback * 1.2 / 10000) * 10000, // 1.2배, 만원 단위 반올림
    max: Math.round(buyback * 1.5 / 10000) * 10000, // 1.5배
  };
}
