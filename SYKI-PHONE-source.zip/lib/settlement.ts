/**
 * 판매자 정산 계산 순수 로직.
 * settlement.tsx 화면과 단위 테스트가 동일한 로직을 공유한다.
 */
import { AppNotification, Order, Phone } from "@/constants/types";

// 플랫폼 정산 수수료율 (데모 기준 3.5%)
export const FEE_RATE = 0.035;

export type SettleRow = {
  phone: Phone;
  sold: boolean;
  gross: number;
  fee: number;
  net: number;
};

export type SettleSummary = {
  listingCount: number;
  soldCount: number;
  gross: number;
  fee: number;
  net: number;
};

/** 단일 매물의 정산 행을 계산한다. */
export function calcRow(phone: Phone, soldProductIds: Set<string>): SettleRow {
  const sold = soldProductIds.has(phone.id);
  const gross = sold ? phone.price : 0;
  const fee = Math.round(gross * FEE_RATE);
  return { phone, sold, gross, fee, net: gross - fee };
}

/** 판매자의 매물 목록과 주문 목록으로부터 정산 행 배열을 만든다. */
export function buildSettleRows(listings: Phone[], orders: Order[]): SettleRow[] {
  const soldProductIds = new Set(orders.map((o) => o.productId));
  return listings.map((phone) => calcRow(phone, soldProductIds));
}

/** 정산 행 배열을 요약(합계)한다. */
export function summarize(rows: SettleRow[]): SettleSummary {
  const soldRows = rows.filter((r) => r.sold);
  const gross = soldRows.reduce((s, r) => s + r.gross, 0);
  const fee = soldRows.reduce((s, r) => s + r.fee, 0);
  return {
    listingCount: rows.length,
    soldCount: soldRows.length,
    gross,
    fee,
    net: gross - fee,
  };
}

/** 특정 사용자의 미읽음 알림 개수를 센다. */
export function countUnread(notifications: AppNotification[], userId: string): number {
  return notifications.filter((n) => n.userId === userId && !n.read).length;
}

/** 특정 사용자에게 속한 알림만 필터링한다. */
export function notificationsForUser(notifications: AppNotification[], userId: string): AppNotification[] {
  return notifications.filter((n) => n.userId === userId);
}
