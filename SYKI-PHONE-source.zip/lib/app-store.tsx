import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useReducer } from "react";

import { AppNotification, Order, Phone, SellRequest } from "@/constants/types";
import { mapServerListings, phoneIdToServerId } from "@/lib/listing-adapter";
import { archiveSellRequests, deleteSellRequests, restoreSellRequests } from "@/lib/sell-request-management";
import { trpc } from "@/lib/trpc";
import { FavoriteAlertPreference, getFavoriteAlertSignals } from "@/lib/favorite-alerts";

const SELL_KEY = "@upm/sell_requests";
const FAV_KEY = "@upm/favorites";
const LISTING_KEY = "@upm/user_listings";
const ORDER_KEY = "@upm/orders";
const NOTI_KEY = "@upm/notifications";
const FAV_ALERT_KEY = "@syki/favorite_alerts";

const ORDER_STATUS_FLOW: Order["status"][] = ["결제완료", "배송준비", "배송중", "배송완료"];

/** 관리자(사장님) 전용 알림 수신 식별자. 관리자 모드에서 이 ID로 오는 알림을 분다. */
export const ADMIN_USER_ID = "__admin__";

/** 원(좌)/만원 금액을 "12만원" 형태로 간단 표기 */
function wonToManwonLabel(won: number): string {
  const manwon = Math.round((won / 10000) * 10) / 10;
  return `${manwon}만원`;
}

function makeId(prefix: string) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

type State = {
  sellRequests: SellRequest[];
  favorites: string[]; // phone ids
  userListings: Phone[]; // 판매자가 등록한 매물
  orders: Order[]; // 구매자 주문 내역
  notifications: AppNotification[]; // 앱 내 알림함
  favoriteAlerts: Record<string, FavoriteAlertPreference>;
  loaded: boolean;
};

type Action =
  | { type: "load"; sellRequests: SellRequest[]; favorites: string[]; userListings: Phone[]; orders: Order[]; notifications: AppNotification[]; favoriteAlerts: Record<string, FavoriteAlertPreference> }
  | { type: "addSell"; request: SellRequest }
  | { type: "toggleFav"; id: string }
  | { type: "addListing"; phone: Phone }
  | { type: "removeListing"; id: string }
  | { type: "addOrder"; order: Order }
  | { type: "updateOrderStatus"; id: string; status: Order["status"] }
  | { type: "updateSellStatus"; id: string; status: SellRequest["status"] }
  | { type: "archiveSells"; ids: string[]; archivedAt: string }
  | { type: "restoreSells"; ids: string[] }
  | { type: "deleteSells"; ids: string[] }
  | { type: "addNotification"; notification: AppNotification }
  | { type: "markNotiRead"; id: string }
  | { type: "markAllNotiRead"; userId: string }
  | { type: "setFavAlert"; id: string; preference: FavoriteAlertPreference };

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "load":
      return {
        ...state,
        sellRequests: action.sellRequests,
        favorites: action.favorites,
        userListings: action.userListings,
        orders: action.orders,
        notifications: action.notifications,
        favoriteAlerts: action.favoriteAlerts,
        loaded: true,
      };
    case "addSell":
      return { ...state, sellRequests: [action.request, ...state.sellRequests] };
    case "toggleFav": {
      const exists = state.favorites.includes(action.id);
      return {
        ...state,
        favorites: exists
          ? state.favorites.filter((f) => f !== action.id)
          : [action.id, ...state.favorites],
      };
    }
    case "addListing":
      return { ...state, userListings: [action.phone, ...state.userListings] };
    case "removeListing":
      return {
        ...state,
        userListings: state.userListings.filter((p) => p.id !== action.id),
      };
    case "addOrder":
      return { ...state, orders: [action.order, ...state.orders] };
    case "updateOrderStatus":
      return {
        ...state,
        orders: state.orders.map((o) => (o.id === action.id ? { ...o, status: action.status } : o)),
      };
    case "updateSellStatus":
      return {
        ...state,
        sellRequests: state.sellRequests.map((r) => (r.id === action.id ? { ...r, status: action.status } : r)),
      };
    case "archiveSells":
      return { ...state, sellRequests: archiveSellRequests(state.sellRequests, action.ids, action.archivedAt) };
    case "restoreSells":
      return { ...state, sellRequests: restoreSellRequests(state.sellRequests, action.ids) };
    case "deleteSells": {
      const deletedIds = new Set(action.ids);
      return {
        ...state,
        sellRequests: deleteSellRequests(state.sellRequests, action.ids),
        notifications: state.notifications.filter((notification) => !notification.refId || !deletedIds.has(notification.refId)),
      };
    }
    case "addNotification":
      return { ...state, notifications: [action.notification, ...state.notifications] };
    case "markNotiRead":
      return {
        ...state,
        notifications: state.notifications.map((n) => (n.id === action.id ? { ...n, read: true } : n)),
      };
    case "markAllNotiRead":
      return {
        ...state,
        notifications: state.notifications.map((n) => (n.userId === action.userId ? { ...n, read: true } : n)),
      };
    case "setFavAlert":
      return { ...state, favoriteAlerts: { ...state.favoriteAlerts, [action.id]: action.preference } };
    default:
      return state;
  }
}

type AppStore = State & {
  /** 서버 매물 + 사용자 등록 매물 통합 목록 */
  allPhones: Phone[];
  /** 서버 매물 로딩 상태 */
  listingsLoading: boolean;
  /** 서버 매물 요청 실패 여부 */
  listingsError: boolean;
  /** 서버 매물 요청 진행 여부(최초 로딩 및 수동 재시도 포함) */
  listingsRefreshing: boolean;
  /** 서버 매물 다시 불러오기 */
  refetchListings: () => void;
  addSellRequest: (request: SellRequest) => void;
  /** 견적 상태 변경 (관리자 전용) + 고객 알림 발송 */
  advanceSellStatus: (id: string) => void;
  /** 선택한 견적 신청을 관리자 보관함으로 이동 */
  archiveSellRequests: (ids: string[]) => void;
  /** 보관한 견적 신청을 일반 목록으로 복원 */
  restoreSellRequests: (ids: string[]) => void;
  /** 선택한 견적 신청과 관련 알림을 영구 삭제 */
  deleteSellRequests: (ids: string[]) => void;
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  /** 공식 매물 상세 조회를 공유 통계에 기록 */
  recordListingView: (id: string) => void;
  /** 공식 매물 찜/해제를 공유 통계에 기록 */
  recordListingFavorite: (id: string, active: boolean) => void;
  addListing: (phone: Phone) => void;
  removeListing: (id: string) => void;
  getPhoneById: (id: string) => Phone | undefined;
  addOrder: (order: Order) => void;
  advanceOrderStatus: (id: string) => void;
  pushNotification: (n: Omit<AppNotification, "id" | "read" | "createdAt">) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: (userId: string) => void;
  notificationsFor: (userId: string) => AppNotification[];
  unreadCount: (userId: string) => number;
  setFavoriteAlert: (id: string, preference: Pick<FavoriteAlertPreference, "priceDrop" | "lowStock">) => void;
  getFavoriteAlert: (id: string) => FavoriteAlertPreference | undefined;
};

const AppStoreContext = createContext<AppStore | null>(null);

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, {
    sellRequests: [],
    favorites: [],
    userListings: [],
    orders: [],
    notifications: [],
    favoriteAlerts: {},
    loaded: false,
  });

  useEffect(() => {
    (async () => {
      try {
        const [sellRaw, favRaw, listingRaw, orderRaw, notiRaw, favAlertRaw] = await Promise.all([
          AsyncStorage.getItem(SELL_KEY),
          AsyncStorage.getItem(FAV_KEY),
          AsyncStorage.getItem(LISTING_KEY),
          AsyncStorage.getItem(ORDER_KEY),
          AsyncStorage.getItem(NOTI_KEY),
          AsyncStorage.getItem(FAV_ALERT_KEY),
        ]);
        dispatch({
          type: "load",
          sellRequests: sellRaw ? JSON.parse(sellRaw) : [],
          favorites: favRaw ? JSON.parse(favRaw) : [],
          userListings: listingRaw ? JSON.parse(listingRaw) : [],
          orders: orderRaw ? JSON.parse(orderRaw) : [],
          notifications: notiRaw ? JSON.parse(notiRaw) : [],
          favoriteAlerts: favAlertRaw ? JSON.parse(favAlertRaw) : {},
        });
      } catch {
        dispatch({ type: "load", sellRequests: [], favorites: [], userListings: [], orders: [], notifications: [], favoriteAlerts: {} });
      }
    })();
  }, []);

  // 영속화
  useEffect(() => {
    if (state.loaded) {
      AsyncStorage.setItem(SELL_KEY, JSON.stringify(state.sellRequests)).catch(() => {});
    }
  }, [state.sellRequests, state.loaded]);

  useEffect(() => {
    if (state.loaded) {
      AsyncStorage.setItem(FAV_KEY, JSON.stringify(state.favorites)).catch(() => {});
    }
  }, [state.favorites, state.loaded]);

  useEffect(() => {
    if (state.loaded) {
      AsyncStorage.setItem(LISTING_KEY, JSON.stringify(state.userListings)).catch(() => {});
    }
  }, [state.userListings, state.loaded]);

  useEffect(() => {
    if (state.loaded) {
      AsyncStorage.setItem(ORDER_KEY, JSON.stringify(state.orders)).catch(() => {});
    }
  }, [state.orders, state.loaded]);

  useEffect(() => {
    if (state.loaded) {
      AsyncStorage.setItem(NOTI_KEY, JSON.stringify(state.notifications)).catch(() => {});
    }
  }, [state.notifications, state.loaded]);

  useEffect(() => {
    if (state.loaded) {
      AsyncStorage.setItem(FAV_ALERT_KEY, JSON.stringify(state.favoriteAlerts)).catch(() => {});
    }
  }, [state.favoriteAlerts, state.loaded]);

  // 서버에서 매물 목록을 가져온다 (모든 사용자 공유)
  const listingsQuery = trpc.listings.list.useQuery(undefined, {
    staleTime: 1000 * 30,
  });
  const recordViewMutation = trpc.listings.recordView.useMutation({
    onSuccess: () => { void listingsQuery.refetch(); },
  });
  const recordFavoriteMutation = trpc.listings.recordFavorite.useMutation({
    onSuccess: () => { void listingsQuery.refetch(); },
  });

  const serverPhones: Phone[] = useMemo(
    () => (listingsQuery.data ? mapServerListings(listingsQuery.data as any) : []),
    [listingsQuery.data],
  );

  // 사용자 등록(로컬) 매물을 앞에, 서버(매장) 매물을 뒤에 배치
  const allPhones: Phone[] = [...state.userListings, ...serverPhones];

  useEffect(() => {
    if (!state.loaded) return;
    state.favorites.forEach((id) => {
      const listing = allPhones.find((phone) => phone.id === id);
      const preference = state.favoriteAlerts[id];
      if (!listing || !preference) return;
      const signals = getFavoriteAlertSignals(listing, preference);
      if (signals.length === 0) return;

      dispatch({
        type: "setFavAlert",
        id,
        preference: {
          ...preference,
          lastPriceAlertedPrice: signals.includes("priceDrop") ? listing.price : preference.lastPriceAlertedPrice,
          lowStockAlerted: signals.includes("lowStock") ? true : preference.lowStockAlerted,
        },
      });
      signals.forEach((signal) => {
        dispatch({
          type: "addNotification",
          notification: {
            id: makeId("noti"),
            kind: "system",
            title: signal === "priceDrop" ? "찜한 매물의 가격이 인하되었어요" : "찜한 매물이 품절 임박이에요",
            body: signal === "priceDrop" ? `${listing.model} · 현재 ${listing.price.toLocaleString()}원` : `${listing.model} · 찜한 고객이 많아 빠른 확인을 권장합니다.`,
            userId: "__customer__",
            refId: listing.id,
            read: false,
            createdAt: new Date().toISOString(),
          },
        });
      });
    });
  }, [allPhones, state.favoriteAlerts, state.favorites, state.loaded]);

  const value: AppStore = {
    ...state,
    allPhones,
    listingsLoading: listingsQuery.isLoading,
    listingsError: listingsQuery.isError,
    listingsRefreshing: listingsQuery.isFetching,
    refetchListings: () => {
      void listingsQuery.refetch();
    },
    addSellRequest: (request) => {
      dispatch({ type: "addSell", request });
      // 관리자(사장님)에게 신규 견적 신청 알림 생성
      const conds =
        request.conditionLabels && request.conditionLabels.length > 0
          ? ` · ${request.conditionLabels.join(", ")}`
          : "";
      dispatch({
        type: "addNotification",
        notification: {
          id: makeId("noti"),
          kind: "sell",
          title: "새 매입 견적 신청이 도착했어요",
          body: `${request.model} ${request.storage} ${request.gradeLabel ?? ""} · 예상 ${wonToManwonLabel(request.estimatedPrice)}${conds}`,
          userId: ADMIN_USER_ID,
          refId: request.id,
          read: false,
          createdAt: new Date().toISOString(),
        },
      });
    },
    advanceSellStatus: (id) => {
      const req = state.sellRequests.find((r) => r.id === id);
      if (!req) return;
      const SELL_STATUS_FLOW: SellRequest["status"][] = ["접수", "검수중", "입금완료"];
      const idx = SELL_STATUS_FLOW.indexOf(req.status);
      if (idx < 0 || idx >= SELL_STATUS_FLOW.length - 1) return;
      const next = SELL_STATUS_FLOW[idx + 1];
      dispatch({ type: "updateSellStatus", id, status: next });
      // 고객(신청자)에게 알림 발송 — userId는 고객 식별자로 "__customer__" 사용
      dispatch({
        type: "addNotification",
        notification: {
          id: makeId("noti"),
          kind: "sell",
          title: "매입 견적 상태가 변경되었어요",
          body: `${req.model} ${req.storage} · ${next} 상태로 변경되었습니다.`,
          userId: "__customer__",
          refId: req.id,
          read: false,
          createdAt: new Date().toISOString(),
        },
      });
    },
    archiveSellRequests: (ids) => {
      if (ids.length === 0) return;
      dispatch({ type: "archiveSells", ids, archivedAt: new Date().toISOString() });
    },
    restoreSellRequests: (ids) => {
      if (ids.length === 0) return;
      dispatch({ type: "restoreSells", ids });
    },
    deleteSellRequests: (ids) => {
      if (ids.length === 0) return;
      dispatch({ type: "deleteSells", ids });
    },
    toggleFavorite: (id) => dispatch({ type: "toggleFav", id }),
    isFavorite: (id) => state.favorites.includes(id),
    recordListingView: (id) => {
      const serverId = phoneIdToServerId(id);
      if (serverId !== null) recordViewMutation.mutate({ id: serverId });
    },
    recordListingFavorite: (id, active) => {
      const serverId = phoneIdToServerId(id);
      if (serverId !== null) recordFavoriteMutation.mutate({ id: serverId, active });
    },
    addListing: (phone) => dispatch({ type: "addListing", phone }),
    removeListing: (id) => dispatch({ type: "removeListing", id }),
    getPhoneById: (id) => allPhones.find((p) => p.id === id),
    addOrder: (order) => dispatch({ type: "addOrder", order }),
    advanceOrderStatus: (id) => {
      const order = state.orders.find((o) => o.id === id);
      if (!order) return;
      const idx = ORDER_STATUS_FLOW.indexOf(order.status);
      if (idx < 0 || idx >= ORDER_STATUS_FLOW.length - 1) return;
      const next = ORDER_STATUS_FLOW[idx + 1];
      dispatch({ type: "updateOrderStatus", id, status: next });
      dispatch({
        type: "addNotification",
        notification: {
          id: makeId("noti"),
          kind: "order",
          title: "주문 상태가 업데이트되었어요",
          body: `${order.productName} · ${next} 상태로 변경되었습니다.`,
          userId: order.buyerId,
          refId: order.id,
          read: false,
          createdAt: new Date().toISOString(),
        },
      });
    },
    pushNotification: (n) =>
      dispatch({
        type: "addNotification",
        notification: { ...n, id: makeId("noti"), read: false, createdAt: new Date().toISOString() },
      }),
    markNotificationRead: (id) => dispatch({ type: "markNotiRead", id }),
    markAllNotificationsRead: (userId) => dispatch({ type: "markAllNotiRead", userId }),
    notificationsFor: (userId) => state.notifications.filter((n) => n.userId === userId),
    unreadCount: (userId) => state.notifications.filter((n) => n.userId === userId && !n.read).length,
    setFavoriteAlert: (id, preference) => {
      const listing = allPhones.find((phone) => phone.id === id);
      if (!listing) return;
      const current = state.favoriteAlerts[id];
      dispatch({
        type: "setFavAlert",
        id,
        preference: {
          priceDrop: preference.priceDrop,
          lowStock: preference.lowStock,
          baselinePrice: current?.baselinePrice ?? listing.price,
          lastPriceAlertedPrice: current?.lastPriceAlertedPrice,
          lowStockAlerted: current?.lowStockAlerted,
        },
      });
    },
    getFavoriteAlert: (id) => state.favoriteAlerts[id],
  };

  return <AppStoreContext.Provider value={value}>{children}</AppStoreContext.Provider>;
}

export function useAppStore(): AppStore {
  const ctx = useContext(AppStoreContext);
  if (!ctx) throw new Error("useAppStore must be used within AppStoreProvider");
  return ctx;
}
