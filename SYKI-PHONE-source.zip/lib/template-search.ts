export type SearchableTemplate = { id: string; title: string; body: string; folderId?: string };
export type SearchableFolder = { id: string; name: string };

function normalize(value: string) { return value.trim().toLocaleLowerCase("ko-KR"); }

export function filterReplyTemplatesByKeyword<T extends SearchableTemplate>(templates: readonly T[], folders: readonly SearchableFolder[], keyword: string) {
  const query = normalize(keyword);
  if (!query) return [...templates];
  const folderNameById = new Map(folders.map((folder) => [folder.id, normalize(folder.name)]));
  return templates.filter((template) => [normalize(template.title), normalize(template.body), folderNameById.get(template.folderId ?? "unclassified") ?? ""].some((value) => value.includes(query)));
}

export function sortReplyTemplatesByFavorite<T extends SearchableTemplate & { isFavorite?: boolean; updatedAt?: string }>(templates: readonly T[]) {
  return [...templates].sort((a, b) => Number(Boolean(b.isFavorite)) - Number(Boolean(a.isFavorite)) || (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
