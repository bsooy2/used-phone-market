export const SMS_CODE_TTL_MS = 3 * 60 * 1000;
export const SMS_RESEND_COOLDOWN_MS = 60 * 1000;
export const SMS_MAX_VERIFY_ATTEMPTS = 5;

export type VerificationChallengeState = { expiresAt: number; attempts: number };

export function normalizeSmsPhone(phone: string): string {
  return phone.replace(/[^0-9]/g, "");
}

export function canRequestSmsCode(lastRequestedAt: number | undefined, now: number): boolean {
  return !lastRequestedAt || now - lastRequestedAt >= SMS_RESEND_COOLDOWN_MS;
}

export function getVerificationFailureReason(challenge: VerificationChallengeState | undefined, now: number): string | null {
  if (!challenge) return "인증번호를 먼저 발송해 주세요.";
  if (now > challenge.expiresAt) return "인증번호가 만료되었습니다. 다시 발송해 주세요.";
  if (challenge.attempts >= SMS_MAX_VERIFY_ATTEMPTS) return "인증번호 입력 횟수를 초과했습니다. 다시 발송해 주세요.";
  return null;
}
