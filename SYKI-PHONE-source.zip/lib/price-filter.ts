export type PriceRange = {
  id: string;
  label: string;
  min?: number;
  max?: number;
};

export const PRICE_RANGES: PriceRange[] = [
  { id: "all", label: "전체" },
  { id: "under-300", label: "30만원 이하", max: 300_000 },
  { id: "300-500", label: "30~50만원", min: 300_000, max: 500_000 },
  { id: "500-800", label: "50~80만원", min: 500_000, max: 800_000 },
  { id: "over-800", label: "80만원 이상", min: 800_000 },
];

/** 최소·최대 가격을 모두 포함하는 범위 필터입니다. */
export function isPriceInRange(price: number, range: PriceRange): boolean {
  if (!Number.isFinite(price) || price < 0) return false;
  if (range.min !== undefined && price < range.min) return false;
  if (range.max !== undefined && price > range.max) return false;
  return true;
}
