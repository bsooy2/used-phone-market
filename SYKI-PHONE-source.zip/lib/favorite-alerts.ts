export type FavoriteAlertPreference = {
  priceDrop: boolean;
  lowStock: boolean;
  baselinePrice: number;
  lastPriceAlertedPrice?: number;
  lowStockAlerted?: boolean;
};

export type FavoriteAlertListing = {
  id: string;
  model: string;
  price: number;
  favoriteCount?: number;
};

export const LOW_STOCK_FAVORITE_THRESHOLD = 10;

export function getFavoriteAlertSignals(
  listing: FavoriteAlertListing,
  preference: FavoriteAlertPreference,
): Array<"priceDrop" | "lowStock"> {
  const signals: Array<"priceDrop" | "lowStock"> = [];
  const priceDropped = listing.price < preference.baselinePrice && preference.lastPriceAlertedPrice !== listing.price;
  if (preference.priceDrop && priceDropped) signals.push("priceDrop");

  const lowStock = (listing.favoriteCount ?? 0) >= LOW_STOCK_FAVORITE_THRESHOLD && !preference.lowStockAlerted;
  if (preference.lowStock && lowStock) signals.push("lowStock");
  return signals;
}
