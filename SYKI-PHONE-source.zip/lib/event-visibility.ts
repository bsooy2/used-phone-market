export type EventVisibilityInput = {
  active: boolean;
  startDate?: string;
  endDate?: string;
};

/** 활성화되어 있고 시작일 이후·종료일 이전인 이벤트만 노출한다. */
export function isEventVisible(event: EventVisibilityInput, now = new Date()): boolean {
  if (!event.active) return false;
  if (event.startDate && new Date(event.startDate) > now) return false;
  if (event.endDate && new Date(event.endDate) < now) return false;
  return true;
}
