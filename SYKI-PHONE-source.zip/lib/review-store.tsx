import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useReducer } from "react";

import { usePointStore } from "@/lib/point-store";
import { filterReviews, type ReviewRatingFilter } from "@/lib/review-filters";
import {
  canEditReview,
  isPhotoReviewRewardEligible,
  isValidReviewRating,
  PHOTO_REVIEW_REWARD_POINTS,
  validateReviewDraft,
} from "@/lib/review-rules";

const REVIEWS_KEY = "@syki/reviews";

export type ReviewTransactionType = "purchase" | "sell";
export type ReviewVisibility = "public" | "hidden";

export type Review = {
  id: string;
  userId: string;
  transactionId: string;
  transactionType: ReviewTransactionType;
  transactionLabel: string;
  authorName: string;
  text: string;
  photos: string[];
  rating: number;
  visibility: ReviewVisibility;
  reportedBy: string[];
  editCount: number;
  pointAwarded: boolean;
  adminReply?: { text: string; updatedAt: string };
  createdAt: string;
  updatedAt: string;
};

type ReviewState = { reviews: Review[]; loaded: boolean };
type ReviewAction =
  | { type: "load"; reviews: Review[] }
  | { type: "add"; review: Review }
  | { type: "update"; review: Review };

function reducer(state: ReviewState, action: ReviewAction): ReviewState {
  switch (action.type) {
    case "load": return { reviews: action.reviews, loaded: true };
    case "add": return { ...state, reviews: [action.review, ...state.reviews] };
    case "update": return { ...state, reviews: state.reviews.map((review) => review.id === action.review.id ? action.review : review) };
    default: return state;
  }
}

function normalizeReview(value: unknown): Review | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  if (typeof raw.id !== "string" || typeof raw.userId !== "string") return null;
  const transactionId = typeof raw.transactionId === "string" ? raw.transactionId : typeof raw.orderId === "string" ? raw.orderId : "";
  if (!transactionId) return null;
      let adminReply: { text: string; updatedAt: string } | undefined = undefined;
    if (raw.adminReply && typeof raw.adminReply === "object") {
      const rep = raw.adminReply as Record<string, unknown>;
      if (typeof rep.text === "string" && rep.text.trim()) {
        adminReply = { text: rep.text.trim(), updatedAt: typeof rep.updatedAt === "string" ? rep.updatedAt : new Date().toISOString() };
      }
    }
    return {
      id: raw.id,
      userId: raw.userId,
      transactionId,
      transactionType: raw.transactionType === "sell" ? "sell" : "purchase",
      transactionLabel: typeof raw.transactionLabel === "string" ? raw.transactionLabel : "거래 후기",
      authorName: typeof raw.authorName === "string" && raw.authorName.trim() ? raw.authorName : "시끼폰 고객",
      text: typeof raw.text === "string" ? raw.text : "",
      photos: Array.isArray(raw.photos) ? raw.photos.filter((photo): photo is string => typeof photo === "string").slice(0, 3) : [],
      rating: typeof raw.rating === "number" && isValidReviewRating(raw.rating) ? raw.rating : 5,
      visibility: raw.visibility === "hidden" ? "hidden" : "public",
      reportedBy: Array.isArray(raw.reportedBy) ? raw.reportedBy.filter((userId): userId is string => typeof userId === "string") : [],
      editCount: typeof raw.editCount === "number" ? Math.max(0, raw.editCount) : 0,
      pointAwarded: raw.pointAwarded === true,
      adminReply,
      createdAt: typeof raw.createdAt === "string" ? raw.createdAt : new Date().toISOString(),
      updatedAt: typeof raw.updatedAt === "string" ? raw.updatedAt : new Date().toISOString(),
    };

}

type CreateReviewInput = Pick<Review, "userId" | "transactionId" | "transactionType" | "transactionLabel" | "authorName" | "text" | "photos" | "rating">;
type ReviewResult = { ok: true; review: Review; pointsAwarded: number } | { ok: false; error: string };

type ReviewStore = {
  reviews: Review[];
  loaded: boolean;
  createReview: (input: CreateReviewInput, awardPhotoReward: boolean) => ReviewResult;
  updateReview: (id: string, userId: string, text: string, photos: string[], rating: number) => { ok: boolean; error?: string };
  getReviewForTransaction: (userId: string, transactionId: string, transactionType: ReviewTransactionType) => Review | undefined;
  getReviewsForUser: (userId: string) => Review[];
  getPublicReviews: (query?: string, rating?: ReviewRatingFilter) => Review[];
  reportReview: (id: string, reporterId: string) => { ok: boolean; error?: string };
  setReviewVisibility: (id: string, visibility: ReviewVisibility) => { ok: boolean; error?: string };
  clearReviewReports: (id: string) => { ok: boolean; error?: string };
  setAdminReply: (id: string, replyText: string) => { ok: boolean; error?: string };
};

const ReviewContext = createContext<ReviewStore | null>(null);

export function useReviewStore(): ReviewStore {
  const value = useContext(ReviewContext);
  if (!value) throw new Error("useReviewStore must be used within ReviewProvider");
  return value;
}

export function ReviewProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, { reviews: [], loaded: false });
  const { earnPoints } = usePointStore();

  useEffect(() => {
    AsyncStorage.getItem(REVIEWS_KEY)
      .then((raw) => {
        if (!raw) return [];
        const parsed: unknown = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed.map(normalizeReview).filter((review): review is Review => review !== null) : [];
      })
      .then((reviews) => dispatch({ type: "load", reviews }))
      .catch(() => dispatch({ type: "load", reviews: [] }));
  }, []);

  useEffect(() => {
    if (state.loaded) void AsyncStorage.setItem(REVIEWS_KEY, JSON.stringify(state.reviews));
  }, [state.loaded, state.reviews]);

  const createReview: ReviewStore["createReview"] = (input, awardPhotoReward) => {
    const validation = validateReviewDraft(input.text, input.photos.length);
    if (validation) return { ok: false, error: validation };
    if (state.reviews.some((review) => review.userId === input.userId && review.transactionId === input.transactionId && review.transactionType === input.transactionType)) {
      return { ok: false, error: "이 거래에는 이미 후기가 등록되어 있습니다." };
    }
    if (!isValidReviewRating(input.rating)) return { ok: false, error: "별점은 1점부터 5점까지 선택해 주세요." };

    const reward = awardPhotoReward && isPhotoReviewRewardEligible(input.photos.length) ? PHOTO_REVIEW_REWARD_POINTS : 0;
    const now = new Date().toISOString();
    const review: Review = {
      ...input,
      id: `review-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      text: input.text.trim(),
      authorName: input.authorName.trim() || "시끼폰 고객",
      visibility: "public",
      reportedBy: [],
      editCount: 0,
      pointAwarded: reward > 0,
      createdAt: now,
      updatedAt: now,
    };
    dispatch({ type: "add", review });
    if (reward > 0) earnPoints(reward, "사진 후기 작성 보너스");
    return { ok: true, review, pointsAwarded: reward };
  };

  const updateReview: ReviewStore["updateReview"] = (id, userId, text, photos, rating) => {
    const found = state.reviews.find((review) => review.id === id && review.userId === userId);
    if (!found) return { ok: false, error: "후기를 찾을 수 없습니다." };
    if (!canEditReview(found.editCount)) return { ok: false, error: "수정은 최대 3회까지 가능합니다." };
    const validation = validateReviewDraft(text, photos.length);
    if (validation) return { ok: false, error: validation };
    if (!isValidReviewRating(rating)) return { ok: false, error: "별점은 1점부터 5점까지 선택해 주세요." };
    dispatch({ type: "update", review: { ...found, text: text.trim(), photos, rating, editCount: found.editCount + 1, updatedAt: new Date().toISOString() } });
    return { ok: true };
  };

  const getReviewForTransaction = (userId: string, transactionId: string, transactionType: ReviewTransactionType) =>
    state.reviews.find((review) => review.userId === userId && review.transactionId === transactionId && review.transactionType === transactionType);
  const getReviewsForUser = (userId: string) => state.reviews.filter((review) => review.userId === userId);
  const getPublicReviews = (query = "", rating: ReviewRatingFilter = "all") => {
    const publicReviews = state.reviews.filter((review) => review.visibility === "public").sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return filterReviews(publicReviews, query, rating);
  };
  const reportReview: ReviewStore["reportReview"] = (id, reporterId) => {
    const found = state.reviews.find((review) => review.id === id);
    if (!found) return { ok: false, error: "후기를 찾을 수 없습니다." };
    if (found.userId === reporterId) return { ok: false, error: "내 후기는 신고할 수 없습니다." };
    if (found.reportedBy.includes(reporterId)) return { ok: false, error: "이미 신고한 후기입니다." };
    dispatch({ type: "update", review: { ...found, reportedBy: [...found.reportedBy, reporterId], updatedAt: new Date().toISOString() } });
    return { ok: true };
  };
  const setReviewVisibility: ReviewStore["setReviewVisibility"] = (id, visibility) => {
    const found = state.reviews.find((review) => review.id === id);
    if (!found) return { ok: false, error: "후기를 찾을 수 없습니다." };
    dispatch({ type: "update", review: { ...found, visibility, updatedAt: new Date().toISOString() } });
    return { ok: true };
  };
  const clearReviewReports: ReviewStore["clearReviewReports"] = (id) => {
    const found = state.reviews.find((review) => review.id === id);
    if (!found) return { ok: false, error: "후기를 찾을 수 없습니다." };
    dispatch({ type: "update", review: { ...found, reportedBy: [], updatedAt: new Date().toISOString() } });
    return { ok: true };
  };

  const setAdminReply = (id: string, replyText: string) => {
    const found = state.reviews.find((review) => review.id === id);
    if (!found) return { ok: false, error: "후기를 찾을 수 없습니다." };
    const text = replyText.trim();
    const adminReply = text ? { text, updatedAt: new Date().toISOString() } : undefined;
    dispatch({ type: "update", review: { ...found, adminReply, updatedAt: new Date().toISOString() } });
    return { ok: true };
  };

  return <ReviewContext.Provider value={{ reviews: state.reviews, loaded: state.loaded, createReview, updateReview, getReviewForTransaction, getReviewsForUser, getPublicReviews, reportReview, setReviewVisibility, clearReviewReports, setAdminReply }}>{children}</ReviewContext.Provider>;
}
