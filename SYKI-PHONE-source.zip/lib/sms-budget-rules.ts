export type SmsLimitStatus = "safe" | "warning" | "blocked";

export function getSmsLimitStatus(input: { balance: number; dailySentCount: number; dailyLimit: number; balanceWarningThreshold: number }) {
  const balance = Math.max(0, input.balance);
  const dailyLimit = Math.max(1, input.dailyLimit);
  const dailySentCount = Math.max(0, input.dailySentCount);
  if (balance <= 0 || dailySentCount >= dailyLimit) {
    return { status: "blocked" as const, balance, remainingQuota: 0, message: balance <= 0 ? "SOLAPI 충전 잔액이 없습니다." : "오늘의 인증 문자 발송 한도에 도달했습니다." };
  }
  const remainingQuota = Math.max(0, dailyLimit - dailySentCount);
  if (balance < input.balanceWarningThreshold || dailySentCount / dailyLimit >= 0.8) {
    return { status: "warning" as const, balance, remainingQuota, message: balance < input.balanceWarningThreshold ? "SOLAPI 잔액이 설정한 경고 기준보다 낮습니다." : "오늘의 인증 문자 발송 한도에 가까워졌습니다." };
  }
  return { status: "safe" as const, balance, remainingQuota, message: "문자 발송 잔액과 일일 한도가 정상입니다." };
}
