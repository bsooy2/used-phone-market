import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";
import { isAccountRecoveryNameMatch, validatePasswordResetRequest } from "./account-recovery";

export type UserRole = "seller" | "buyer";
export type Gender = "male" | "female" | "none";

/** 구매자 상세 정보 (결제/환불에 사용) */
export type BuyerProfile = {
  name: string;
  birth: string; // YYYY-MM-DD 또는 YYYYMMDD
  gender: Gender;
  email: string;
  zipcode: string; // 우편번호
  address: string; // 도로명/지번 주소
  addressDetail: string; // 상세 주소 (동/호 등)
  refundBank: string; // 은행명
  refundAccount: string; // 계좌번호
  refundHolder: string; // 예금주
};

export const EMPTY_BUYER_PROFILE: BuyerProfile = {
  name: "",
  birth: "",
  gender: "none",
  email: "",
  zipcode: "",
  address: "",
  addressDetail: "",
  refundBank: "",
  refundAccount: "",
  refundHolder: "",
};

export type Account = {
  id: string;
  phone: string; // 로그인 ID로 사용 (연락처)
  password: string; // 데모용 로컬 저장 (실서비스에서는 서버 해시 필요)
  nickname: string;
  role: UserRole;
  createdAt: string;
  agreedPrivacy: boolean; // 필수 동의
  agreedMarketing: boolean; // 선택 동의
  buyerProfile?: BuyerProfile; // 구매자만
  mustChangePassword?: boolean; // 임시 비밀번호 발급 후 강제 변경 플래그
  deleteScheduledAt?: string; // 탈퇴 예약 일시 (ISO string, 7일 후 삭제)
};

export type SessionUser = Omit<Account, "password">;

const ACCOUNTS_KEY = "@syki/accounts";
const SESSION_KEY = "@syki/session";

type SignUpInput = {
  phone: string;
  password: string;
  nickname: string;
  role: UserRole;
  agreedPrivacy: boolean;
  agreedMarketing: boolean;
  buyerProfile?: BuyerProfile;
};

type AuthStore = {
  loaded: boolean;
  user: SessionUser | null;
  isSeller: boolean;
  mustChangePassword: boolean;
  loginLocked: boolean;
  lockRemainingSeconds: number;
  captchaRequired: boolean;
  captchaQuestion: string;
  verifyCaptcha: (answer: string) => boolean;
  autoLogin: boolean;
  setAutoLogin: (v: boolean) => void;
  deleteScheduledAt: string | null;
  signUp: (input: SignUpInput) => Promise<{ ok: boolean; error?: string }>;
  signIn: (input: { phone: string; password: string }) => Promise<{ ok: boolean; error?: string }>;
  signOut: () => Promise<void>;
  updateBuyerProfile: (profile: BuyerProfile) => Promise<{ ok: boolean; error?: string }>;
  /** 현재 사용자의 비밀번호를 검증한다 (정보 수정 전 본인 확인용) */
  verifyPassword: (password: string) => Promise<boolean>;
  /** 현재 사용자의 역할을 전환한다 (buyer ↔ seller) */
  switchRole: () => Promise<{ ok: boolean; error?: string }>;
  /** 비밀번호를 변경한다 */
  changePassword: (newPassword: string) => Promise<{ ok: boolean; error?: string }>;
  /** 아이디(휴대폰 번호) 찾기 — 이름+생년월일로 조회 */
  findId: (name: string, birth: string) => Promise<{ ok: boolean; phone?: string; error?: string }>;
  /** 아이디 찾기 — 이메일로 조회 */
  findIdByEmail: (email: string) => Promise<{ ok: boolean; phone?: string; error?: string }>;
  /** 비밀번호 찾기 — 아이디+이름 확인 후 실제 SMS 발송 전 계정 확인 */
  requestPasswordResetCode: (phone: string, name: string) => Promise<{ ok: boolean; error?: string }>;
  /** 인증 완료 후 새 비밀번호 설정 */
  verifyAndResetPassword: (phone: string, newPassword: string) => Promise<{ ok: boolean; error?: string }>;
  /** 임시 비밀번호 강제 변경 완료 처리 */
  clearMustChangePassword: () => Promise<void>;
  /** 회원 탈퇴 (계정 영구 삭제) */
  deleteAccount: (password: string) => Promise<{ ok: boolean; error?: string; scheduledAt?: string }>;
  /** 탈퇴 예약 취소 */
  cancelDeleteAccount: () => Promise<{ ok: boolean; error?: string }>;
  /** 관리자용: 전체 계정 목록 조회 */
  getAllAccounts: () => Promise<Account[]>;
};

const AuthContext = createContext<AuthStore | null>(null);

async function readAccounts(): Promise<Account[]> {
  try {
    const raw = await AsyncStorage.getItem(ACCOUNTS_KEY);
    return raw ? (JSON.parse(raw) as Account[]) : [];
  } catch {
    return [];
  }
}

function normalizePhone(p: string): string {
  return p.replace(/[^0-9]/g, "");
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/** 구매자 필수 상세정보 검증 */
export function validateBuyerProfile(p: BuyerProfile): string | null {
  if (!p.name.trim()) return "이름을 입력해 주세요.";
  if (!p.birth.trim()) return "생년월일을 입력해 주세요.";
  if (p.gender === "none") return "성별을 선택해 주세요.";
  if (!isValidEmail(p.email.trim())) return "올바른 이메일을 입력해 주세요.";
  if (!p.address.trim()) return "주소를 검색해 선택해 주세요.";
  if (!p.addressDetail.trim()) return "상세 주소를 입력해 주세요.";
  if (!p.refundBank.trim()) return "입금 계좌 은행을 입력해 주세요.";
  if (!p.refundAccount.trim()) return "입금 계좌번호를 입력해 주세요.";
  if (!p.refundHolder.trim()) return "예금주명을 입력해 주세요.";
  return null;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [loaded, setLoaded] = useState(false);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [failCount, setFailCount] = useState(0);
  const [lockUntil, setLockUntil] = useState<number>(0);
  const [lockRemainingSeconds, setLockRemainingSeconds] = useState(0);
  const [captchaRequired, setCaptchaRequired] = useState(false);
  const [captchaA, setCaptchaA] = useState(0);
  const [captchaB, setCaptchaB] = useState(0);
  const [autoLogin, setAutoLoginState] = useState(true);
  const [deleteScheduledAt, setDeleteScheduledAt] = useState<string | null>(null);

  // 자동 로그인 설정 로드
  useEffect(() => {
    AsyncStorage.getItem("AUTO_LOGIN").then((v) => { if (v === "false") setAutoLoginState(false); });
  }, []);

  const setAutoLogin = (v: boolean) => {
    setAutoLoginState(v);
    AsyncStorage.setItem("AUTO_LOGIN", v ? "true" : "false");
  };

  const generateCaptcha = () => {
    const a = Math.floor(Math.random() * 9) + 1;
    const b = Math.floor(Math.random() * 9) + 1;
    setCaptchaA(a);
    setCaptchaB(b);
    setCaptchaRequired(true);
  };

  const verifyCaptcha = (answer: string): boolean => {
    const correct = captchaA + captchaB;
    if (parseInt(answer, 10) === correct) {
      setCaptchaRequired(false);
      setLockUntil(0);
      setLockRemainingSeconds(0);
      return true;
    }
    return false;
  };

  // 잠금 타이머
  useEffect(() => {
    if (lockUntil <= Date.now()) { setLockRemainingSeconds(0); return; }
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((lockUntil - Date.now()) / 1000));
      setLockRemainingSeconds(remaining);
      if (remaining <= 0) clearInterval(interval);
    }, 1000);
    return () => clearInterval(interval);
  }, [lockUntil]);

  useEffect(() => {
    (async () => {
      try {
        const autoLoginSetting = await AsyncStorage.getItem("AUTO_LOGIN");
        if (autoLoginSetting === "false") {
          // 자동 로그인 해제 → 세션 삭제하여 로그인 화면으로 이동
          await AsyncStorage.removeItem(SESSION_KEY);
          setUser(null);
        } else {
          const raw = await AsyncStorage.getItem(SESSION_KEY);
          if (raw) {
            const parsed = JSON.parse(raw) as SessionUser;
            setUser(parsed);
            // 탈퇴 예약 상태 복원
            const accounts = await readAccounts();
            const found = accounts.find((a) => a.id === parsed.id);
            if (found?.deleteScheduledAt) setDeleteScheduledAt(found.deleteScheduledAt);
          }
        }
      } catch {
        // ignore
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const persistSession = async (u: SessionUser | null) => {
    setUser(u);
    if (u) await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(u));
    else await AsyncStorage.removeItem(SESSION_KEY);
  };

  const signUp: AuthStore["signUp"] = async ({
    phone,
    password,
    nickname,
    role,
    agreedPrivacy,
    agreedMarketing,
    buyerProfile,
  }) => {
    const normalized = normalizePhone(phone);
    if (normalized.length < 9) return { ok: false, error: "올바른 휴대폰 번호를 입력해 주세요." };
    if (password.length < 4) return { ok: false, error: "비밀번호는 4자 이상이어야 합니다." };
    if (!nickname.trim()) return { ok: false, error: "닉네임을 입력해 주세요." };
    if (!agreedPrivacy) return { ok: false, error: "필수 개인정보 수집·이용에 동의해야 가입할 수 있습니다." };

    // 구매자는 상세정보 필수
    if (role === "buyer") {
      if (!buyerProfile) return { ok: false, error: "구매자 정보를 입력해 주세요." };
      const profileError = validateBuyerProfile(buyerProfile);
      if (profileError) return { ok: false, error: profileError };
    }

    const accounts = await readAccounts();
    if (accounts.some((a) => a.phone === normalized)) {
      return { ok: false, error: "이미 가입된 휴대폰 번호입니다." };
    }
    const account: Account = {
      id: `u_${Date.now()}`,
      phone: normalized,
      password,
      nickname: nickname.trim(),
      role,
      createdAt: new Date().toISOString(),
      agreedPrivacy,
      agreedMarketing,
      buyerProfile: role === "buyer" ? buyerProfile : undefined,
    };
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify([account, ...accounts]));
    const { password: _pw, ...session } = account;
    await persistSession(session);
    return { ok: true };
  };

  const signIn: AuthStore["signIn"] = async ({ phone, password }) => {
    // 잠금 확인
    if (lockUntil > Date.now() && captchaRequired) {
      const sec = Math.ceil((lockUntil - Date.now()) / 1000);
      return { ok: false, error: `로그인이 잠겼습니다. ${sec}초 후 다시 시도해 주세요.` };
    }
    if (lockUntil > Date.now() && !captchaRequired) {
      return { ok: false, error: `잠금 해제를 위해 보안 문제를 풀어주세요.` };
    }
    const normalized = normalizePhone(phone);
    const accounts = await readAccounts();
    const found = accounts.find((a) => a.phone === normalized);
    if (!found) {
      const newFail = failCount + 1;
      setFailCount(newFail);
      if (newFail >= 5) { setLockUntil(Date.now() + 180000); setFailCount(0); generateCaptcha(); }
      return { ok: false, error: `가입되지 않은 번호입니다. (${newFail}/5)` };
    }
    if (found.password !== password) {
      const newFail = failCount + 1;
      setFailCount(newFail);
      if (newFail >= 5) { setLockUntil(Date.now() + 180000); setFailCount(0); generateCaptcha(); }
      return { ok: false, error: `비밀번호가 일치하지 않습니다. (${newFail}/5)` };
    }
    setFailCount(0);
    setCaptchaRequired(false);
    // 임시 비밀번호 강제 변경 확인
    if (found.mustChangePassword) setMustChangePassword(true);
    const { password: _pw, ...session } = found;
    await persistSession(session);
    return { ok: true };
  };

  const signOut: AuthStore["signOut"] = async () => {
    await persistSession(null);
  };

  const updateBuyerProfile: AuthStore["updateBuyerProfile"] = async (profile) => {
    if (!user) return { ok: false, error: "로그인이 필요합니다." };
    const profileError = validateBuyerProfile(profile);
    if (profileError) return { ok: false, error: profileError };

    const accounts = await readAccounts();
    const updated = accounts.map((a) =>
      a.id === user.id ? { ...a, buyerProfile: profile } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    await persistSession({ ...user, buyerProfile: profile });
    return { ok: true };
  };

  const verifyPassword: AuthStore["verifyPassword"] = async (password) => {
    if (!user) return false;
    const accounts = await readAccounts();
    const found = accounts.find((a) => a.id === user.id);
    return found?.password === password;
  };

  const switchRole: AuthStore["switchRole"] = async () => {
    if (!user) return { ok: false, error: "로그인이 필요합니다." };
    const newRole: UserRole = user.role === "buyer" ? "seller" : "buyer";
    const accounts = await readAccounts();
    const updated = accounts.map((a) =>
      a.id === user.id ? { ...a, role: newRole } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    await persistSession({ ...user, role: newRole });
    return { ok: true };
  };

  const changePassword: AuthStore["changePassword"] = async (newPassword) => {
    if (!user) return { ok: false, error: "로그인이 필요합니다." };
    if (newPassword.length < 4) return { ok: false, error: "비밀번호는 4자 이상이어야 합니다." };
    const accounts = await readAccounts();
    const updated = accounts.map((a) =>
      a.id === user.id ? { ...a, password: newPassword } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    return { ok: true };
  };

  const findId: AuthStore["findId"] = async (name, birth) => {
    if (!name.trim() || !birth.trim()) return { ok: false, error: "이름과 생년월일을 모두 입력해 주세요." };
    const accounts = await readAccounts();
    const found = accounts.find(
      (a) => isAccountRecoveryNameMatch(a, name) && a.buyerProfile?.birth.replace(/-/g, "") === birth.replace(/-/g, ""),
    );
    if (!found) return { ok: false, error: "일치하는 회원 정보가 없습니다." };
    // 번호 일부 마스킹: 010-1234-5678 → 010-****-5678
    const p = found.phone;
    const masked = p.length >= 8 ? p.slice(0, 3) + "****" + p.slice(-4) : p;
    return { ok: true, phone: masked };
  };

  const requestPasswordResetCode: AuthStore["requestPasswordResetCode"] = async (phone, name) => {
    const validationError = validatePasswordResetRequest(phone, name);
    if (validationError) return { ok: false, error: validationError };
    const normalized = normalizePhone(phone);
    const accounts = await readAccounts();
    const found = accounts.find(
      (a) => a.phone === normalized && isAccountRecoveryNameMatch(a, name),
    );
    if (!found) return { ok: false, error: "일치하는 회원 정보가 없습니다." };
    return { ok: true };
  };

  const verifyAndResetPassword: AuthStore["verifyAndResetPassword"] = async (phone, newPassword) => {
    const normalized = normalizePhone(phone);
    if (!normalized || newPassword.length < 4) return { ok: false, error: "올바른 비밀번호를 입력해 주세요." };
    const accounts = await readAccounts();
    const found = accounts.find((a) => a.phone === normalized);
    if (!found) return { ok: false, error: "계정을 찾을 수 없습니다." };
    const updated = accounts.map((a) =>
      a.id === found.id ? { ...a, password: newPassword, mustChangePassword: false } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    return { ok: true };
  };

  const findIdByEmail: AuthStore["findIdByEmail"] = async (email) => {
    if (!email.trim() || !email.includes("@")) return { ok: false, error: "올바른 이메일을 입력해 주세요." };
    const accounts = await readAccounts();
    const found = accounts.find(
      (a) => a.buyerProfile?.email.trim().toLowerCase() === email.trim().toLowerCase(),
    );
    if (!found) return { ok: false, error: "해당 이메일로 가입된 계정이 없습니다." };
    const p = found.phone;
    const masked = p.length >= 8 ? p.slice(0, 3) + "****" + p.slice(-4) : p;
    return { ok: true, phone: masked };
  };

  const clearMustChangePassword: AuthStore["clearMustChangePassword"] = async () => {
    if (!user) return;
    const accounts = await readAccounts();
    const updated = accounts.map((a) =>
      a.id === user.id ? { ...a, mustChangePassword: false } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    setMustChangePassword(false);
  };

  const deleteAccount: AuthStore["deleteAccount"] = async (password): Promise<{ ok: boolean; error?: string; scheduledAt?: string }> => {
    if (!user) return { ok: false, error: "로그인이 필요합니다." };
    const accounts = await readAccounts();
    const found = accounts.find((a) => a.id === user.id);
    if (!found || found.password !== password) return { ok: false, error: "비밀번호가 일치하지 않습니다." };
    // 7일 유예 예약
    const scheduledAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const updated = accounts.map((a) =>
      a.id === user.id ? { ...a, deleteScheduledAt: scheduledAt } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    setDeleteScheduledAt(scheduledAt);
    return { ok: true, scheduledAt };
  };

  const cancelDeleteAccount: AuthStore["cancelDeleteAccount"] = async () => {
    if (!user) return { ok: false, error: "로그인이 필요합니다." };
    const accounts = await readAccounts();
    const updated = accounts.map((a) =>
      a.id === user.id ? { ...a, deleteScheduledAt: undefined } : a,
    );
    await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(updated));
    setDeleteScheduledAt(null);
    return { ok: true };
  };

  const getAllAccounts: AuthStore["getAllAccounts"] = async () => {
    return readAccounts();
  };

  const value: AuthStore = {
    loaded,
    user,
    isSeller: user?.role === "seller",
    mustChangePassword,
    loginLocked: lockUntil > Date.now(),
    lockRemainingSeconds,
    captchaRequired,
    captchaQuestion: `${captchaA} + ${captchaB} = ?`,
    verifyCaptcha,
    autoLogin,
    setAutoLogin,
    deleteScheduledAt,
    signUp,
    signIn,
    signOut,
    updateBuyerProfile,
    verifyPassword,
    switchRole,
    changePassword,
    findId,
    findIdByEmail,
    requestPasswordResetCode,
    verifyAndResetPassword,
    clearMustChangePassword,
    deleteAccount,
    cancelDeleteAccount,
    getAllAccounts,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuthStore(): AuthStore {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuthStore must be used within AuthProvider");
  return ctx;
}
