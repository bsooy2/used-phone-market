/** 매장 전화번호를 운영체제 전화 앱이 인식하는 tel URL로 변환한다. */
export function makeStoreTelUrl(phone: string): string {
  return `tel:${phone.replace(/[^0-9+]/g, "")}`;
}
