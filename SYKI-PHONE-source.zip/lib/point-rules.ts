/** 포인트는 상품 실결제 금액의 2%를 적립합니다. */
export const POINT_EARN_RATE = 0.02;

/** 구매 후 적립될 포인트(원 단위)를 계산합니다. 배송비는 적립 대상에서 제외합니다. */
export function calculatePurchasePoints(productPaidAmount: number): number {
  if (!Number.isFinite(productPaidAmount) || productPaidAmount <= 0) return 0;
  return Math.floor(productPaidAmount * POINT_EARN_RATE);
}

/** 현재 보유 포인트와 상품 금액 범위에서 사용할 수 있는 최대 포인트(1,000원 단위)입니다. */
export function maxRedeemablePoints(balance: number, productAmount: number): number {
  if (!Number.isFinite(balance) || !Number.isFinite(productAmount)) return 0;
  return Math.floor(Math.max(0, Math.min(balance, productAmount)) / 1000) * 1000;
}

/** 포인트 사용액이 1,000원 단위이며 사용 가능한 범위인지 검증합니다. */
export function isValidPointRedemption(amount: number, balance: number, productAmount: number): boolean {
  return amount > 0 && amount % 1000 === 0 && amount <= maxRedeemablePoints(balance, productAmount);
}
