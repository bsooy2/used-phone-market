export type ReviewRatingFilter = "all" | 1 | 2 | 3 | 4 | 5;

export type ReviewFilterable = {
  text: string;
  authorName: string;
  transactionLabel: string;
  rating: number;
};

export const REVIEW_RATING_FILTERS: Array<{ value: ReviewRatingFilter; label: string }> = [
  { value: "all", label: "전체 별점" },
  { value: 5, label: "5점" },
  { value: 4, label: "4점" },
  { value: 3, label: "3점" },
  { value: 2, label: "2점" },
  { value: 1, label: "1점" },
];

export function normalizeReviewSearchQuery(query: string): string {
  return query
    .trim()
    .toLocaleLowerCase("ko-KR")
    .replaceAll("아이폰", "iphone")
    .replaceAll("갤럭시", "galaxy");
}

export function filterReviews<T extends ReviewFilterable>(
  reviews: readonly T[],
  query: string,
  rating: ReviewRatingFilter,
): T[] {
  const normalizedQuery = normalizeReviewSearchQuery(query);
  return reviews.filter((review) => {
    const matchesRating = rating === "all" || review.rating === rating;
    if (!matchesRating) return false;
    if (!normalizedQuery) return true;

    const searchableText = normalizeReviewSearchQuery([review.text, review.authorName, review.transactionLabel].join(" "));
    return searchableText.includes(normalizedQuery);
  });
}
