import React, { createContext, useContext, useEffect, useReducer, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAuthStore } from "@/lib/auth-store";
import { maxRedeemablePoints } from "@/lib/point-rules";

const POINTS_KEY_PREFIX = "@syki/points";

export type PointEntry = {
  id: string;
  amount: number; // 양수=적립, 음수=사용
  label: string;
  createdAt: string;
};

type PointState = {
  balance: number;
  history: PointEntry[];
};

type PointAction =
  | { type: "load"; state: PointState }
  | { type: "add"; entry: PointEntry };

function reducer(state: PointState, action: PointAction): PointState {
  switch (action.type) {
    case "load":
      return action.state;
    case "add":
      return { balance: state.balance + action.entry.amount, history: [action.entry, ...state.history] };
  }
}

type PointStore = {
  balance: number;
  history: PointEntry[];
  earnPoints: (amount: number, label: string) => void;
  usePoints: (amount: number, label: string) => boolean;
  canUsePoints: (amount: number) => boolean;
};

const Ctx = createContext<PointStore>(null!);
export const usePointStore = () => useContext(Ctx);

export function PointProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, { balance: 0, history: [] });
  const { user } = useAuthStore();
  const [loadedUserId, setLoadedUserId] = useState<string | null | undefined>(undefined);

  useEffect(() => {
    let cancelled = false;
    const userId = user?.id ?? null;
    setLoadedUserId(undefined);
    dispatch({ type: "load", state: { balance: 0, history: [] } });

    if (!userId) {
      setLoadedUserId(null);
      return () => { cancelled = true; };
    }

    AsyncStorage.getItem(`${POINTS_KEY_PREFIX}/${userId}`).then((raw) => {
      if (cancelled) return;
      try {
        dispatch({ type: "load", state: raw ? JSON.parse(raw) as PointState : { balance: 0, history: [] } });
      } catch {
        dispatch({ type: "load", state: { balance: 0, history: [] } });
      }
      setLoadedUserId(userId);
    });

    return () => { cancelled = true; };
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id || loadedUserId !== user.id) return;
    AsyncStorage.setItem(`${POINTS_KEY_PREFIX}/${user.id}`, JSON.stringify(state));
  }, [loadedUserId, state, user?.id]);

  const earnPoints = (amount: number, label: string) => {
    if (!user || amount <= 0) return;
    dispatch({
      type: "add",
      entry: { id: `pt-${Date.now()}`, amount, label, createdAt: new Date().toISOString() },
    });
  };

  const usePoints = (amount: number, label: string): boolean => {
    if (!user || amount % 1000 !== 0 || amount <= 0 || amount > state.balance) return false;
    dispatch({
      type: "add",
      entry: { id: `pt-${Date.now()}`, amount: -amount, label, createdAt: new Date().toISOString() },
    });
    return true;
  };

  const canUsePoints = (amount: number) => amount <= maxRedeemablePoints(state.balance, amount) && amount % 1000 === 0 && amount > 0;

  return (
    <Ctx.Provider value={{ balance: state.balance, history: state.history, earnPoints, usePoints, canUsePoints }}>
      {children}
    </Ctx.Provider>
  );
}
