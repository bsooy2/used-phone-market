import type { Phone } from "@/constants/types";

export type ListingPopularity = {
  id: string;
  label: string;
  price: number;
  views: number;
  favorites: number;
};

/** 매물 통계를 조회수 우선, 찜 횟수 보조 순으로 정렬한다. */
export function rankListingPopularity(phones: Phone[]): ListingPopularity[] {
  return phones
    .map((phone) => ({
      id: phone.id,
      label: `${phone.model} · ${phone.storage}`,
      price: phone.price,
      views: Math.max(0, phone.viewCount ?? 0),
      favorites: Math.max(0, phone.favoriteCount ?? 0),
    }))
    .sort((a, b) => b.views - a.views || b.favorites - a.favorites || b.price - a.price);
}

export function getListingAnalyticsSummary(rows: ListingPopularity[]) {
  return {
    totalViews: rows.reduce((sum, row) => sum + row.views, 0),
    totalFavorites: rows.reduce((sum, row) => sum + row.favorites, 0),
  };
}
