import * as FileSystem from "expo-file-system/legacy";
import { Platform } from "react-native";

const REVIEW_PHOTO_DIRECTORY = `${FileSystem.documentDirectory ?? ""}review-photos/`;

function fileExtension(uri: string): string {
  const extension = uri.split("?")[0].match(/\.([a-zA-Z0-9]{2,5})$/)?.[1];
  return extension ? `.${extension.toLowerCase()}` : ".jpg";
}

/** 후기 사진을 앱 문서 저장소로 복사해 갤러리 URI 만료 후에도 유지한다. */
export async function persistReviewPhoto(uri: string, index: number): Promise<string> {
  if (Platform.OS === "web" || !FileSystem.documentDirectory || /^https?:\/\//i.test(uri) || uri.includes("/review-photos/")) {
    return uri;
  }

  try {
    await FileSystem.makeDirectoryAsync(REVIEW_PHOTO_DIRECTORY, { intermediates: true });
    const destination = `${REVIEW_PHOTO_DIRECTORY}${Date.now()}-${index}${fileExtension(uri)}`;
    await FileSystem.copyAsync({ from: uri, to: destination });
    return destination;
  } catch {
    return uri;
  }
}
