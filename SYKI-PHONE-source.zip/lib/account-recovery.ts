export type AccountRecoveryIdentity = {
  nickname: string;
  buyerProfile?: { name: string };
};

function normalizePhone(phone: string): string {
  return phone.replace(/[^0-9]/g, "");
}

/** 구매자 실명과 모든 가입 유형의 닉네임을 비밀번호 찾기 대상 이름으로 인식한다. */
export function isAccountRecoveryNameMatch(account: AccountRecoveryIdentity, name: string): boolean {
  const target = name.trim();
  if (!target) return false;
  return [account.buyerProfile?.name, account.nickname].some((savedName) => savedName?.trim() === target);
}

export function validatePasswordResetRequest(phone: string, name: string): string | null {
  if (!normalizePhone(phone) || !name.trim()) return "아이디(휴대폰 번호)와 이름 또는 닉네임을 모두 입력해 주세요.";
  if (normalizePhone(phone).length < 9) return "올바른 휴대폰 번호를 입력해 주세요.";
  return null;
}
