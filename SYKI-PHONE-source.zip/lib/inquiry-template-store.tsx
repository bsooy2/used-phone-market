import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useState } from "react";
import { resolveTemplateFolderId, UNCLASSIFIED_FOLDER_ID, validateTemplateFolderName } from "@/lib/template-folder-rules";

const TEMPLATE_KEY = "@syki/inquiry_reply_templates";
const FOLDER_KEY = "@syki/inquiry_reply_template_folders";
export { UNCLASSIFIED_FOLDER_ID } from "@/lib/template-folder-rules";

export type InquiryTemplateFolder = { id: string; name: string; createdAt: string; updatedAt: string; isSystem?: boolean };
export type InquiryReplyTemplate = { id: string; title: string; body: string; folderId?: string; isFavorite?: boolean; createdAt: string; updatedAt: string };

const DEFAULT_FOLDERS: InquiryTemplateFolder[] = [
  { id: UNCLASSIFIED_FOLDER_ID, name: "미분류", createdAt: "2026-08-20T00:00:00.000Z", updatedAt: "2026-08-20T00:00:00.000Z", isSystem: true },
];
const DEFAULT_TEMPLATES: InquiryReplyTemplate[] = [
  { id: "template_received", title: "문의 접수 안내", body: "안녕하세요, 시끼폰입니다. 문의 내용을 확인했으며 빠르게 안내드리겠습니다. 감사합니다.", folderId: UNCLASSIFIED_FOLDER_ID, createdAt: "2026-08-20T00:00:00.000Z", updatedAt: "2026-08-20T00:00:00.000Z" },
  { id: "template_visit", title: "매장 방문 안내", body: "안녕하세요, 시끼폰입니다. 기기 상태 확인을 위해 매장 방문 상담도 가능합니다. 방문 전 연락 주시면 빠르게 안내드리겠습니다.", folderId: UNCLASSIFIED_FOLDER_ID, createdAt: "2026-08-20T00:00:00.000Z", updatedAt: "2026-08-20T00:00:00.000Z" },
];

type Result = { ok: boolean; error?: string };
type TemplateStore = {
  templates: InquiryReplyTemplate[];
  folders: InquiryTemplateFolder[];
  loaded: boolean;
  createTemplate: (title: string, body: string, folderId?: string) => Result;
  updateTemplate: (id: string, title: string, body: string, folderId?: string) => Result;
  deleteTemplate: (id: string) => void;
  toggleTemplateFavorite: (id: string) => void;
  moveTemplate: (templateId: string, folderId: string) => void;
  createFolder: (name: string) => Result;
  updateFolder: (id: string, name: string) => Result;
  deleteFolder: (id: string) => Result;
};

const InquiryTemplateContext = createContext<TemplateStore | null>(null);
const makeId = (prefix: string) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
function validateTemplate(title: string, body: string) { if (title.trim().length < 2) return "템플릿 제목을 2자 이상 입력해 주세요."; if (body.trim().length < 2) return "답변 내용을 2자 이상 입력해 주세요."; if (body.trim().length > 1000) return "답변 내용은 1,000자 이내로 입력해 주세요."; return null; }

export function InquiryTemplateProvider({ children }: { children: React.ReactNode }) {
  const [templates, setTemplates] = useState<InquiryReplyTemplate[]>([]);
  const [folders, setFolders] = useState<InquiryTemplateFolder[]>(DEFAULT_FOLDERS);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { Promise.all([AsyncStorage.getItem(TEMPLATE_KEY), AsyncStorage.getItem(FOLDER_KEY)]).then(([templateRaw, folderRaw]) => {
    const savedFolders = folderRaw ? JSON.parse(folderRaw) as InquiryTemplateFolder[] : DEFAULT_FOLDERS;
    const normalizedFolders = savedFolders.some((folder) => folder.id === UNCLASSIFIED_FOLDER_ID) ? savedFolders : [...DEFAULT_FOLDERS, ...savedFolders];
    const savedTemplates = templateRaw ? JSON.parse(templateRaw) as InquiryReplyTemplate[] : DEFAULT_TEMPLATES;
    const normalizedTemplates = savedTemplates.map((template) => ({ ...template, folderId: normalizedFolders.some((folder) => folder.id === template.folderId) ? template.folderId : UNCLASSIFIED_FOLDER_ID }));
    setFolders(normalizedFolders); setTemplates(normalizedTemplates); void AsyncStorage.multiSet([[TEMPLATE_KEY, JSON.stringify(normalizedTemplates)], [FOLDER_KEY, JSON.stringify(normalizedFolders)]]);
  }).catch(() => { setFolders(DEFAULT_FOLDERS); setTemplates(DEFAULT_TEMPLATES); }).finally(() => setLoaded(true)); }, []);
  const persist = (nextTemplates: InquiryReplyTemplate[], nextFolders: InquiryTemplateFolder[]) => { setTemplates(nextTemplates); setFolders(nextFolders); void AsyncStorage.multiSet([[TEMPLATE_KEY, JSON.stringify(nextTemplates)], [FOLDER_KEY, JSON.stringify(nextFolders)]]); };
  const validFolderId = (folderId?: string) => resolveTemplateFolderId(folderId, folders.map((folder) => folder.id));
  const createTemplate: TemplateStore["createTemplate"] = (title, body, folderId) => { const error = validateTemplate(title, body); if (error) return { ok: false, error }; const now = new Date().toISOString(); persist([{ id: makeId("reply_template"), title: title.trim(), body: body.trim(), folderId: validFolderId(folderId), createdAt: now, updatedAt: now }, ...templates], folders); return { ok: true }; };
  const updateTemplate: TemplateStore["updateTemplate"] = (id, title, body, folderId) => { const error = validateTemplate(title, body); if (error) return { ok: false, error }; persist(templates.map((template) => template.id === id ? { ...template, title: title.trim(), body: body.trim(), folderId: validFolderId(folderId), updatedAt: new Date().toISOString() } : template), folders); return { ok: true }; };
  const createFolder: TemplateStore["createFolder"] = (name) => { const error = validateTemplateFolderName(name, folders); if (error) return { ok: false, error }; const now = new Date().toISOString(); persist(templates, [...folders, { id: makeId("reply_folder"), name: name.trim(), createdAt: now, updatedAt: now }]); return { ok: true }; };
  const updateFolder: TemplateStore["updateFolder"] = (id, name) => { if (id === UNCLASSIFIED_FOLDER_ID) return { ok: false, error: "미분류 폴더 이름은 변경할 수 없습니다." }; const error = validateTemplateFolderName(name, folders, id); if (error) return { ok: false, error }; persist(templates, folders.map((folder) => folder.id === id ? { ...folder, name: name.trim(), updatedAt: new Date().toISOString() } : folder)); return { ok: true }; };
  const deleteFolder: TemplateStore["deleteFolder"] = (id) => { if (id === UNCLASSIFIED_FOLDER_ID) return { ok: false, error: "미분류 폴더는 삭제할 수 없습니다." }; persist(templates.map((template) => template.folderId === id ? { ...template, folderId: UNCLASSIFIED_FOLDER_ID, updatedAt: new Date().toISOString() } : template), folders.filter((folder) => folder.id !== id)); return { ok: true }; };
  const moveTemplate: TemplateStore["moveTemplate"] = (templateId, folderId) => persist(templates.map((template) => template.id === templateId ? { ...template, folderId: validFolderId(folderId), updatedAt: new Date().toISOString() } : template), folders);
  const toggleTemplateFavorite: TemplateStore["toggleTemplateFavorite"] = (id) => persist(templates.map((template) => template.id === id ? { ...template, isFavorite: !template.isFavorite, updatedAt: new Date().toISOString() } : template), folders);
  return <InquiryTemplateContext.Provider value={{ templates, folders, loaded, createTemplate, updateTemplate, deleteTemplate: (id) => persist(templates.filter((template) => template.id !== id), folders), toggleTemplateFavorite, moveTemplate, createFolder, updateFolder, deleteFolder }}>{children}</InquiryTemplateContext.Provider>;
}

export function useInquiryTemplateStore() { const value = useContext(InquiryTemplateContext); if (!value) throw new Error("useInquiryTemplateStore must be used within InquiryTemplateProvider"); return value; }
