import * as FileSystem from "expo-file-system/legacy";
import { Platform } from "react-native";

const DRAFT_PHOTO_DIRECTORY = `${FileSystem.documentDirectory ?? ""}listing-drafts/`;

function isRemoteUri(uri: string): boolean {
  return /^https?:\/\//i.test(uri);
}

function isDraftPhotoUri(uri: string): boolean {
  return uri.includes("/listing-drafts/");
}

function fileExtension(uri: string): string {
  const extension = uri.split("?")[0].match(/\.([a-zA-Z0-9]{2,5})$/)?.[1];
  return extension ? `.${extension.toLowerCase()}` : ".jpg";
}

/**
 * 선택한 사진을 앱 문서 폴더로 복사한다. 원본 갤러리 URI가 만료되어도 임시저장 사진은 유지된다.
 */
export async function persistListingDraftPhoto(uri: string, index: number): Promise<string> {
  if (Platform.OS === "web" || !FileSystem.documentDirectory || isRemoteUri(uri) || isDraftPhotoUri(uri)) {
    return uri;
  }

  try {
    await FileSystem.makeDirectoryAsync(DRAFT_PHOTO_DIRECTORY, { intermediates: true });
    const destination = `${DRAFT_PHOTO_DIRECTORY}${Date.now()}-${index}${fileExtension(uri)}`;
    await FileSystem.copyAsync({ from: uri, to: destination });
    return destination;
  } catch {
    // 복사 실패 시에도 원본 URI를 유지해 현재 세션의 사진 등록은 가능하게 한다.
    return uri;
  }
}

export async function removeListingDraftPhotos(uris: string[]): Promise<void> {
  if (Platform.OS === "web") return;

  await Promise.all(
    uris
      .filter(isDraftPhotoUri)
      .map((uri) => FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => {})),
  );
}
