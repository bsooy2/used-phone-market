/** 주요 은행별 계좌번호 허용 자릿수 맵 */
export const BANK_ACCOUNT_LENGTHS: Record<string, number[]> = {
  국민은행: [14],
  국민: [14],
  KB국민은행: [14],
  신한은행: [12],
  신한: [12],
  우리은행: [13],
  우리: [13],
  하나은행: [14],
  하나: [14],
  농협: [13, 14],
  NH농협: [13, 14],
  농협은행: [13, 14],
  기업은행: [14],
  IBK기업은행: [14],
  카카오뱅크: [13],
  카카오: [13],
  토스뱅크: [12],
  토스: [12],
  케이뱅크: [12],
  SC제일은행: [11, 12],
  씨티은행: [12],
  대구은행: [12],
  부산은행: [12, 13],
  경남은행: [12, 13],
  광주은행: [12],
  전북은행: [12, 13],
  제주은행: [12],
  수협: [12, 13],
  새마을금고: [13],
  신협: [13],
  우체국: [14],
};

/** 은행명과 계좌번호를 받아 자릿수 검증 결과를 반환한다. */
export function validateBankAccount(bankName: string, accountNumber: string): { valid: boolean; message: string | null } {
  const digits = accountNumber.replace(/[^0-9]/g, "");
  if (!digits) return { valid: false, message: "계좌번호를 입력해 주세요." };

  const normalizedBank = bankName.trim();
  if (!normalizedBank) return { valid: false, message: "은행을 입력해 주세요." };

  // 은행명에서 매칭되는 키를 찾는다
  const matchedKey = Object.keys(BANK_ACCOUNT_LENGTHS).find(
    (key) => normalizedBank.includes(key) || key.includes(normalizedBank),
  );

  if (!matchedKey) {
    // 알 수 없는 은행이면 10~16자리 범위만 확인
    if (digits.length < 10 || digits.length > 16) {
      return { valid: false, message: `계좌번호는 10~16자리여야 합니다. (현재 ${digits.length}자리)` };
    }
    return { valid: true, message: null };
  }

  const allowedLengths = BANK_ACCOUNT_LENGTHS[matchedKey];
  if (allowedLengths.includes(digits.length)) {
    return { valid: true, message: null };
  }

  const expected = allowedLengths.join(" 또는 ");
  return { valid: false, message: `${matchedKey}은 ${expected}자리입니다. (현재 ${digits.length}자리)` };
}
