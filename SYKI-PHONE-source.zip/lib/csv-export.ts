import { Share, Platform } from "react-native";
import * as FileSystem from "expo-file-system/legacy";

/**
 * 데이터를 CSV 문자열로 변환
 */
export function toCSV(headers: string[], rows: string[][]): string {
  const escape = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const lines = [headers.map(escape).join(",")];
  for (const row of rows) {
    lines.push(row.map(escape).join(","));
  }
  return "\uFEFF" + lines.join("\n"); // BOM for Excel 한글 호환
}

/**
 * CSV를 파일로 저장하고 공유 시트를 열어 내보내기
 */
export async function exportCSV(filename: string, csv: string): Promise<void> {
  if (Platform.OS === "web") {
    // 웹: Blob 다운로드
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } else {
    // 네이티브: 파일 저장 후 Share
    const path = `${FileSystem.cacheDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(path, csv, { encoding: FileSystem.EncodingType.UTF8 });
    await Share.share({ url: path, title: filename });
  }
}
