import { SellRequest } from "@/constants/types";

/** 선택한 신청을 관리자 보관함으로 이동한다. */
export function archiveSellRequests(requests: SellRequest[], ids: readonly string[], archivedAt: string): SellRequest[] {
  const selected = new Set(ids);
  return requests.map((request) =>
    selected.has(request.id) ? { ...request, archivedAt } : request,
  );
}

/** 선택한 보관 신청을 일반 신청 목록으로 되돌린다. */
export function restoreSellRequests(requests: SellRequest[], ids: readonly string[]): SellRequest[] {
  const selected = new Set(ids);
  return requests.map((request) => {
    if (!selected.has(request.id)) return request;
    const { archivedAt: _archivedAt, ...rest } = request;
    return rest;
  });
}

/** 선택한 신청을 영구 삭제한다. */
export function deleteSellRequests(requests: SellRequest[], ids: readonly string[]): SellRequest[] {
  const selected = new Set(ids);
  return requests.filter((request) => !selected.has(request.id));
}
