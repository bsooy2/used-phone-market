import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useState } from "react";

import { ADMIN_USER_ID, useAppStore } from "@/lib/app-store";

const INQUIRY_KEY = "@syki/trade_inquiries";

export type InquiryTransactionType = "order" | "sell";

export type TradeInquiry = {
  id: string;
  userId: string;
  authorName: string;
  transactionId: string;
  transactionType: InquiryTransactionType;
  transactionLabel: string;
  body: string;
  photos?: string[];
  createdAt: string;
  reply?: string;
  repliedAt?: string;
};

type InquiryStore = {
  inquiries: TradeInquiry[];
  loaded: boolean;
  createInquiry: (input: Omit<TradeInquiry, "id" | "createdAt" | "reply" | "repliedAt">) => { ok: boolean; error?: string };
  replyToInquiry: (id: string, reply: string) => { ok: boolean; error?: string };
  getInquiriesForUser: (userId: string) => TradeInquiry[];
};

const InquiryContext = createContext<InquiryStore | null>(null);

function createId() {
  return `inquiry_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export function InquiryProvider({ children }: { children: React.ReactNode }) {
  const [inquiries, setInquiries] = useState<TradeInquiry[]>([]);
  const [loaded, setLoaded] = useState(false);
  const { pushNotification } = useAppStore();

  useEffect(() => {
    AsyncStorage.getItem(INQUIRY_KEY)
      .then((raw) => setInquiries(raw ? JSON.parse(raw) : []))
      .catch(() => setInquiries([]))
      .finally(() => setLoaded(true));
  }, []);

  const save = (next: TradeInquiry[]) => {
    setInquiries(next);
    void AsyncStorage.setItem(INQUIRY_KEY, JSON.stringify(next));
  };

  const createInquiry: InquiryStore["createInquiry"] = (input) => {
    const body = input.body.trim();
    if (body.length < 2) return { ok: false, error: "문의 내용을 2자 이상 입력해 주세요." };
    const inquiry: TradeInquiry = { ...input, body, id: createId(), createdAt: new Date().toISOString() };
    save([inquiry, ...inquiries]);
    pushNotification({
      kind: "system",
      userId: ADMIN_USER_ID,
      refId: inquiry.id,
      title: "새 거래 문의가 도착했어요",
      body: `${inquiry.transactionLabel} · ${inquiry.authorName} 고객`,
    });
    return { ok: true };
  };

  const replyToInquiry: InquiryStore["replyToInquiry"] = (id, reply) => {
    const text = reply.trim();
    if (text.length < 2) return { ok: false, error: "답변 내용을 2자 이상 입력해 주세요." };
    const found = inquiries.find((inquiry) => inquiry.id === id);
    if (!found) return { ok: false, error: "문의를 찾을 수 없습니다." };
    const next = inquiries.map((inquiry) => inquiry.id === id ? { ...inquiry, reply: text, repliedAt: new Date().toISOString() } : inquiry);
    save(next);
    pushNotification({
      kind: "system",
      userId: found.userId,
      refId: id,
      title: "거래 문의에 답변이 등록되었어요",
      body: found.transactionLabel,
    });
    return { ok: true };
  };

  const value: InquiryStore = {
    inquiries,
    loaded,
    createInquiry,
    replyToInquiry,
    getInquiriesForUser: (userId) => inquiries.filter((inquiry) => inquiry.userId === userId),
  };

  return <InquiryContext.Provider value={value}>{children}</InquiryContext.Provider>;
}

export function useInquiryStore(): InquiryStore {
  const value = useContext(InquiryContext);
  if (!value) throw new Error("useInquiryStore must be used within InquiryProvider");
  return value;
}
