/**
 * 매입 견적 계산 로직 (순수 함수).
 * 시세표 데이터를 기반으로 고객이 선택한 등급/상태 옵션에 따라 예상 매입가를 산출한다.
 */
import {
  ALL_IPHONE_MODELS,
  BuybackGrade,
  BuybackModel,
  GRADE_LABELS,
} from "../constants/buyback-data";
import { SAMSUNG_MODELS } from "../constants/buyback-data-samsung";

/** 전체 매입 대상 모델 (아이폰 + 삼성) */
export const BUYBACK_MODELS: BuybackModel[] = [...ALL_IPHONE_MODELS, ...SAMSUNG_MODELS];

export function getModelByKey(key: string): BuybackModel | undefined {
  return BUYBACK_MODELS.find((m) => m.key === key);
}

export function getModelsByBrand(brand: BuybackModel["brand"]): BuybackModel[] {
  return BUYBACK_MODELS.filter((m) => m.brand === brand);
}

export { GRADE_LABELS };
export type { BuybackGrade, BuybackModel };

/** 고객이 선택할 수 있는 상태 옵션 정의 */
export type ConditionKey =
  | "liquidCrack"
  | "backGlass"
  | "lcd"
  | "biometrics"
  | "camera"
  | "wifi"
  | "burnInMid"
  | "burnInStrong"
  | "burnInLcd";

export interface ConditionOption {
  key: ConditionKey;
  label: string;
  /** 사용자 안내용 짧은 설명 */
  hint: string;
}

/**
 * 고객용 상태 옵션 목록.
 * 잔상은 약/중잔상과 강잔상을 단일 선택처럼 다루되 체크박스로 단순화.
 */
export const CONDITION_OPTIONS: ConditionOption[] = [
  { key: "liquidCrack", label: "액정 기스/잔기스", hint: "화면에 기스가 있어요" },
  { key: "backGlass", label: "후면 유리/카메라 손상", hint: "뒷판이나 카메라 렌즈가 깨졌어요" },
  { key: "lcd", label: "액정 파손/멍/줄(LCD 불량)", hint: "화면이 깨졌거나 멍·줄이 있어요" },
  { key: "biometrics", label: "지문/페이스 인식 불량", hint: "생체인식이 안 돼요" },
  { key: "camera", label: "카메라 불량", hint: "카메라가 흐리거나 작동 안 해요" },
  { key: "wifi", label: "WIFI/통신/나침반 불량", hint: "기능 일부가 작동 안 해요" },
  { key: "burnInMid", label: "약·중 잔상", hint: "화면에 옅은 잔상이 보여요" },
  { key: "burnInStrong", label: "강한 잔상", hint: "화면에 뚜렷한 잔상이 남아요" },
  { key: "burnInLcd", label: "LCD급(심한) 잔상", hint: "잔상이 매우 심해요 (특가 등급 적용 제외)" },
];

/** 잔상 옵션은 한 가지만 적용(가장 심한 것 우선) */
const BURN_IN_KEYS: ConditionKey[] = ["burnInMid", "burnInStrong", "burnInLcd"];

export interface QuoteInput {
  modelKey: string;
  storage: string;
  grade: BuybackGrade;
  /** 선택된 상태 옵션 키 목록 */
  conditions: ConditionKey[];
}

export interface QuoteLineItem {
  label: string;
  /** 만원 단위. 양수=가산(기준가), 음수=차감 */
  amount: number;
}

export interface QuoteResult {
  ok: boolean;
  /** 매입 불가 등 사유 (ok=false일 때) */
  reason?: string;
  modelName: string;
  storage: string;
  gradeLabel: string;
  /** 기준 등급가(만원) */
  basePrice: number;
  /** 차감 항목 내역 */
  deductions: QuoteLineItem[];
  /** 최종 예상 매입가(만원, 0 미만이면 0) */
  finalPrice: number;
  batteryMin: number;
  /** 등급 보정 등 안내 메모 */
  note?: string;
}

const GRADE_KEYS: BuybackGrade[] = ["A", "Aminus", "Bplus", "B", "liquid", "used"];

/** 해당 모델/용량에서 매입 가능한(가격이 null이 아닌) 등급 목록을 반환 */
export function availableGrades(model: BuybackModel, storage: string): BuybackGrade[] {
  const variant = model.variants.find((v) => v.storage === storage);
  if (!variant) return [];
  return GRADE_KEYS.filter((g) => variant.prices[g] != null);
}

/**
 * 견적 계산.
 * 기준 등급가에서 선택된 상태 옵션의 차감액을 차례로 뺀다.
 */
export function calculateQuote(input: QuoteInput): QuoteResult {
  const model = getModelByKey(input.modelKey);
  if (!model) {
    return emptyResult("모델 정보를 찾을 수 없습니다.");
  }
  const variant = model.variants.find((v) => v.storage === input.storage);
  if (!variant) {
    return emptyResult("용량 정보를 찾을 수 없습니다.", model.model, input.storage);
  }
  const base = variant.prices[input.grade];
  const gradeLabel = GRADE_LABELS[input.grade];
  if (base == null) {
    return {
      ok: false,
      reason: `${gradeLabel}은(는) 이 모델에서 매입이 어려워요. 다른 등급을 선택해 주세요.`,
      modelName: model.model,
      storage: input.storage,
      gradeLabel,
      basePrice: 0,
      deductions: [],
      finalPrice: 0,
      batteryMin: model.batteryMin,
    };
  }

  const d = model.deductions;
  // LCD파손은 별도가(lcdDamage)가 있으면 우선, 없으면 lcd 사용
  // LCD급 잔상은 burnInLcd가 있으면 우선, 없으면 강잔상으로 대체
  const deductionMap: Record<ConditionKey, number> = {
    liquidCrack: d.liquidCrack,
    backGlass: d.backGlass,
    lcd: d.lcdDamage != null ? d.lcdDamage : d.lcd,
    biometrics: d.biometrics,
    camera: d.camera,
    wifi: d.wifi,
    burnInMid: d.burnInMid,
    burnInStrong: d.burnInStrong,
    burnInLcd: d.burnInLcd != null ? d.burnInLcd : d.burnInStrong,
  };

  // 동일 항목 중복 제거
  let uniqueConditions = Array.from(new Set(input.conditions));
  // 잔상은 가장 심한 한 가지만 적용 (LCD급 > 강 > 약중)
  const selectedBurn = BURN_IN_KEYS.filter((k) => uniqueConditions.includes(k));
  if (selectedBurn.length > 1) {
    const keep = selectedBurn[selectedBurn.length - 1];
    uniqueConditions = uniqueConditions.filter(
      (c) => !BURN_IN_KEYS.includes(c) || c === keep,
    );
  }

  // 특가 등급(A/A-/B+) + LCD급 잔상은 시세표상 특가 미적용 → 중고가 기준으로 보정
  let effectiveBase = base;
  let gradeNote: string | undefined;
  const premiumGrades: BuybackGrade[] = ["A", "Aminus", "Bplus"];
  if (uniqueConditions.includes("burnInLcd") && premiumGrades.includes(input.grade)) {
    const usedPrice = variant.prices.used;
    if (usedPrice != null && usedPrice < effectiveBase) {
      effectiveBase = usedPrice;
      gradeNote = "LCD급 잔상은 특가 등급이 적용되지 않아 중고가 기준으로 산정됩니다.";
    }
  }

  const deductions: QuoteLineItem[] = [];
  for (const c of uniqueConditions) {
    const amount = deductionMap[c];
    const opt = CONDITION_OPTIONS.find((o) => o.key === c);
    if (!opt) continue;
    if (amount && amount > 0) {
      deductions.push({ label: opt.label, amount: -amount });
    }
  }

  const totalDeduction = deductions.reduce((sum, l) => sum + l.amount, 0);
  const finalPrice = Math.max(0, Math.round((effectiveBase + totalDeduction) * 10) / 10);

  return {
    ok: true,
    modelName: model.model,
    storage: input.storage,
    gradeLabel,
    basePrice: effectiveBase,
    deductions,
    finalPrice,
    batteryMin: model.batteryMin,
    note: gradeNote,
  };
}

function emptyResult(reason: string, modelName = "", storage = ""): QuoteResult {
  return {
    ok: false,
    reason,
    modelName,
    storage,
    gradeLabel: "",
    basePrice: 0,
    deductions: [],
    finalPrice: 0,
    batteryMin: 0,
  };
}

/** 만원 단위 숫자를 "12만원" / "12.5만원" 형태로 포맷 */
export function formatManwon(value: number): string {
  if (Number.isInteger(value)) return `${value}만원`;
  return `${value}만원`;
}

/** 만원 단위를 원 단위 정수로 변환 (예: 12.5 -> 125000) */
export function manwonToWon(value: number): number {
  return Math.round(value * 10000);
}
