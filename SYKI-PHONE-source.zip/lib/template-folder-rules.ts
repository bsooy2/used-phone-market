export const UNCLASSIFIED_FOLDER_ID = "unclassified";

export function validateTemplateFolderName(name: string, existingFolders: readonly { id: string; name: string }[], exceptId?: string) {
  const trimmed = name.trim();
  if (trimmed.length < 2) return "폴더 이름을 2자 이상 입력해 주세요.";
  if (trimmed.length > 20) return "폴더 이름은 20자 이내로 입력해 주세요.";
  if (existingFolders.some((folder) => folder.id !== exceptId && folder.name === trimmed)) return "같은 이름의 폴더가 이미 있습니다.";
  return null;
}

export function resolveTemplateFolderId(folderId: string | undefined, folderIds: readonly string[]) {
  return folderId && folderIds.includes(folderId) ? folderId : UNCLASSIFIED_FOLDER_ID;
}
