export type ReviewAnalyticsInput = {
  rating: number;
  visibility: "public" | "hidden";
};

export type ReviewAnalyticsSummary = {
  totalReviews: number;
  publicReviews: number;
  averageRating: number;
  eligibleTransactionCount: number;
  reviewWriteRate: number;
};

export function getReviewAnalyticsSummary(
  reviews: readonly ReviewAnalyticsInput[],
  eligibleTransactionCount: number,
): ReviewAnalyticsSummary {
  const totalReviews = reviews.length;
  const publicReviews = reviews.filter((review) => review.visibility === "public").length;
  const averageRating = totalReviews > 0 ? reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews : 0;
  const safeEligibleCount = Math.max(0, eligibleTransactionCount);
  return {
    totalReviews,
    publicReviews,
    averageRating,
    eligibleTransactionCount: safeEligibleCount,
    reviewWriteRate: safeEligibleCount > 0 ? Math.min(100, Math.round((totalReviews / safeEligibleCount) * 100)) : 0,
  };
}
