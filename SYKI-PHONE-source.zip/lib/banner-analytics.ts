import type { EventBanner } from "@/lib/content-store";

export function getBannerClickSummary(banners: readonly Pick<EventBanner, "id" | "title" | "clickCount" | "conversionCount">[]) {
  return {
    totalClicks: banners.reduce((sum, banner) => sum + (banner.clickCount ?? 0), 0),
    totalConversions: banners.reduce((sum, banner) => sum + (banner.conversionCount ?? 0), 0),
    ranked: [...banners].sort((a, b) => (b.clickCount ?? 0) - (a.clickCount ?? 0)),
  };
}

export function getBannerPeriodChannelComparison(banners: readonly Pick<EventBanner, "id" | "title" | "linkUrl" | "performanceEvents">[], days: number, now = new Date()) {
  const cutoff = now.getTime() - Math.max(1, days) * 24 * 60 * 60 * 1000;
  return banners.map((banner) => {
    const events = (banner.performanceEvents ?? []).filter((event) => Number.isFinite(new Date(event.occurredAt).getTime()) && new Date(event.occurredAt).getTime() >= cutoff);
    const taps = events.filter((event) => event.type === "tap").length;
    const conversions = events.filter((event) => event.type === "conversion").length;
    const channel = banner.linkUrl?.startsWith("tel:") ? "전화" : banner.linkUrl?.startsWith("http:") || banner.linkUrl?.startsWith("https:") ? "웹" : "앱";
    return { id: banner.id, title: banner.title, channel, taps, conversions, conversionRate: taps > 0 ? Math.round((conversions / taps) * 100) : 0 };
  }).sort((a, b) => b.conversions - a.conversions || b.taps - a.taps);
}
