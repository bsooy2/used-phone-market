/**
 * 결제 추상화 계층.
 *
 * 카카오페이: CID(가맹점 코드)가 설정되면 라이브 모드로 동작합니다.
 * - 결제 준비(ready) → 사용자 리다이렉트 → 결제 승인(approve)
 *
 * 기타 결제수단(카드/계좌이체/네이버페이):
 * - PG 키 미설정 시 모의(mock) 모드로 동작합니다.
 */

// react-native는 런타임에서만 사용 (테스트 환경 호환)
let RN: { Linking: any; Platform: any } | null = null;
try {
  RN = require("react-native");
} catch {
  RN = null;
}

export type PaymentMethod = "card" | "transfer" | "kakaopay" | "naverpay";

export type PaymentMethodInfo = {
  key: PaymentMethod;
  label: string;
  description: string;
  /** 아이콘 배경색 (브랜드 컬러) */
  brandColor: string;
};

export const PAYMENT_METHODS: PaymentMethodInfo[] = [
  { key: "card", label: "신용·체크카드", description: "국내 모든 카드 결제", brandColor: "#1F1F1F" },
  { key: "transfer", label: "계좌이체", description: "실시간 계좌이체", brandColor: "#4B4B4B" },
  { key: "kakaopay", label: "카카오페이", description: "간편결제", brandColor: "#FEE500" },
  { key: "naverpay", label: "네이버페이", description: "간편결제", brandColor: "#03C75A" },
];

export type PaymentRequest = {
  orderId: string;
  productId: string;
  productName: string;
  amount: number; // 원
  method: PaymentMethod;
  buyerName: string;
  buyerEmail: string;
};

export type PaymentResult =
  | { status: "success"; orderId: string; method: PaymentMethod; paidAt: string; receiptId: string }
  | { status: "failed"; orderId: string; method: PaymentMethod; reason: string }
  | { status: "cancelled"; orderId: string; method: PaymentMethod };

/**
 * PG 키 설정. 실제 키가 채워지면 isLiveMode()가 true가 되어 라이브 경로를 탑니다.
 */
export const PAYMENT_CONFIG = {
  tossClientKey: process.env.EXPO_PUBLIC_TOSS_CLIENT_KEY ?? "",
  kakaoPayCid: process.env.EXPO_PUBLIC_KAKAOPAY_CID ?? "",
  naverPayClientId: process.env.EXPO_PUBLIC_NAVERPAY_CLIENT_ID ?? "",
  /** 카카오페이 API 서버 base URL */
  kakaoPayApiUrl: "https://open-api.kakaopay.com/online/v1/payment",
};

export function isLiveMode(method: PaymentMethod): boolean {
  switch (method) {
    case "card":
    case "transfer":
      return !!PAYMENT_CONFIG.tossClientKey;
    case "kakaopay":
      return !!PAYMENT_CONFIG.kakaoPayCid;
    case "naverpay":
      return !!PAYMENT_CONFIG.naverPayClientId;
    default:
      return false;
  }
}

export function generateOrderId(): string {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 8);
  return `SYKI_${ts}_${rand}`.toUpperCase();
}

export function formatKRW(amount: number): string {
  return `${amount.toLocaleString("ko-KR")}원`;
}

// ─── 카카오페이 API 타입 ───

type KakaoPayReadyResponse = {
  tid: string;
  next_redirect_app_url: string;
  next_redirect_mobile_url: string;
  next_redirect_pc_url: string;
  created_at: string;
};

type KakaoPayApproveResponse = {
  aid: string;
  tid: string;
  cid: string;
  partner_order_id: string;
  partner_user_id: string;
  payment_method_type: string;
  amount: { total: number; tax_free: number };
  approved_at: string;
};

// 카카오페이 결제 상태를 임시 저장 (앱 메모리)
let pendingKakaoPayment: {
  tid: string;
  orderId: string;
  userId: string;
} | null = null;

/**
 * 카카오페이 결제 준비 (ready) API 호출
 */
async function kakaoPayReady(req: PaymentRequest): Promise<KakaoPayReadyResponse> {
  const cid = PAYMENT_CONFIG.kakaoPayCid;
  const approvalUrl = "https://usedphonemkt-98grbfe4.manus.space/kakaopay/success";
  const cancelUrl = "https://usedphonemkt-98grbfe4.manus.space/kakaopay/cancel";
  const failUrl = "https://usedphonemkt-98grbfe4.manus.space/kakaopay/fail";

  const body = new URLSearchParams({
    cid,
    partner_order_id: req.orderId,
    partner_user_id: req.buyerEmail || "anonymous",
    item_name: req.productName,
    quantity: "1",
    total_amount: String(req.amount),
    tax_free_amount: "0",
    approval_url: approvalUrl,
    cancel_url: cancelUrl,
    fail_url: failUrl,
  });

  const response = await fetch(`${PAYMENT_CONFIG.kakaoPayApiUrl}/ready`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": `SECRET_KEY DEV${cid}`,
    },
    body: body.toString(),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`카카오페이 결제 준비 실패: ${response.status} ${errorText}`);
  }

  return response.json();
}

/**
 * 카카오페이 결제 승인 (approve) API 호출
 */
export async function kakaoPayApprove(pgToken: string): Promise<KakaoPayApproveResponse | null> {
  if (!pendingKakaoPayment) return null;

  const { tid, orderId, userId } = pendingKakaoPayment;
  const cid = PAYMENT_CONFIG.kakaoPayCid;

  const body = new URLSearchParams({
    cid,
    tid,
    partner_order_id: orderId,
    partner_user_id: userId,
    pg_token: pgToken,
  });

  const response = await fetch(`${PAYMENT_CONFIG.kakaoPayApiUrl}/approve`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": `SECRET_KEY DEV${cid}`,
    },
    body: body.toString(),
  });

  pendingKakaoPayment = null;

  if (!response.ok) {
    throw new Error(`카카오페이 결제 승인 실패: ${response.status}`);
  }

  return response.json();
}

/**
 * 결제 요청 진입점.
 * - 카카오페이: CID가 있으면 실제 API 호출 (ready → redirect)
 * - 기타: 모의 모드
 */
export async function requestPayment(req: PaymentRequest): Promise<PaymentResult> {
  // 카카오페이 라이브 모드
  if (req.method === "kakaopay" && isLiveMode("kakaopay")) {
    try {
      const readyRes = await kakaoPayReady(req);

      // 결제 상태 임시 저장
      pendingKakaoPayment = {
        tid: readyRes.tid,
        orderId: req.orderId,
        userId: req.buyerEmail || "anonymous",
      };

      // 사용자를 카카오페이 결제 페이지로 리다이렉트
      const redirectUrl = RN?.Platform?.OS === "web"
        ? readyRes.next_redirect_pc_url
        : readyRes.next_redirect_mobile_url;

      if (RN?.Linking) {
        await RN.Linking.openURL(redirectUrl);
      }

      // 리다이렉트 후 approve는 콜백에서 처리됨
      // 여기서는 "진행 중" 상태로 성공 반환 (실제 승인은 콜백에서)
      return {
        status: "success",
        orderId: req.orderId,
        method: req.method,
        paidAt: new Date().toISOString(),
        receiptId: readyRes.tid,
      };
    } catch (error: any) {
      return {
        status: "failed",
        orderId: req.orderId,
        method: req.method,
        reason: error?.message || "카카오페이 결제 처리 중 오류가 발생했습니다.",
      };
    }
  }

  // 기타 라이브 모드 (미구현)
  if (isLiveMode(req.method)) {
    return {
      status: "failed",
      orderId: req.orderId,
      method: req.method,
      reason: "라이브 결제 연동이 아직 구현되지 않았습니다. (PG 계약 후 연동 예정)",
    };
  }

  // 모의(sandbox) 결제: 플로우 검증용
  await new Promise((resolve) => setTimeout(resolve, 1200));

  return {
    status: "success",
    orderId: req.orderId,
    method: req.method,
    paidAt: new Date().toISOString(),
    receiptId: `RCPT_${req.orderId}`,
  };
}
