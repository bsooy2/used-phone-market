# SOLAPI SMS 인증 연동 참고

- SOLAPI REST API는 `application/json`, UTF-8, `HMAC_SHA256` Authorization을 사용한다.
- 공식 Node.js SDK 기준 SMS 발송은 API Key·API Secret·SOLAPI에 등록된 발신번호가 필요하다.
- 발신번호와 수신번호는 특수문자 없이 `01012345678` 형식으로 전달해야 한다.
- 연결 검증은 실제 발송 대신 `GET https://api.solapi.com/cash/v1/balance` 잔액 조회를 사용한다.

## 공식 출처

- https://solapi.com/developers/api/start
- https://solapi.com/developers/api/authentication
- https://solapi.com/developers/sdk/nodejs-sendingexample
- https://solapi.com/developers/api/getBalance

## 발송 이력과 비용 집계

`GET /messages/v4/list`는 발송 대상·메시지 타입·상태·상태 코드·생성 일시를 제공한다. 인증 문자만 식별해 발송 이력으로 표시하고, 실제 비용은 `GET /cash/v1/balance-history`의 잔액 변동 가운데 메시지 발송 차감 건을 합산한다. 해당 기록은 SOLAPI 계정 잔액 기준이며, 요금 추정값을 임의로 계산하지 않는다.

## 추가 공식 출처

- https://solapi.com/developers/api/msg-getList
- https://solapi.com/developers/api/balance-getBalanceHistory
